package go3treks.craig.com.go3treks.model;


public class Station{

    public String title = null;
    public String subtitle = null;
    Double latitude = 0.0;
    Double longitude = 0.0;

    public Station(Double lat, Double lon)
    {
        super();
        latitude = lat;
        longitude = lon;
    }

}
