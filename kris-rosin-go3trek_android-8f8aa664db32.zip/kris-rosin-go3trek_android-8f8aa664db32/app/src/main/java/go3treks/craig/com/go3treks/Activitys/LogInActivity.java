package go3treks.craig.com.go3treks.Activitys;

import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import go3treks.craig.com.go3treks.*;
import go3treks.craig.com.go3treks.Manager.Go3TreksConstants;

public class LogInActivity extends AppCompatActivity {

    private float rWindowW = 0;
    private float rWindowH = 0;
    public TextView textVSignUp;
    private ImageView imgLogo;
    private EditText editUsername;
    private EditText editPassword;
    private TextView textForget;
    private ImageView imgOr;
    private EditText editGroup;
    private Button btnSubmit;
    private Button btnSkip;


    public float rX;
    public float rY;

    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        Display display = getWindowManager().getDefaultDisplay();
        rWindowW = display.getWidth();
        rWindowH = display.getHeight();

        rX = Go3TreksConstants.getRX(rWindowW);
        rY = Go3TreksConstants.getRY(rWindowH);

        //skip button
        btnSkip = (Button)findViewById(R.id.button_login_skip);
        btnSkip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent mainIntent = new Intent(LogInActivity.this, EPALocationActivity.class);
                LogInActivity.this.startActivity(mainIntent);
                LogInActivity.this.finish();
            }
        });
        int nBtnSkipW = (int)rWindowW/3*2;
        int nBtnSkipH = (int)(50*rY);
        btnSkip.setX(rWindowW/2 - nBtnSkipW/2);
        btnSkip.setY(rWindowH - 100*rY - nBtnSkipH);
        RelativeLayout.LayoutParams parmsBtnSkip = new RelativeLayout.LayoutParams(nBtnSkipW, nBtnSkipH);
        btnSkip.setLayoutParams(parmsBtnSkip);

        //signup text
        textVSignUp = (TextView)this.findViewById(R.id.textViewSignUp);
        textVSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mainIntent = new Intent(LogInActivity.this, SignUpActivity.class);
                LogInActivity.this.startActivity(mainIntent);
                LogInActivity.this.finish();
            }
        });
        int nTxtSignupW = (int)rWindowW/5;
        int nTxtSignupH = (int)(40*rY);
        textVSignUp.setX(rWindowW/2 + nBtnSkipW/2 - nTxtSignupW);
        textVSignUp.setY(rWindowH - 50*rY - nTxtSignupH);
        RelativeLayout.LayoutParams parmsTxtSignup = new RelativeLayout.LayoutParams(nTxtSignupW, nTxtSignupH);
        textVSignUp.setLayoutParams(parmsTxtSignup);

        //submit button
        btnSubmit = (Button)findViewById(R.id.button_login_submit);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        int nBtnSubmitW = (int)rWindowW/3*2;
        int nBtnSubmitH = (int)(50*rY);
        btnSubmit.setX(rWindowW/2 - nBtnSubmitW/2);
        btnSubmit.setY(rWindowH - 100*rY - nBtnSkipH - 10*rY - nBtnSubmitH);
        RelativeLayout.LayoutParams parmsBtnSubmit = new RelativeLayout.LayoutParams(nBtnSubmitW, nBtnSubmitH);
        btnSubmit.setLayoutParams(parmsBtnSubmit);

        //group edit
        RelativeLayout relativeGroup = (RelativeLayout)findViewById(R.id.relative_login_group);
        int nRelativeGroupW = (int)rWindowW/3*2;
        int nRelativeGroupH = (int)(80*rY);
        relativeGroup.setX(rWindowW/2 - nRelativeGroupW/2);
        relativeGroup.setY(btnSubmit.getY() - 10*rY - nRelativeGroupH);
        RelativeLayout.LayoutParams parmsRelatGrup = new RelativeLayout.LayoutParams(nRelativeGroupW, nRelativeGroupH);
        relativeGroup.setLayoutParams(parmsRelatGrup);

        ImageView imgGLine = (ImageView)findViewById(R.id.imageView_login_goupline);
        int nImgGLineW = (int)(10*rX);
        int nImgGLineH = (int)(40*rY);
        imgGLine.setX(50*rX);
        imgGLine.setY(20*rY);
        RelativeLayout.LayoutParams parmsImgGLine = new RelativeLayout.LayoutParams(nImgGLineW, nImgGLineH);
        imgGLine.setLayoutParams(parmsImgGLine);


        ImageView imgGIcon = (ImageView)findViewById(R.id.imageView_login_groupuser);
        int nImgGIconW = nRelativeGroupH - (int)(40*rY);
        int nImgGIconH = nRelativeGroupH - (int)(40*rY);
        imgGIcon.setX(10*rX);
        imgGIcon.setY(20*rY);
        RelativeLayout.LayoutParams parmsImgGIcon = new RelativeLayout.LayoutParams(nImgGIconW, nImgGIconH);
        imgGIcon.setLayoutParams(parmsImgGIcon);

        ImageView imgGBk = (ImageView)findViewById(R.id.imageView_login_groupbk);
        int nImgGBkW = nRelativeGroupW;
        int nImgGBkH = nRelativeGroupH;
        imgGBk.setX(0);
        imgGBk.setY(0);
        RelativeLayout.LayoutParams parmsImgGBk = new RelativeLayout.LayoutParams(nImgGBkW, nImgGBkH);
        imgGBk.setLayoutParams(parmsImgGBk);

        editGroup = (EditText)findViewById(R.id.editText_login_group);
        int editGW = nRelativeGroupW - (int)(55*rX);
        int editGH = nRelativeGroupH;
        editGroup.setX(55*rX);
        editGroup.setY(0);
        RelativeLayout.LayoutParams parmsEditG = new RelativeLayout.LayoutParams(editGW, editGH);
        editGroup.setLayoutParams(parmsEditG);
        editGroup.setBackgroundDrawable(null);

        //image or
        imgOr = (ImageView)findViewById(R.id.imageView_login_or);
        int nImgOrW = nRelativeGroupW;
        int nImgOrH = (int)(20*rY);
        imgOr.setX(rWindowW/2 - nImgOrW/2);
        imgOr.setY(relativeGroup.getY() - 20*rY);
        RelativeLayout.LayoutParams parmsImgOr = new RelativeLayout.LayoutParams(nImgOrW, nImgOrH);
        imgOr.setLayoutParams(parmsImgOr);

        //forget text
        textForget = (TextView)this.findViewById(R.id.textView_login_forgetpassword);
        textForget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        int nTxtForgetW = (int)rWindowW/3;
        int nTxtForgetH = (int)(40*rY);
//        ViewTreeObserver vto = textForget.getViewTreeObserver();
//        vto.addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
//            public boolean onPreDraw() {
//                nTxtForgetW = textForget.getMeasuredHeight();
//                nTxtForgetH = textForget.getMeasuredWidth();
//                return true;
//            }
//        });

        textForget.setX(rWindowW/2 + nBtnSkipW/2 - nTxtForgetW);
        textForget.setY(imgOr.getY() - 50*rY);
        RelativeLayout.LayoutParams parmsTxtForget = new RelativeLayout.LayoutParams(nTxtForgetW, nTxtForgetH);
        textForget.setLayoutParams(parmsTxtForget);

        //password edit
        RelativeLayout relativePassword = (RelativeLayout)findViewById(R.id.relative_login_password);
        int nRelativePassW = (int)rWindowW/3*2;
        int nRelativePassH = (int)(80*rY);
        relativePassword.setX(rWindowW/2 - nRelativePassW/2);
        relativePassword.setY(textForget.getY() - 10*rY - nRelativePassH);
        RelativeLayout.LayoutParams parmsRelatPass = new RelativeLayout.LayoutParams(nRelativePassW, nRelativePassH);
        relativePassword.setLayoutParams(parmsRelatPass);

        ImageView imgPLine = (ImageView)findViewById(R.id.imageView_login_passline);
        int nImgPLineW = (int) (10*rX);
        int nImgPLineH = (int) (40*rY);
        imgPLine.setX(50*rX);
        imgPLine.setY(20*rY);
        RelativeLayout.LayoutParams parmsImgPLine = new RelativeLayout.LayoutParams(nImgPLineW, nImgPLineH);
        imgPLine.setLayoutParams(parmsImgPLine);


        ImageView imgPIcon = (ImageView)findViewById(R.id.imageView_login_pass);
        int nImgPIconW = nRelativePassH - (int) (40*rY);
        int nImgPIconH = nRelativePassH - (int)(40*rY);
        imgPIcon.setX(10*rX);
        imgPIcon.setY(20*rY);
        RelativeLayout.LayoutParams parmsImgPIcon = new RelativeLayout.LayoutParams(nImgPIconW, nImgPIconH);
        imgPIcon.setLayoutParams(parmsImgPIcon);

        ImageView imgPBk = (ImageView)findViewById(R.id.imageView_login_passbk);
        int nImgPBkW = nRelativePassW;
        int nImgPBkH = nRelativePassH;
        imgPBk.setX(0);
        imgPBk.setY(0);
        RelativeLayout.LayoutParams parmsImgPBk = new RelativeLayout.LayoutParams(nImgPBkW, nImgPBkH);
        imgPBk.setLayoutParams(parmsImgPBk);

        editPassword = (EditText)findViewById(R.id.editText_login_password);
        int editPW = nRelativePassW - (int)(55*rX);
        int editPH = nRelativePassH;
        editPassword.setX(55*rX);
        editPassword.setY(0);
        RelativeLayout.LayoutParams parmsEditP = new RelativeLayout.LayoutParams(editPW, editPH);
        editPassword.setLayoutParams(parmsEditP);
        editPassword.setBackgroundDrawable(null);

        //user edit
        RelativeLayout relativeUser = (RelativeLayout)findViewById(R.id.relative_login_user);
        int nRelativeUserW = (int)rWindowW/3*2;
        int nRelativeUserH = (int)(80*rY);
        relativeUser.setX(rWindowW/2 - nRelativePassW/2);
        relativeUser.setY(relativePassword.getY() - 20*rY - nRelativeUserH/2);
        RelativeLayout.LayoutParams parmsRelatUser = new RelativeLayout.LayoutParams(nRelativeUserW, nRelativeUserH);
        relativeUser.setLayoutParams(parmsRelatUser);

        ImageView imgULine = (ImageView)findViewById(R.id.imageView_login_userline);
        int nImgULineW = (int)(10*rX);
        int nImgULineH = (int)(40*rY);
        imgULine.setX(50*rX);
        imgULine.setY(20*rY);
        RelativeLayout.LayoutParams parmsImgULine = new RelativeLayout.LayoutParams(nImgULineW, nImgULineH);
        imgULine.setLayoutParams(parmsImgULine);


        ImageView imgUIcon = (ImageView)findViewById(R.id.imageView_login_useruser);
        int nImgUIconW = nRelativeUserH - (int)(40*rY);
        int nImgUIconH = nRelativeUserH - (int) (40*rY);
        imgUIcon.setX(10*rX);
        imgUIcon.setY(20*rY);
        RelativeLayout.LayoutParams parmsImgUIcon = new RelativeLayout.LayoutParams(nImgUIconW, nImgUIconH);
        imgUIcon.setLayoutParams(parmsImgUIcon);

        ImageView imgUBk = (ImageView)findViewById(R.id.imageView_login_userbk);
        int nImgUBkW = nRelativeUserW;
        int nImgUBkH = nRelativeUserH;
        imgUBk.setX(0);
        imgUBk.setY(0);
        RelativeLayout.LayoutParams parmsImgUBk = new RelativeLayout.LayoutParams(nImgUBkW, nImgUBkH);
        imgUBk.setLayoutParams(parmsImgUBk);

        editUsername = (EditText)findViewById(R.id.editText_login_username);
        int editUW = nRelativeUserW - (int)(55*rX);
        int editUH = nRelativeUserH;
        editUsername.setX(55*rX);
        editUsername.setY(0);
        RelativeLayout.LayoutParams parmsEditU = new RelativeLayout.LayoutParams(editUW, editUH);
        editUsername.setLayoutParams(parmsEditU);
        editUsername.setBackgroundDrawable(null);

        //image logo
        imgLogo = (ImageView)findViewById(R.id.img_login_logo);
        int logH = (int)relativeUser.getY() - (int)(150*rY);
        int logW = logH;
        RelativeLayout.LayoutParams parmsImgLogo = new RelativeLayout.LayoutParams(logW, logH);
        imgLogo.setLayoutParams(parmsImgLogo);
        imgLogo.setX(rWindowW/2 - logW/2);
        imgLogo.setY(100*rY);

    }
}
