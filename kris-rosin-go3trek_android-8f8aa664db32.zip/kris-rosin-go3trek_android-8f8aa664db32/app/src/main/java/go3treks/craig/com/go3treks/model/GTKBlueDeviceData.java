package go3treks.craig.com.go3treks.model;

import android.bluetooth.BluetoothDevice;

import java.util.ArrayList;

/**
 * Created by osc_mac on 12/2/16.
 */

public class GTKBlueDeviceData {

    public String strDeviceName = "";
    public String strStartTrekTime = "";
    public String strEndTrekTime = "";
    public Boolean isTreking= false;
    public Boolean isSelectOnFinish = false;
    public int nCountTrekPoint = 0;
    public int nIndex = 0;
    public int nPoint = 0;

    public BluetoothDevice periperal;

    public ArrayList<Double> latMyDevice = new ArrayList<Double>();
    public ArrayList<Double> lonMyDevice = new ArrayList<Double>();

    public ArrayList<BLEPacket> blePackets = new ArrayList<BLEPacket>();

    public int nIndexLocation = 0;

    public GTKBlueDeviceData()
    {

    }
}
