package go3treks.craig.com.go3treks.Fragments;

import android.app.Activity;
import android.app.IntentService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Typeface;
import android.location.Location;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.maps.MapView;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;

import go3treks.craig.com.go3treks.Activitys.LogInActivity;
import go3treks.craig.com.go3treks.Activitys.SignUpActivity;
import go3treks.craig.com.go3treks.Manager.DownloadConntectURL;
import go3treks.craig.com.go3treks.Manager.DownloadFileFromURL;
import go3treks.craig.com.go3treks.Manager.GPSTracker;
import go3treks.craig.com.go3treks.Manager.GTKBleDeviceManager;
import go3treks.craig.com.go3treks.Manager.GTKGlobal;
import go3treks.craig.com.go3treks.Manager.Go3TreksConstants;
import go3treks.craig.com.go3treks.R;
import go3treks.craig.com.go3treks.model.DataInfo;
import go3treks.craig.com.go3treks.model.GTKBlueDeviceData;
import go3treks.craig.com.go3treks.model.MonitorInfo;

@SuppressWarnings("Since15")
public class StatusFragment extends Fragment {

    boolean bStart = false;

    private TextView textMain;
    ArrayList<String> arrayMonitoInfo = new ArrayList<String>();
    //O3, PM2.5, SO2, NO2, PM2.5, PM10, CO, TEMP, WS, WD, RHUM, NO2Y, NOY, PRECIP, SRAD, NO, NOX
    ArrayList<MonitorInfo> ozoneMonitorInfo = new ArrayList<MonitorInfo>();
    ArrayList<MonitorInfo> no2MonitorInfo = new ArrayList<MonitorInfo>();
    ArrayList<MonitorInfo> pm25MonitorInfo = new ArrayList<MonitorInfo>();
    ArrayList<MonitorInfo> pm10MonitorInfo = new ArrayList<MonitorInfo>();
    ArrayList<MonitorInfo> coMonitorInfo = new ArrayList<MonitorInfo>();
    ArrayList<MonitorInfo> tempMonitorInfo = new ArrayList<MonitorInfo>();
    ArrayList<MonitorInfo> rhMonitorInfo = new ArrayList<MonitorInfo>();
    ArrayList<MonitorInfo> noxMonitorInfo = new ArrayList<MonitorInfo>();

    ArrayList<DataInfo> arrayDataInfo = new ArrayList<DataInfo>();
    ArrayList<DataInfo> arrayTmpDataInfo = new ArrayList<DataInfo>();

    boolean fileParserStarted = false;
    int parsedLineCount = 0;
    Thread monitorThread;
    Thread hourlyThread;
    boolean bReadHourlyData = false;
    boolean bReadHourlyDataFail = false;

    private static final String strFilePath = "https://s3-us-west-1.amazonaws.com//files.airnowtech.org/airnow/today/monitoring_site_locations.dat";

    public StatusFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LocalBroadcastManager.getInstance(this.getContext()).registerReceiver(redrawStatusReceiver,
                new IntentFilter(GTKGlobal.kNotificationResetStatus));


   }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_status, container, false);
    }

    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        textMain = (TextView) view.findViewById(R.id.status_textview);
        bStart = true;
        bReadHourlyData = false;
        bReadHourlyDataFail = false;

        monitorThread = new Thread(new Runnable() {
            @Override
            public void run() {

                while (Go3TreksConstants.bReadMonitoFile == false)
                {
                    if (Go3TreksConstants.bReadMonitoFileFail == true)
                    {
                        new downloadLocationsFile().start();
                        Go3TreksConstants.bReadMonitoFileFail = false;
                    }
                }

            }
        });
        monitorThread.start();

        hourlyThread = new Thread(new Runnable() {
            @Override
            public void run() {
                new downloadHourlyFile().start();
                while (bReadHourlyData == false)
                {
                    if (bReadHourlyDataFail == true)
                    {
                        new downloadHourlyFile().start();
                        bReadHourlyDataFail = false;
                    }
                }
            }
        });
        hourlyThread.start();
    }


    @Override
    public void onResume() {
        super.onResume();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager.getInstance(getContext()).unregisterReceiver(redrawStatusReceiver);

        bReadHourlyData = true;
        monitorThread.interrupt();
        hourlyThread.interrupt();
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    //
    private BroadcastReceiver redrawStatusReceiver = new BroadcastReceiver() {
        @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
        @Override
        public void onReceive(Context context, Intent intent) {

            redrawStatus();
        }
    };

    public void redrawStatus()
    {

        if (bStart == false)
        {
            return;
        }
        textMain.setText("");
        if (Go3TreksConstants.bBleSkip == false)
        {
            SpannableString str1=  new SpannableString("Number of Data Points:");
            str1.setSpan(new StyleSpan(Typeface.BOLD), 0, str1.length()-1, 0);
            textMain.append(str1);
            textMain.append("\n");
            textMain.append(String.format("  %d", GTKGlobal.g_nIndexRedrawG));
            textMain.append("\n");
            textMain.append("\n");
            SpannableString str2=  new SpannableString("Current Device Measurements:");
            str2.setSpan(new StyleSpan(Typeface.BOLD), 0, str2.length()-1, 0);
            textMain.append(str2);
            textMain.append("\n");


            if (GTKBleDeviceManager.arrayDevices.size() > 0)
            {
                GTKBlueDeviceData dataDevice = GTKBleDeviceManager.arrayDevices.get(0);
                int packetCount = dataDevice.blePackets.size();
                if (packetCount > 0)
                {
                    for (int i = 0; i < packetCount; i++)
                    {
                        String strGas = dataDevice.blePackets.get(i).name;

                        String strGasValue = "";
                        if (dataDevice.blePackets.get(i)._value.size()>0)
                        {
                            strGasValue = String.format(" -> %2f", dataDevice.blePackets.get(i)._value.get(dataDevice.blePackets.get(i)._value.size()-1));
                        }
                        else
                        {
                            strGasValue = String.format(" -> %2f", dataDevice.blePackets.get(i)._value.get(0));
                        }

                        String strGasUnit = dataDevice.blePackets.get(i)._units;


                        if( dataDevice.blePackets.get(i).isString )
                        {
                            if (dataDevice.blePackets.get(i)._valueString.size() > 0)
                            {
                                strGasValue = dataDevice.blePackets.get(i)._valueString.get(dataDevice.blePackets.get(i)._valueString.size()-1);
                            }
                            else
                            {
                                strGasValue = dataDevice.blePackets.get(i)._valueString.get(0);
                            }
                            textMain.append("\n");
                            textMain.append(strGas);
                            textMain.append(strGasValue);
                        }
                        else
                        {
                            textMain.append("\n");
                            textMain.append(strGas);
                            textMain.append(strGasValue);
                            textMain.append(String.format(" %s", strGasUnit));
                        }

                    }
                }


            }
        }

        textMain.append("\n");
        textMain.append("\n");
        SpannableString str3=  new SpannableString("Closest EPA Measurements:");
        str3.setSpan(new StyleSpan(Typeface.BOLD), 0, str3.length()-1, 0);
        textMain.append(str3);
        textMain.append("\n");

        if (arrayDataInfo.size() > 0)
        {
            for(int i = 0; i < arrayDataInfo.size(); i++)
            {
                String oneDecimalPlace = String.format("%.1f", arrayDataInfo.get(i).distanceToMe);
                textMain.append(String.format("  %s = %s %s", arrayDataInfo.get(i).gas, arrayDataInfo.get(i).gasValue, arrayDataInfo.get(i).unit));
                textMain.append("\n");
                textMain.append(String.format("     %s, %s miles away", arrayDataInfo.get(i).county, oneDecimalPlace));
                textMain.append("\n");
            }
        }
        else
        {

            String strRealEPAMeasure = "  Please wait. Finding now.";
            textMain.append(strRealEPAMeasure);
        }
    }




    private class downloadLocationsFile extends Thread/*AsyncTask<String, String, String>*/ {

        public downloadLocationsFile()
        {

        }

        @Override
        public void run() {
            super.run();
            if (Go3TreksConstants.myCurrentLatitude == 0 && Go3TreksConstants.myCurrentLongitude == 0)
            {
                Go3TreksConstants.bReadMonitoFileFail = true;
                return;
            }
            doInBackground(strFilePath);
        }

        protected String doInBackground(String f_url) {

            try {
                fileParserStarted = true;
                URL url = new URL(f_url);
                URLConnection ucon = url.openConnection();
                InputStream input = ucon.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(input));
                String line = "";


                Log.i("line monitor starting ----- ", "line starting");
                int nCount = 0;
                int nReadingCount = 0;
                while ((line = reader.readLine()) != null) {
                    MonitorInfo monitor = new MonitorInfo();
                    line = reader.readLine();
                    arrayMonitoInfo.add(line);
                    // do something with the line
                    String[] strS = line.split("\\|");

                    if (strS.length > 18)
                    {
                        if (!strS[0].isEmpty()) { //ID
                            String _ID = strS[0];
                            monitor._ID = _ID;
                        }

                        if (!strS[1].isEmpty()) { //gas
                            String gas = strS[1];
                            //print("Monitor gas:\(gas)")
                            monitor.gas = gas;
                        }

                        if (!strS[2].isEmpty()) { //value
                            String v = strS[2];
                            //print("Monitor value:\(v)")
                            monitor.gasValue = v;
                        }

                        if (!strS[3].isEmpty()) {//county
                            String county = strS[3];
                            //print("Monitor count:\(county)")
                            monitor.county = county;
                        }
                        if (!strS[4].isEmpty()) {
                            String activeStatus = strS[4];
                            //print("Monitor status:\(activeStatus)")
                            monitor.activeStatus = activeStatus;
                        }
                        if (!strS[8].isEmpty()) { //lat
                            String lat = strS[8];
                            //print("Monitor latitude:\(lat)")
                            monitor.lat = lat;
                        }

                        if (!strS[9].isEmpty()) { //long
                            String longi = strS[9];
                            //print("Monitor longitude:\(long)")
                            monitor.longi = longi;
                        }

                        if (!strS[18].isEmpty()) { //state
                            String state = strS[18];
                            //print("Monitor state:\(state)")
                            monitor.state = state;
                        }

                        if (!strS[16].isEmpty()) { //city
                            String city = strS[16];
                            //print("Monitor city:\(city)")
                            monitor.city = city;
                        }

                        GTKGlobal.g_State = "CA";
                        if ((!monitor.activeStatus.contains("Inactive")) && (GTKGlobal.g_State.compareToIgnoreCase(monitor.state) == 0
                                || monitor.state.compareToIgnoreCase(GTKGlobal.g_State) == 0)) {
                            //print("found state:\(monitor.state), county: \(monitor.county), active state: \(monitor.activeStatus)\n");

                            if (monitor.gas != "")
                            {
                                if (monitor.gas.contains("CO")) {
                                    coMonitorInfo.add(monitor);
                                } else if (monitor.gas.contains("O3")) {
                                    ozoneMonitorInfo.add(monitor);
                                } else if (monitor.gas.contains("PM2.5")) {
                                    pm25MonitorInfo.add(monitor);
                                } else if (monitor.gas.contains("PM10")) {
                                    pm10MonitorInfo.add(monitor);
                                } else if (monitor.gas.contains("TEMP")) {
                                    tempMonitorInfo.add(monitor);
                                } else if (monitor.gas.contains("RHUM")) {
                                    rhMonitorInfo.add(monitor);
                                } else if (monitor.gas.contains("NOX")) {
                                    noxMonitorInfo.add(monitor);
                                } else if (monitor.gas.contains("NO2")) {
                                    no2MonitorInfo.add(monitor);
                                }

                                Log.i("line Monito gas", monitor.gas);

                                closestLocationArray(coMonitorInfo);
                                closestLocationArray(no2MonitorInfo);
                                closestLocationArray(ozoneMonitorInfo);
                                closestLocationArray(pm25MonitorInfo);
                                closestLocationArray(pm10MonitorInfo);
                                closestLocationArray(rhMonitorInfo);
                                closestLocationArray(tempMonitorInfo);

                                nReadingCount += 1;
                            }

                        }//end if g_state
                    }

                    nCount += 1;

                }//end while

                parsedLineCount = nCount;

                closestLocationArray(coMonitorInfo);
                closestLocationArray(no2MonitorInfo);
                closestLocationArray(ozoneMonitorInfo);
                closestLocationArray(pm25MonitorInfo);
                closestLocationArray(pm10MonitorInfo);
                closestLocationArray(rhMonitorInfo);
                closestLocationArray(tempMonitorInfo);

                reader.close();
                input.close();

                Go3TreksConstants.bReadMonitoFile = true;

            } catch (Exception e) {
                Log.e("Error: ", e.getMessage());
                Go3TreksConstants.bReadMonitoFileFail = true;
            }

            return "";
        }

    }

    public class downloadHourlyFile extends Thread /*AsyncTask<String, String, String>*/ {

        public downloadHourlyFile(){}

        @Override
        public void run() {
//            super.run();
//            if (coMonitorInfo.size() == 0 ||
//                    no2MonitorInfo.size() == 0 ||
//                    ozoneMonitorInfo.size() == 0 ||
//                    pm25MonitorInfo.size() == 0 ||
//                    pm10MonitorInfo.size() == 0 ||
//                    rhMonitorInfo.size() == 0 ||
//                    tempMonitorInfo.size() == 0)
//            {
//                bReadHourlyDataFail = true;
//                return;
//            }
//            doInBackground();
            getHourlyDataInfo();
        }

        public void doInBackground() {

            String f_url = "";
            boolean foundCO = false;
            boolean foundOzone = false;
            boolean foundNO2 = false;
            boolean foundPM25 = false;
            boolean foundPM10 = false;
            boolean foundTemp = false;
            boolean foundRH = false;

            String dateFileString = getDateFilePath();
            String prefixString = "https://s3-us-west-1.amazonaws.com//files.airnowtech.org/airnow/today/HourlyData_";
            int utcHour = Integer.parseInt(getUTCHour()) + 3;
            if(utcHour < 0){
                utcHour = 23;
            }
            if(utcHour < 10){
                f_url = prefixString + dateFileString + String.format("0%d", utcHour) + ".dat";
            }else{
                f_url = prefixString + dateFileString + String.format("%d", utcHour) + ".dat";
            }
            try {

                URL url = new URL(f_url);

                URLConnection ucon = url.openConnection();

                InputStream input = ucon.getInputStream();

                BufferedReader reader = new BufferedReader(new InputStreamReader(input));

                if (arrayDataInfo.size() > 0)
                {
                    arrayDataInfo.clear();
                }
                Log.i("line hourly data starting ----- ", "line starting");
                String line = "";
                int arrayIndexCounter = 0;
                while(!foundCO || !foundOzone || !foundNO2 || !foundPM25 || !foundPM10 || !foundTemp || !foundRH)
                {
                    while ((line = reader.readLine()) != null)
                    {
                        DataInfo dataInfo = new DataInfo();
                        line = reader.readLine();
                        Log.i("line string ----- ", line);
                        // do something with the line
                        String[] strS = line.split("\\|");

                        if(!strS[2].isEmpty()){ //ID
                            String _ID  = strS[2];
                            // print("data ID:\(_ID)")
                            dataInfo._ID = _ID;
                        }

                        if(!strS[5].isEmpty()){ //gas
                            String gas  = strS[5];
                            //print("data gas:\(gas)")
                            dataInfo.gas = gas;
                        }

                        if(!strS[7].isEmpty()){ //value
                            String v  = strS[7];
                            //print("data value:\(v)")
                            dataInfo.gasValue = v;
                        }



                        if(!strS[6].isEmpty()){ //unit
                            String unit  = strS[6];
                            //print("data unit:\(unit)")
                            dataInfo.unit = unit;
                        }

                        if(!strS[3].isEmpty()){ //city
                            String city  = strS[3];
                            //print("data city:\(city)")
                            dataInfo.city = city;
                        }

                        if (coMonitorInfo.size()>0)
                        {
                            for (int i = 0; i < coMonitorInfo.size(); i++ )
                            {
                                if (coMonitorInfo.get(i)._ID.contains(dataInfo._ID) && dataInfo.gas.contains("CO") && !foundCO)
                                {
                                    dataInfo.county = coMonitorInfo.get(i).county;
                                    dataInfo.distanceToMe = coMonitorInfo.get(i).distanceToMe;
                                    arrayDataInfo.add(dataInfo);
                                    foundCO = true;
                                    Log.i("Found CO", "");
                                }
                            }
                        }

                        if (ozoneMonitorInfo.size() > 0)
                        {
                            for (int i = 0; i < ozoneMonitorInfo.size(); i++)
                            {
                                if (ozoneMonitorInfo.get(i)._ID.contains(dataInfo._ID) && dataInfo.gas.contains("OZONE") && !foundOzone)
                                {
                                    dataInfo.county = ozoneMonitorInfo.get(i).county;
                                    dataInfo.distanceToMe = ozoneMonitorInfo.get(i).distanceToMe;
                                    arrayDataInfo.add(dataInfo);
                                    foundOzone = true;
                                    Log.i("Found Ozone", "");
                                }
                            }
                        }

                        if (no2MonitorInfo.size() > 0)
                        {
                            for (int i = 0; i < no2MonitorInfo.size(); i++)
                            {
                                if (no2MonitorInfo.get(i)._ID.contains(dataInfo._ID) && dataInfo.gas.contains("NO2") && !foundNO2)
                                {
                                    dataInfo.county = no2MonitorInfo.get(i).county;
                                    dataInfo.distanceToMe = no2MonitorInfo.get(i).distanceToMe;
                                    arrayDataInfo.add(dataInfo);
                                    foundNO2 = true;
                                    Log.i("Found NO2", "");
                                }
                            }
                        }

                        if (pm25MonitorInfo.size() > 0)
                        {
                            for (int i = 0; i < pm25MonitorInfo.size(); i++)
                            {
                                if (pm25MonitorInfo.get(i)._ID.contains(dataInfo._ID) && dataInfo.gas.contains("PM2.5") && !foundPM25)
                                {
                                    dataInfo.county = pm25MonitorInfo.get(i).county;
                                    dataInfo.distanceToMe = pm25MonitorInfo.get(i).distanceToMe;
                                    arrayDataInfo.add(dataInfo);
                                    foundPM25 = true;
                                    Log.i("Found PM2.5", "");
                                }
                            }
                        }

                        if (tempMonitorInfo.size() > 0)
                        {
                            for (int i = 0; i < tempMonitorInfo.size(); i++ )
                            {
                                if (tempMonitorInfo.get(i)._ID.contains(dataInfo._ID) && dataInfo.gas.contains("TEMP") && !foundTemp)
                                {
                                    dataInfo.county = tempMonitorInfo.get(i).county;
                                    dataInfo.distanceToMe = tempMonitorInfo.get(i).distanceToMe;
                                    arrayDataInfo.add(dataInfo);
                                    foundTemp = true;
                                    Log.i("Found Temperature", "");
                                }
                            }
                        }

                        if (rhMonitorInfo.size() > 0)
                        {
                            for (int i = 0; i < rhMonitorInfo.size(); i++ )
                            {
                                if (rhMonitorInfo.get(i)._ID.contains(dataInfo._ID) && dataInfo.gas.contains("RHUM") && !foundRH)
                                {
                                    dataInfo.county = rhMonitorInfo.get(i).county;
                                    dataInfo.distanceToMe = rhMonitorInfo.get(i).distanceToMe;
                                    arrayDataInfo.add(dataInfo);
                                    foundRH = true;
                                    Log.i("Found RH", "");
                                }
                            }
                        }

                        if (pm10MonitorInfo.size() > 0)
                        {
                            for (int i = 0; i < pm10MonitorInfo.size(); i++)
                            {
                                if (pm10MonitorInfo.get(i)._ID.contains(dataInfo._ID) && dataInfo.gas.contains("PM10") && !foundPM10)
                                {
                                    dataInfo.county = pm10MonitorInfo.get(i).county;
                                    dataInfo.distanceToMe = pm10MonitorInfo.get(i).distanceToMe;
                                    arrayDataInfo.add(dataInfo);
                                    foundPM10 = true;
                                    Log.i("Found PM10", "");
                                }
                            }
                        }

                        arrayIndexCounter += 1;
                    }//read line

                }//

                if (arrayTmpDataInfo.size() > 0)
                {
                    arrayTmpDataInfo.clear();
                }
                arrayTmpDataInfo = arrayDataInfo;

                bReadHourlyDataFail = true;

                reader.close();
                input.close();


            } catch (Exception e) {
                Log.e("Error: ", e.getMessage());
                bReadHourlyDataFail = true;
            }

        }


    }

    void getHourlyDataInfo()
    {
        boolean foundCO = false;
        boolean foundOzone = false;
        boolean foundNO2 = false;
        boolean foundPM25 = false;
        boolean foundPM10 = false;
        boolean foundTemp = false;
        boolean foundRH = false;
        while(!foundCO || !foundOzone || !foundNO2 || !foundPM25 || !foundPM10 || !foundTemp || !foundRH)
        {
            for (int j = 0; j < arrayMonitoInfo.size(); j++)
            {
                String line = "";
                DataInfo dataInfo = new DataInfo();
                line = arrayMonitoInfo.get(j);
                String[] strS = line.split("\\|");

                if(!strS[0].isEmpty()){ //ID
                    String _ID  = strS[0];
                    // print("data ID:\(_ID)")
                    dataInfo._ID = _ID;
                }

                if(!strS[1].isEmpty()){ //gas
                    String gas  = strS[1];
                    //print("data gas:\(gas)")
                    dataInfo.gas = gas;
                }

                if(!strS[2].isEmpty()){ //value
                    String v  = strS[2];
                    //print("data value:\(v)")
                    dataInfo.gasValue = v;
                }



                if(!strS[6].isEmpty()){ //unit
                    String unit  = strS[6];
                    //print("data unit:\(unit)")
                    dataInfo.unit = unit;
                }

                if(!strS[3].isEmpty()){ //city
                    String city  = strS[3];
                    //print("data city:\(city)")
                    dataInfo.city = city;
                }

                if (coMonitorInfo.size()>0)
                {
                    for (int i = 0; i < coMonitorInfo.size(); i++ )
                    {
                        if (coMonitorInfo.get(i)._ID.contains(dataInfo._ID) && dataInfo.gas.contains("CO") && !foundCO)
                        {
                            dataInfo.county = coMonitorInfo.get(i).county;
                            dataInfo.distanceToMe = coMonitorInfo.get(i).distanceToMe;
                            arrayDataInfo.add(dataInfo);
                            foundCO = true;
                            Log.i("Found CO", "");
                        }
                    }
                }

                if (ozoneMonitorInfo.size() > 0)
                {
                    for (int i = 0; i < ozoneMonitorInfo.size(); i++)
                    {
                        if (ozoneMonitorInfo.get(i)._ID.contains(dataInfo._ID) && dataInfo.gas.contains("O3") && !foundOzone)
                        {
                            dataInfo.county = ozoneMonitorInfo.get(i).county;
                            dataInfo.distanceToMe = ozoneMonitorInfo.get(i).distanceToMe;
                            arrayDataInfo.add(dataInfo);
                            foundOzone = true;
                            Log.i("Found Ozone", "");
                        }
                    }
                }

                if (no2MonitorInfo.size() > 0)
                {
                    for (int i = 0; i < no2MonitorInfo.size(); i++)
                    {
                        if (no2MonitorInfo.get(i)._ID.contains(dataInfo._ID) && dataInfo.gas.contains("NO2") && !foundNO2)
                        {
                            dataInfo.county = no2MonitorInfo.get(i).county;
                            dataInfo.distanceToMe = no2MonitorInfo.get(i).distanceToMe;
                            arrayDataInfo.add(dataInfo);
                            foundNO2 = true;
                            Log.i("Found NO2", "");
                        }
                    }
                }

                if (pm25MonitorInfo.size() > 0)
                {
                    for (int i = 0; i < pm25MonitorInfo.size(); i++)
                    {
                        if (pm25MonitorInfo.get(i)._ID.contains(dataInfo._ID) && dataInfo.gas.contains("PM2.5") && !foundPM25)
                        {
                            dataInfo.county = pm25MonitorInfo.get(i).county;
                            dataInfo.distanceToMe = pm25MonitorInfo.get(i).distanceToMe;
                            arrayDataInfo.add(dataInfo);
                            foundPM25 = true;
                            Log.i("Found PM2.5", "");
                        }
                    }
                }

                if (tempMonitorInfo.size() > 0)
                {
                    for (int i = 0; i < tempMonitorInfo.size(); i++ )
                    {
                        if (tempMonitorInfo.get(i)._ID.contains(dataInfo._ID) && dataInfo.gas.contains("TEMP") && !foundTemp)
                        {
                            dataInfo.county = tempMonitorInfo.get(i).county;
                            dataInfo.distanceToMe = tempMonitorInfo.get(i).distanceToMe;
                            arrayDataInfo.add(dataInfo);
                            foundTemp = true;
                            Log.i("Found Temperature", "");
                        }
                    }
                }

                if (rhMonitorInfo.size() > 0)
                {
                    for (int i = 0; i < rhMonitorInfo.size(); i++ )
                    {
                        if (rhMonitorInfo.get(i)._ID.contains(dataInfo._ID) && dataInfo.gas.contains("RHUM") && !foundRH)
                        {
                            dataInfo.county = rhMonitorInfo.get(i).county;
                            dataInfo.distanceToMe = rhMonitorInfo.get(i).distanceToMe;
                            arrayDataInfo.add(dataInfo);
                            foundRH = true;
                            Log.i("Found RH", "");
                        }
                    }
                }

                if (pm10MonitorInfo.size() > 0)
                {
                    for (int i = 0; i < pm10MonitorInfo.size(); i++)
                    {
                        if (pm10MonitorInfo.get(i)._ID.contains(dataInfo._ID) && dataInfo.gas.contains("PM10") && !foundPM10)
                        {
                            dataInfo.county = pm10MonitorInfo.get(i).county;
                            dataInfo.distanceToMe = pm10MonitorInfo.get(i).distanceToMe;
                            arrayDataInfo.add(dataInfo);
                            foundPM10 = true;
                            Log.i("Found PM10", "");
                        }
                    }
                }
//                if (arrayTmpDataInfo.size() > 0)
//                {
//                    arrayTmpDataInfo.clear();
//                }
//                for (int i = 0; i < arrayDataInfo.size(); i++)
//                {
//                    arrayTmpDataInfo.add(arrayDataInfo.get(i));
//                }

            }

        }



    }



    void closestLocationArray(ArrayList<MonitorInfo> localArr)
    {
        if (localArr.size() == 0)
        {
            return;
        }
        Location location = new Location("");
        location.setLatitude(Go3TreksConstants.myCurrentLatitude);
        location.setLongitude(Go3TreksConstants.myCurrentLongitude);
        //determine distance to me for each site
        for (int i = 0; i < localArr.size(); i++ )
        {
            //print("ID:\(localArr[i]._ID), )city:\(localArr[i].city), state:\(localArr[i].state), gas:\(localArr[i].gas)\n");
            Location dicLocation = new Location("");
            dicLocation.setLatitude(Double.parseDouble(localArr.get(i).lat));
            dicLocation.setLongitude(Double.parseDouble(localArr.get(i).longi));
            float tmpDistanceBetween = dicLocation.distanceTo(location);
            localArr.get(i).distanceToMe = tmpDistanceBetween / 1609.34;
        }

//        Collections.sort(localArr.get(0));
//        localArr.sort($0.distanceToMe < $1.distanceToMe); //.sort {$0.distanceToMe < $1.distanceToMe }

        //print("For gas: \(localArr[0].gas), the closest location to me is: \(localArr[0]._ID) which is in \(localArr[0].county)\n")

    }

    String getUTCHour()
    {
        SimpleDateFormat sdf = new SimpleDateFormat("HH");
        String currentDate = sdf.format(new Date());
        return currentDate;
    }

    String getDateFilePath()
    {
        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyyMdd");
        String currentDateString = dateFormatter.format(new Date());
        return currentDateString;
    }

}
