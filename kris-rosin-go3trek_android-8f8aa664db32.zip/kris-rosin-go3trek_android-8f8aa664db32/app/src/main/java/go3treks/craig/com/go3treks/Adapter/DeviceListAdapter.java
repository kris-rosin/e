package go3treks.craig.com.go3treks.Adapter;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.content.LocalBroadcastManager;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.List;

import go3treks.craig.com.go3treks.Manager.GTKBleDeviceManager;
import go3treks.craig.com.go3treks.Manager.GTKGlobal;
import go3treks.craig.com.go3treks.Manager.Go3TreksConstants;
import go3treks.craig.com.go3treks.R;
import go3treks.craig.com.go3treks.model.GTKBlueDeviceData;

public class DeviceListAdapter  extends BaseAdapter {
    private LayoutInflater mInflater;
    private List<BluetoothDevice> mData;
    private OnItemsClickListener mListener;

    private float rW = 0;
    private float rH = 0;

    private float rX;
    private float rY;

    public DeviceListAdapter(Context context, float ww, float hh) {
        mInflater = LayoutInflater.from(context);
        rW = ww;
        rH = hh;

        rX = Go3TreksConstants.getRX(rW);
        rY = Go3TreksConstants.getRY(rH);
    }

    public void setData(List<BluetoothDevice> data) {
        mData = data;
    }

    public void setListener(OnItemsClickListener listener) {
        mListener = listener;
    }

    public int getCount() {
        return (mData == null) ? 0 : mData.size();
    }

    public Object getItem(int position) {
        return null;
    }

    public long getItemId(int position) {
        return position;
    }

    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;

        if (convertView == null) {
            convertView			=  mInflater.inflate(R.layout.list_item_device, null);

            holder 				= new ViewHolder();

            holder.nameText		= (TextView) convertView.findViewById(R.id.textView_ble_list_name);
            holder.checkItem    = (CheckBox) convertView.findViewById(R.id.checkBox_ble_list_check);

            int nListViewW = (int)rW/3*2 - (int)(50*rX);
            int nListViewH = (int)(40*rY);
            holder.nameText.setX(50*rX);
            holder.nameText.setY(10*rY);
            RelativeLayout.LayoutParams parmsListView = new RelativeLayout.LayoutParams(nListViewW, nListViewH);
            holder.nameText.setLayoutParams(parmsListView);

            holder.checkItem.setY(5*rY);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        final BluetoothDevice device	= mData.get(position);
        String strName = device.getName();
        if (strName == null)
        {
            strName = String.format("Treks-%s", Go3TreksConstants.g_DeviceID);
        }
        else
        {
            strName = device.getName();
        }
        holder.nameText.setText(strName);
//        holder.addressTv.setText(device.getAddress());
//        holder.pairBtn.setText((device.getBondState() == BluetoothDevice.BOND_BONDED) ? "Unpair" : "Pair");
        holder.nameText.setClickable(true);
        holder.nameText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mListener != null) {
                    mListener.onItemClick(position);
                    holder.checkItem.setChecked(!holder.checkItem.isChecked());

                    if (holder.checkItem.isChecked())
                    {
                        GTKBlueDeviceData data = new GTKBlueDeviceData();
                        data.strDeviceName = holder.nameText.getText().toString();
                        data.periperal = device;
                        GTKBleDeviceManager.arrayDevices.add(data);
                    }
                    else
                    {
                        for (int i = 0; i < GTKBleDeviceManager.arrayDevices.size(); i++)
                        {
                            GTKBlueDeviceData data = GTKBleDeviceManager.arrayDevices.get(i);
                            String strAddress1 = data.periperal.getAddress();
                            String strAddress2 = device.getAddress();
                            if (strAddress1.contentEquals(strAddress2))
                            {
                                GTKBleDeviceManager.arrayDevices.remove(i);
                            }
                        }
                    }

                    Intent intent = new Intent(GTKGlobal.kNotificationReSelectDevice);
                    LocalBroadcastManager.getInstance(mInflater.getContext()).sendBroadcast(intent);

                }
            }
        });

        holder.checkItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mListener != null) {
                    mListener.onItemClick(position);
                    if (holder.checkItem.isChecked())
                    {
                        holder.checkItem.setChecked(true);
                    }
                    else
                    {
                        holder.checkItem.setChecked(false);
                    }

                    if (holder.checkItem.isChecked())
                    {
                        GTKBlueDeviceData data = new GTKBlueDeviceData();
                        data.strDeviceName = holder.nameText.getText().toString();
                        data.periperal = device;
                        GTKBleDeviceManager.arrayDevices.add(data);
                    }
                    else
                    {
                        for (int i = 0; i < GTKBleDeviceManager.arrayDevices.size(); i++)
                        {
                            GTKBlueDeviceData data = GTKBleDeviceManager.arrayDevices.get(i);
                            String strAddress1 = data.periperal.getAddress();
                            String strAddress2 = device.getAddress();
                            if (strAddress1.contentEquals(strAddress2))
                            {
                                GTKBleDeviceManager.arrayDevices.remove(i);
                            }
                        }
                    }

                    Intent intent = new Intent(GTKGlobal.kNotificationReSelectDevice);
                    LocalBroadcastManager.getInstance(mInflater.getContext()).sendBroadcast(intent);

                }
            }
        });

        return convertView;
    }

    static class ViewHolder {
        TextView nameText;
        CheckBox checkItem;
    }

    public interface OnItemsClickListener {
        public abstract void onItemClick(int position);
    }
}
