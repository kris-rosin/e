package go3treks.craig.com.go3treks.Manager;

import java.util.ArrayList;

import go3treks.craig.com.go3treks.model.GTKBlueDeviceData;

/**
 * Created by osc_mac on 12/2/16.
 */

public class GTKBleDeviceManager {

    public static ArrayList<GTKBlueDeviceData> arrayDevices = new ArrayList<GTKBlueDeviceData>();
    public static int nDeviceCounts = 0;
    public static Boolean didDevicesAppear = false;

    public static GTKBleDeviceManager shard = new GTKBleDeviceManager();
    public GTKBleDeviceManager(){

    }

    public static int getDevicesCount()
    {
        nDeviceCounts = arrayDevices.size();
        return nDeviceCounts;
    }

    public static void removeDevicesArray()
    {
        arrayDevices.clear();
    }
}
