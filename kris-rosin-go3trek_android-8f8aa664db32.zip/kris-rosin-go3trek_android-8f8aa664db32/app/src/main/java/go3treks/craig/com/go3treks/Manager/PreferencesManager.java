package go3treks.craig.com.go3treks.Manager;

/**
 * Created by osc_mac on 10/25/16.
 */
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;


public class PreferencesManager {

    public static final String PREF_IS_FIRST_TIME           = "PREF_IS_FIRST_TIME";
    public static final String PREF_IS_AGREED_TO_EULA       = "PREF_IS_AGREED_TO_EULA";

    private static final String PREF_AUTH_TOKEN        = "Auth_token";
    private static final String PREF_IS_COUNTRY_LOADED = "is_country_loaded";


    public static boolean contains(final Context context, final String key) {
        final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        return preferences.contains(key);
    }

    /**
     * Get String value for a particular key.
     *
     * @param context
     * @param key
     * @return String value that was stored earlier, or empty string if no
     *         mapping exists
     */
    public static String getString(final Context context, final String key) {

        return getString(context, key, Go3TreksConstants.EMPTY);
    }

    /**
     * Get String value for a particular key.
     *
     * @param context
     * @param key
     * @param defValue
     *            The default value to return
     * @return String value that was stored earlier, or the supplied default
     *         value if no mapping exists
     */
    public static String getString(final Context context, final String key, final String defValue) {

        final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        return preferences.getString(key, defValue);
    }

    /**
     * Get int value for key.
     *
     * @param context
     * @param key
     * @return value or 0 if no mapping exists
     */
    public static int getInt(final Context context, final String key) {

        return getInt(context, key, 0);
    }

    /**
     * Get int value for key.
     *
     * @param context
     * @param key
     * @param defValue
     *            The default value
     * @return value or defValue if no mapping exists
     */
    public static int getInt(final Context context, final String key, final int defValue) {

        final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        return preferences.getInt(key, defValue);
    }

    /**
     * Get float value for a particular key.
     *
     * @param context
     * @param key
     * @return value or 0.0 if no mapping exists
     */
    public static float getFloat(final Context context, final String key) {

        return getFloat(context, key, 0.0f);

    }

    /**
     * Get float value for a particular key.
     *
     * @param context
     * @param key
     * @param defValue
     * @return value or defValue if no mapping exists
     */
    public static float getFloat(final Context context, final String key, final float defValue) {

        final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        return preferences.getFloat(key, defValue);

    }

    /**
     * Get long value for a particular key.
     *
     * @param context
     * @param key
     * @return value or 0 if no mapping exists
     */
    public static long getLong(final Context context, final String key) {

        return getLong(context, key, 0L);
    }

    /**
     * Get long value for a particular key.
     *
     * @param context
     * @param key
     * @param defValue
     * @return value or defValue if no mapping exists
     */
    public static long getLong(final Context context, final String key, final long defValue) {

        final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        return preferences.getLong(key, defValue);
    }

    /**
     * Get boolean value for a particular key.
     *
     * @param context
     * @param key
     * @return value or false if no mapping exists
     */
    public static boolean getBoolean(final Context context, final String key) {

        return getBoolean(context, key, false);
    }

    /**
     * Get boolean value for a particular key.
     *
     * @param context
     * @param key
     * @param defValue
     * @return value or defValue if no mapping exists
     */
    public static boolean getBoolean(final Context context, final String key, final boolean defValue) {

        final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        return preferences.getBoolean(key, defValue);
    }

    /**
     * Set String value for a particular key. Convert non-Strings to appropriate
     * Strings before storing.
     *
     * @param context
     * @param key
     * @param value
     */
    public static void set(final Context context, final String key, final String value) {

        final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        final SharedPreferences.Editor editor = preferences.edit();
        editor.putString(key, value);
        editor.apply();
    }

    /**
     * Set int value for key.
     *
     * @param context
     * @param key
     * @param value
     */
    public static void set(final Context context, final String key, final int value) {

        final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        final SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(key, value);
        editor.apply();
    }

    /**
     * Set float value for a key.
     *
     * @param context
     * @param key
     * @param value
     */
    public static void set(final Context context, final String key, final float value) {

        final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        final SharedPreferences.Editor editor = preferences.edit();

        editor.putFloat(key, value);
        editor.apply();
    }

    /**
     * Set long value for key.
     *
     * @param context
     * @param key
     * @param value
     */
    public static void set(final Context context, final String key, final long value) {

        final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        final SharedPreferences.Editor editor = preferences.edit();
        editor.putLong(key, value);
        editor.apply();
    }

    /**
     * Set boolean value for key.
     *
     * @param context
     * @param key
     * @param value
     */
    public static void set(final Context context, final String key, final boolean value) {

        final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        final SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(key, value);
        editor.apply();
    }

    /**
     * Clear all preferences.
     *
     * @param context
     */
    public static void clearPreferences(final Context context) {

        final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        boolean isFirstTime = preferences.getBoolean(PREF_IS_FIRST_TIME, true);
        boolean isAgreedToEula = preferences.getBoolean(PREF_IS_AGREED_TO_EULA, false);
        final SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
//        TODO move all preferences except these two in another file
        editor.putBoolean(PREF_IS_FIRST_TIME, isFirstTime)
                .putBoolean(PREF_IS_AGREED_TO_EULA, isAgreedToEula);
        editor.apply();
    }

    @Nullable
    public static String getAuthToken(Context ctx) {
        return PreferenceManager.getDefaultSharedPreferences(ctx).getString(PREF_AUTH_TOKEN, null);
    }

    public static void setAuthToken(Context ctx, String authToken) {
        PreferenceManager.getDefaultSharedPreferences(ctx).edit()
                .putString(PREF_AUTH_TOKEN, authToken)
                .apply();
    }

    public static boolean isCountriesLoaded(Context ctx){
        return PreferenceManager.getDefaultSharedPreferences(ctx).getBoolean(PREF_IS_COUNTRY_LOADED, false);
    }

    public static void setIsCountriesLoaded(Context ctx, boolean isLoaded){
        PreferenceManager.getDefaultSharedPreferences(ctx).edit()
                .putBoolean(PREF_IS_COUNTRY_LOADED, isLoaded)
                .apply();
    }
}
