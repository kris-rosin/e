package go3treks.craig.com.go3treks.Manager;

/**
 * Created by osc_mac on 10/25/16.
 */
public class Go3TreksConstants {


    private Go3TreksConstants() {
        // This prevents the native class from calling this constructor as well
        throw new AssertionError();
    }

    public static final String  EMPTY                      = "";

    public static final float g_FixedWindowWidth = 480.0f;
    public  static  final  float g_FixedWindowHeight = 854.0f;

    public static final float g_rX = 0.0f;
    public static final float g_rY = 0.0f;

    public static boolean bFoindingEPASite = true;
    public static boolean bFoundBLEDevice = false;
    public static boolean isEnableBLE = false;
    public static boolean bHadErroe = false;
    public static boolean bReadMonitoFile = false;
    public static boolean bReadMonitoFileFail = true;

    public static double myCurrentLongitude = 0;
    public static double myCurrentLatitude = 0;

    public static String g_nearEPASite = "";
    public static String g_nearMile = "";
    public static String g_SiteLat = "";
    public static String g_SiteLong = "";

    public static String g_DeviceID = "";

    public  static  boolean bBleSkip = false;


    public static float getRX(float tmp)
    {
        return tmp / g_FixedWindowWidth;
    }

    public static float getRY(float tmp)
    {
        return tmp / g_FixedWindowHeight;
    }
}
