package go3treks.craig.com.go3treks.Activitys;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.annotation.RequiresApi;
import android.support.design.widget.TabLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.ViewPager;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import go3treks.craig.com.go3treks.*;
import go3treks.craig.com.go3treks.Adapter.DeviceListAdapter;
import go3treks.craig.com.go3treks.Adapter.PagerAdapter;
import go3treks.craig.com.go3treks.Manager.DownloadConntectURL;
import go3treks.craig.com.go3treks.Manager.DownloadFileFromURL;
import go3treks.craig.com.go3treks.Manager.GTKBleDeviceManager;
import go3treks.craig.com.go3treks.Manager.GTKGlobal;
import go3treks.craig.com.go3treks.Manager.Go3TreksConstants;
import go3treks.craig.com.go3treks.model.BLEPacket;
import go3treks.craig.com.go3treks.model.GTKBlueDeviceData;

@RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
public class MainMenuActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener,
        LocationListener {

    String download_monitor_file_path = "https://s3-us-west-1.amazonaws.com//files.airnowtech.org/airnow/today/monitoring_site_locations.dat";
    private Handler handler = new Handler();

    // The minimum distance to change Updates in meters
    private static final long MIN_DISTANCE_CHANGE_FOR_UPDATES = 1;

    // The minimum time between updates in milliseconds
    private static final long MIN_TIME_BW_UPDATES = 1;

    private float rWindowW = 0;
    private float rWindowH = 0;

    public float rX;
    public float rY;

    private DeviceListAdapter mAdapter;

    private BluetoothAdapter mBluetoothAdapter;
    private int REQUEST_ENABLE_BT = 1;
    private BluetoothLeScanner mLEScanner;
    private ScanSettings settings;
    private List<ScanFilter> filters;
    private BluetoothGatt mGatt;

    int nIndexStart = 0;
    int nIndexRedrawG = 0;

    int nRuntime = 0;

    LocationManager locationManager;

    Location locationMyDevice = new Location("");

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main_menu);

        setTitle("Home");

        getWindow().getDecorView().setBackgroundColor(Color.WHITE);

        Display display = getWindowManager().getDefaultDisplay();
        rWindowW = display.getWidth();
        rWindowH = display.getHeight();

        rX = Go3TreksConstants.getRX(rWindowW);
        rY = Go3TreksConstants.getRY(rWindowH);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setBackground(getResources().getDrawable(R.drawable.bar));
        setSupportActionBar(toolbar);

//        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        TabLayout tabLayout = (TabLayout) findViewById(R.id.tab_layout);
        tabLayout.addTab(tabLayout.newTab().setIcon(getResources().getDrawable(R.drawable.mainmenu_home_icon)));
        if (Go3TreksConstants.bBleSkip == false)
        {
            tabLayout.addTab(tabLayout.newTab().setIcon(getResources().getDrawable(R.drawable.mainmenu_graph_icon)));
            tabLayout.addTab(tabLayout.newTab().setIcon(getResources().getDrawable(R.drawable.mainmenu_map_icon)));
        }

        tabLayout.addTab(tabLayout.newTab().setIcon(getResources().getDrawable(R.drawable.mainmenu_status_icon)));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        final ViewPager viewPager = (ViewPager) findViewById(R.id.pager);
        final PagerAdapter adapter = new PagerAdapter
                (getSupportFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
                int n = tab.getPosition();
                if (n == 0) {
                    setTitle("Home");
                }
                if (n == 1)
                {
                    setTitle("Graph");
                }
                if (n==2)
                {
                    setTitle("Map");
                }
                if (n==3)
                {
                    setTitle("Status");
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        checkBTState();
        mBluetoothAdapter.startDiscovery();

        redrawGraphic();
        Timer timer = new Timer();
        TimerTask mainTimerTask = new TimerTask() {
            @Override
            public void run() {
                calculateRuntime();
            }
        };
        timer.schedule(mainTimerTask, 0, 20000); //execute in every 15s

        locationMyDevice = getLocation();


        new Thread(new Runnable() {
            @Override
            public void run() {

                while(nRuntime != -1)
                {
                    if (nRuntime == 0)
                    {
                        redrawGraphic();
                        nRuntime = 1;
                    }

                }

            }
        }).start();

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {

        } else if (id == R.id.nav_epa) {

            Intent mainIntent = new Intent(MainMenuActivity.this, EPALocationActivity.class);
            MainMenuActivity.this.startActivity(mainIntent);
            MainMenuActivity.this.finish();

        } else if (id == R.id.nav_ble) {

            Intent mainIntent = new Intent(MainMenuActivity.this, BLEDeviceActivity.class);
            MainMenuActivity.this.startActivity(mainIntent);
            MainMenuActivity.this.finish();

        }else if (id == R.id.nav_logout) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        } else {
            if (Build.VERSION.SDK_INT >= 21) {
                mLEScanner = mBluetoothAdapter.getBluetoothLeScanner();
                settings = new ScanSettings.Builder()
                        .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                        .build();
                filters = new ArrayList<ScanFilter>();
            }
            scanLeDevice(true);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mBluetoothAdapter != null && mBluetoothAdapter.isEnabled()) {
            scanLeDevice(false);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mGatt == null) {
            return;
        }
        mGatt.close();
        mGatt = null;

        scanLeDevice(false);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == Activity.RESULT_CANCELED) {
                //Bluetooth not enabled.
                checkBTState();
                return;
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void scanLeDevice(final boolean enable) {
        if (enable) {
            if (Build.VERSION.SDK_INT < 21) {
                mBluetoothAdapter.startLeScan(mLeScanCallback);
            } else {
                mLEScanner.startScan(filters, settings, mScanCallback);
            }
        } else {
            if (Build.VERSION.SDK_INT < 21) {
                mBluetoothAdapter.stopLeScan(mLeScanCallback);
            } else {
                mLEScanner.stopScan(mScanCallback);
            }
        }
    }

    private ScanCallback mScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            Log.i("callbackType", String.valueOf(callbackType));
            Log.i("result", result.toString());
            BluetoothDevice btDevice = result.getDevice();

            ScanRecord scanRecord = result.getScanRecord();
            byte[] scanByte = scanRecord.getBytes();

            String strName = btDevice.getName();
            String strAdress = btDevice.getAddress();

            String strPacket = null;
            try {
                strPacket = new String(scanByte, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            connectToDevice(btDevice);

            int nIndex = strPacket.indexOf("$");
            String strSub = strPacket.substring(0, 6);
            Boolean bContain = strSub.contains("$");
            if (bContain == true)
            {
                if (GTKBleDeviceManager.getDevicesCount() > 0)
                {
                    for (int i = 0; i < GTKBleDeviceManager.getDevicesCount(); i++)
                    {
                        GTKBlueDeviceData deviceData = GTKBleDeviceManager.arrayDevices.get(i);
                        if (deviceData.periperal.getAddress().contentEquals(strAdress))
                        {
                            deviceData.periperal = btDevice;

                            if (deviceData.isTreking == false)
                            {
                                deviceData.strStartTrekTime = getCurrentTime();
                                deviceData.isTreking = true;
                            }

                            String separatedStrings[] = strPacket.split("\\|");
                            int arraySize = separatedStrings.length - 1;

                            String strDeviceID = "";
                            String strPacketNumber = "";
                            String strMeasurementName = "";
                            String strMeasurementValue = "";
                            String strMeasurementUnits = "";

                            if(!separatedStrings[0].isEmpty()){
                                String device  = separatedStrings[0];
                                strDeviceID = device;
                            }
                            if(!separatedStrings[1].isEmpty()){
                                String packetNumber = separatedStrings[1];
                                strPacketNumber = packetNumber;
                            }
                            if(!separatedStrings[2].isEmpty()){
                                String measurementName = separatedStrings[2];
                                strMeasurementName = measurementName;
                            }
                            if(!separatedStrings[3].isEmpty()){
                                String measurementValue = separatedStrings[3];
                                strMeasurementValue = measurementValue;
                            }
                            if(!separatedStrings[4].isEmpty()){
                                String measurementUnits = separatedStrings[4];
                                strMeasurementUnits = measurementUnits;
                            }

                            boolean bFoundName = false;
                            if (deviceData.blePackets.size() > 0)
                            {
                                for (int j = 0; j < deviceData.blePackets.size(); j++ )
                                {
                                    BLEPacket bleP = deviceData.blePackets.get(j);
                                    if (strMeasurementName.contentEquals(bleP.name))
                                    {
                                        while (bleP._indexPoint < nIndexRedrawG)
                                        {
                                            (bleP._ID).add(strDeviceID);
                                            (bleP._num).add(strPacketNumber);

                                            Double values = Double.parseDouble(strMeasurementValue);
                                            if (values.isNaN()) //in case string
                                            {
                                                (bleP._valueString).add(strMeasurementValue);
                                                bleP.isString = true;
                                            }
                                            else
                                            {
                                                (bleP._value).add(values);
                                            }

                                            bleP._units = strMeasurementUnits;

                                            bleP._indexPoint += 1;
                                        }

                                        bFoundName = true;

                                        break;
                                    }
                                }

                            }

                            if (bFoundName == false)
                            {
                                BLEPacket bleP = new BLEPacket();
                                bleP._ID.add(strDeviceID);
                                bleP._num.add(strPacketNumber);
                                bleP.name = strMeasurementName;
                                Double values = Double.parseDouble(strMeasurementValue);
                                if (values.isNaN()) //in case string
                                {
                                    bleP._valueString.add(strMeasurementValue);
                                    bleP.isString = true;
                                }
                                else
                                {
                                    bleP._value.add(values);
                                }

                                bleP._units = strMeasurementUnits;

                                deviceData.blePackets.add(bleP);
                            }

                            while (deviceData.nIndexLocation < nIndexRedrawG)
                            {
                                deviceData.latMyDevice.add(locationMyDevice.getLatitude());
                                deviceData.lonMyDevice.add(locationMyDevice.getLongitude());
                                deviceData.nIndexLocation += 1;
                            }
                        }
                    }
                }

            }
        }

        @Override
        public void onBatchScanResults(List<ScanResult> results) {
            for (ScanResult sr : results) {
                Log.i("ScanResult - Results", sr.toString());
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            Log.e("Scan Failed", "Error Code: " + errorCode);
        }
    };

    private BluetoothAdapter.LeScanCallback mLeScanCallback =
            new BluetoothAdapter.LeScanCallback() {
                @Override
                public void onLeScan(final BluetoothDevice device, int rssi,
                                     final byte[] scanRecord) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Log.i("onLeScan", device.toString());

                            String strName = device.getName();
                            String strAdress = device.getAddress();

                            String s = null;
                            try {
                                s = new String(scanRecord, "UTF-8");
                            } catch (UnsupportedEncodingException e) {
                                e.printStackTrace();
                            }
                            connectToDevice(device);

                            int nIndex = s.indexOf("$");
                            String strSub = s.substring(0, 6);
                            Boolean bContain = strSub.contains("$");
                            if (bContain == true)
                            {

                                if (GTKBleDeviceManager.getDevicesCount() > 0)
                                {
                                    for (int i = 0; i < GTKBleDeviceManager.getDevicesCount(); i++)
                                    {
                                        GTKBlueDeviceData deviceData = GTKBleDeviceManager.arrayDevices.get(i);
                                        if (deviceData.periperal.getAddress().contentEquals(strAdress))
                                        {
                                            deviceData.periperal = device;

                                            if (deviceData.isTreking == false)
                                            {
                                                deviceData.strStartTrekTime = getCurrentTime();
                                                deviceData.isTreking = true;
                                            }

                                            String separatedStrings[] = s.split("\\|");
                                            int arraySize = separatedStrings.length;

                                            String strDeviceID = "";
                                            String strPacketNumber = "";
                                            String strMeasurementName = "";
                                            String strMeasurementValue = "";
                                            String strMeasurementUnits = "";

                                            if(!separatedStrings[0].isEmpty()){
                                                String device  = separatedStrings[0];
                                                strDeviceID = device;
                                            }
                                            if(!separatedStrings[1].isEmpty()){
                                                String packetNumber = separatedStrings[1];
                                                strPacketNumber = packetNumber;
                                            }
                                            if(!separatedStrings[2].isEmpty()){
                                                String measurementName = separatedStrings[2];
                                                strMeasurementName = measurementName;
                                            }
                                            if(!separatedStrings[3].isEmpty()){
                                                String measurementValue = separatedStrings[3];
                                                strMeasurementValue = measurementValue;
                                            }
                                            if(arraySize==4){
                                                if(!separatedStrings[4].isEmpty()){
                                                    String measurementUnits = separatedStrings[4];
                                                    strMeasurementUnits = measurementUnits;
                                                }
                                            }

                                            boolean bFoundName = false;
                                            if (deviceData.blePackets.size() > 0)
                                            {
                                                for (int j = 0; j < deviceData.blePackets.size(); j++ )
                                                {
                                                    BLEPacket bleP = deviceData.blePackets.get(j);
                                                    if (strMeasurementName.contentEquals(bleP.name))
                                                    {
                                                        while (bleP._indexPoint < nIndexRedrawG)
                                                        {
                                                            (bleP._ID).add(strDeviceID);
                                                            (bleP._num).add(strPacketNumber);

                                                            Double values = Double.parseDouble(strMeasurementValue);
                                                            if (values.isNaN()) //in case string
                                                            {
                                                                (bleP._valueString).add(strMeasurementValue);
                                                                bleP.isString = true;
                                                            }
                                                            else
                                                            {
                                                                (bleP._value).add(values);
                                                            }

                                                            bleP._units = strMeasurementUnits;

                                                            bleP._indexPoint += 1;
                                                        }

                                                        bFoundName = true;

                                                        break;
                                                    }
                                                }

                                            }

                                            if (bFoundName == false)
                                            {
                                                BLEPacket bleP = new BLEPacket();
                                                bleP._ID.add(strDeviceID);
                                                bleP._num.add(strPacketNumber);
                                                bleP.name = strMeasurementName;
                                                Double values = Double.parseDouble(strMeasurementValue);
                                                if (values.isNaN()) //in case string
                                                {
                                                    bleP._valueString.add(strMeasurementValue);
                                                    bleP.isString = true;
                                                }
                                                else
                                                {
                                                    bleP._value.add(values);
                                                }

                                                bleP._units = strMeasurementUnits;

                                                deviceData.blePackets.add(bleP);
                                            }

                                            while (deviceData.nIndexLocation < nIndexRedrawG)
                                            {
                                                deviceData.latMyDevice.add(locationMyDevice.getLatitude());
                                                deviceData.lonMyDevice.add(locationMyDevice.getLongitude());
                                                deviceData.nIndexLocation += 1;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    });
                }
            };

    public void connectToDevice(BluetoothDevice device) {
        if (mGatt == null) {
            mGatt = device.connectGatt(this, false, gattCallback);
            scanLeDevice(true);
        }
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            Log.i("onConnectionStateChange", "Status: " + status);
            switch (newState) {
                case BluetoothProfile.STATE_CONNECTED:
                    Log.i("gattCallback", "STATE_CONNECTED");
                    gatt.discoverServices();
                    break;
                case BluetoothProfile.STATE_DISCONNECTED:
                    Log.e("gattCallback", "STATE_DISCONNECTED");
                    break;
                default:
                    Log.e("gattCallback", "STATE_OTHER");
            }

        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            List<BluetoothGattService> services = gatt.getServices();
            Log.i("onServicesDiscovered", services.toString());
            gatt.readCharacteristic(services.get(1).getCharacteristics().get
                    (0));
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic
                                                 characteristic, int status) {
            Log.i("onCharacteristicRead", characteristic.toString());
//            gatt.disconnect();
        }
    };

    private void checkBTState() {

        if(mBluetoothAdapter==null) {
            Toast.makeText(getBaseContext(), "Device does not support bluetooth", Toast.LENGTH_LONG).show();
        } else {
            if (mBluetoothAdapter.isEnabled()) {
                Go3TreksConstants.isEnableBLE = true;
            } else {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
        }
    }

    void redrawGraphic()
    {
        nIndexRedrawG += 1;
        GTKGlobal.g_nIndexRedrawG += 1;

        Intent intent = new Intent(GTKGlobal.kNotificationRedrawGrph);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);

        Intent intent1 = new Intent(GTKGlobal.kNotificationRedrawMap);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent1);
//
        Intent intent2 = new Intent(GTKGlobal.kNotificationResetStatus);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent2);
    }

    //location
    @Override
    public void onLocationChanged(Location location) {

        locationMyDevice = location;
        GTKGlobal.g_locationMyDevice = location;
        try {
            getAddressFromLocation(location.getLatitude(), location.getLongitude(), this);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }

    void getAddressFromLocation(final double latitude, final double longitude,
                                final Context context) throws IOException {
        Geocoder geocoder = new Geocoder(context, Locale.getDefault());
        String result = null;

        List<Address> addressList = geocoder.getFromLocation(
                latitude, longitude, 1);
        if (addressList.size() > 0) {
            Address address = addressList.get(0);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < address.getMaxAddressLineIndex(); i++) {
                sb.append(address.getAddressLine(i)).append("\n");
            }
            sb.append(address.getLocality()).append("\n");
            sb.append(address.getPostalCode()).append("\n");
            sb.append(address.getCountryName());
            result = sb.toString();

            String strCity = address.getLocality();
            if (strCity != null)
            {
                GTKGlobal.g_City = address.getLocality();
            }

            String strCountry = address.getCountryName();
            if (strCountry != null)
            {
                GTKGlobal.g_State = address.getCountryName();
            }

        }

    }

    public void showSettingsAlert() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);

        // Setting Dialog Title
        alertDialog.setTitle("GPS is settings");

        // Setting Dialog Message
        alertDialog
                .setMessage("GPS is not enabled. Do you want to go to settings menu?");

        // On pressing Settings button
        alertDialog.setPositiveButton("Settings",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(
                                Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivity(intent);
                    }
                });

        // on pressing cancel button
        alertDialog.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

        // Showing Alert Message
        alertDialog.show();
    }

    public Location getLocation()
    {
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        // getting GPS status
        Boolean isGPSEnabled = locationManager
                .isProviderEnabled(LocationManager.GPS_PROVIDER);

        Log.v("isGPSEnabled", "=" + isGPSEnabled);

        // getting network status
        Boolean isNetworkEnabled = locationManager
                .isProviderEnabled(LocationManager.NETWORK_PROVIDER);

        Log.v("isNetworkEnabled", "=" + isNetworkEnabled);

        if (isGPSEnabled == false && isNetworkEnabled == false) {
            // no network provider is enabled
            showSettingsAlert();
        } else {
            if (isNetworkEnabled) {
                locationMyDevice = null;
                if (ActivityCompat.checkSelfPermission(this,
                        Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                        ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return null;
                }
                locationManager.requestLocationUpdates(
                        LocationManager.NETWORK_PROVIDER,
                        MIN_TIME_BW_UPDATES,
                        MIN_DISTANCE_CHANGE_FOR_UPDATES, this);
                Log.d("Network", "Network");
                if (locationManager != null) {
                    locationMyDevice = locationManager
                            .getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                    if (locationMyDevice != null) {

                        return locationMyDevice;
                    }
                }
            }
            // if GPS Enabled get lat/long using GPS Services
            if (isGPSEnabled) {
                locationMyDevice = null;
                if (locationMyDevice == null) {
                    locationManager.requestLocationUpdates(
                            LocationManager.GPS_PROVIDER,
                            MIN_TIME_BW_UPDATES,
                            MIN_DISTANCE_CHANGE_FOR_UPDATES, this);
                    Log.d("GPS Enabled", "GPS Enabled");
                    if (locationManager != null) {
                        locationMyDevice = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                        if (locationMyDevice != null) {
                            return locationMyDevice;
                        }
                    }
                }
            }
        }
        return null;
    }

    private String getCurrentTime()
    {
        String date = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(new Date());
        return date;
    }

    public void calculateRuntime()
    {
        nRuntime = 0;
    }

}
