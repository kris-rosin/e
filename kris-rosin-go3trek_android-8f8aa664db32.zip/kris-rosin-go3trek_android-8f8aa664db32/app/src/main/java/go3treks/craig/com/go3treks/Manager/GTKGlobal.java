package go3treks.craig.com.go3treks.Manager;

import android.location.Location;

import java.util.ArrayList;

import go3treks.craig.com.go3treks.model.GTKBlueDeviceData;

public class GTKGlobal {

    public final static int G_HIGH_GRAPH = 180;

    public final static String kNotificationReSelectEPAs = "kNotificationReSelectEPAs";
    public final static String  kNotificationReSelectDevice = "kNotificationReSelectDevice";
    public final static String  kNotificationRedrawGrph = "kNotificationRedrawGrph";
    public final static String  kNotificationRedrawMap = "kNotificationRedrawMap";
    public final static String  kNotificationStep5 = "kNotificationStep5";
    public final static String  kNotificationResetStatus = "kNotificationResetStatus";
    public final static String  kNotificationProcessFtpData = "kNotificationProcessFtpData";

    public final static String  kNotificationSaveHistory = "kNotificationSaveHistory";
    public final static String  kNotificationHistoryGraph = "kNotificationHistoryGraph";
    public final static String  kNotificationHistoryMap = "kNotificationHistoryMap";
    public final static String  kNotificationHistoryUp = "kNotificationHistoryUp";

    public static ArrayList<Double> g_data = new ArrayList<Double>();
    public static int g_countFrame = 0;

    public static String g_City = "";
    public static String g_State = "";

    public static String g_nearEPASite = "";
    public static String g_nearMile = "";

    public static Location g_locationMyDevice = new Location("");

    public static int g_nIndexRedrawG = 0;

    public static boolean g_bSkipDevice = false;

    public static GTKBlueDeviceData[] g_arrayDeviceData;

    public static String[] g_arrayHistoryFile;

    public static String g_strHName = "";
    public static String g_strHStart = "";
    public static String g_strHEnd = "";
    public static String g_strHBId = "";
}
