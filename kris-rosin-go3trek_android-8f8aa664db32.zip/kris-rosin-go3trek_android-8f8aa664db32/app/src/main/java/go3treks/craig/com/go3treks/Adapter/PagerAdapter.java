package go3treks.craig.com.go3treks.Adapter;

/**
 * Created by osc_mac on 10/26/16.
 */

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import go3treks.craig.com.go3treks.Fragments.*;
import go3treks.craig.com.go3treks.Manager.Go3TreksConstants;

public class PagerAdapter extends FragmentStatePagerAdapter {
    int mNumOfTabs;

    public PagerAdapter(FragmentManager fm, int NumOfTabs) {
        super(fm);
        this.mNumOfTabs = NumOfTabs;
    }

    @Override
    public Fragment getItem(int position) {

        if (Go3TreksConstants.bBleSkip == false)
        {
            switch (position) {
                case 0:
                    HomeFragment tab1 = new HomeFragment();
                    return tab1;
                case 1:
                    GraphFragment tab2 = new GraphFragment();
                    return tab2;
                case 2:
                    MapFragment tab3 = new MapFragment();
                    return tab3;
                case 3:
                    StatusFragment tab4 = new StatusFragment();
                    return tab4;
                default:
                    return null;
            }
        }
        else
        {
            switch (position) {
                case 0:
                    HomeFragment tab1 = new HomeFragment();
                    return tab1;
                case 1:
                    StatusFragment tab2 = new StatusFragment();
                    return tab2;
                default:
                    return null;
            }
        }

    }

    @Override
    public int getCount() {
        return mNumOfTabs;
    }
}
