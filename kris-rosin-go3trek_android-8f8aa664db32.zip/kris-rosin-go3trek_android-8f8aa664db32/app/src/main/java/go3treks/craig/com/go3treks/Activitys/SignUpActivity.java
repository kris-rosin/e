package go3treks.craig.com.go3treks.Activitys;

import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import go3treks.craig.com.go3treks.*;
import go3treks.craig.com.go3treks.Manager.Go3TreksConstants;

public class SignUpActivity extends AppCompatActivity {


    private float rWindowW = 0;
    private float rWindowH = 0;

    public float rX;
    public float rY;

    Button btnSubmit;
    TextView textIHave;

    EditText editRetype;
    EditText editPass;
    EditText editUser;
    EditText editLast;
    EditText editFirst;


    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        Display display = getWindowManager().getDefaultDisplay();
        rWindowW = display.getWidth();
        rWindowH = display.getHeight();

        rX = Go3TreksConstants.getRX(rWindowW);
        rY = Go3TreksConstants.getRY(rWindowH);

        //Submit button
        btnSubmit = (Button)findViewById(R.id.button_signup_submit);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent mainIntent = new Intent(SignUpActivity.this, EPALocationActivity.class);
                SignUpActivity.this.startActivity(mainIntent);
                SignUpActivity.this.finish();
            }
        });
        int nBtnSubW = (int)rWindowW/3*2;
        int nBtnSubH = (int)(50*rY);
        btnSubmit.setX(rWindowW/2 - nBtnSubW/2);
        btnSubmit.setY(rWindowH - 100*rY - nBtnSubH);
        RelativeLayout.LayoutParams parmsBtnSubmit = new RelativeLayout.LayoutParams(nBtnSubW, nBtnSubH);
        btnSubmit.setLayoutParams(parmsBtnSubmit);

        //I have an account text
        textIHave = (TextView)this.findViewById(R.id.textview_signup_ihave);
        textIHave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mainIntent = new Intent(SignUpActivity.this, LogInActivity.class);
                SignUpActivity.this.startActivity(mainIntent);
                SignUpActivity.this.finish();
            }
        });
        int nTxtIW = (int)rWindowW/2;
        int nTxtIH = (int)(40*rY);
        textIHave.setX(rWindowW - nTxtIW - 30*rX);
        textIHave.setY(rWindowH - 50*rY - nTxtIH);
        RelativeLayout.LayoutParams parmsTxtSignup = new RelativeLayout.LayoutParams(nTxtIW, nTxtIH);
        textIHave.setLayoutParams(parmsTxtSignup);

        //retype password edit
        RelativeLayout relativeRetype = (RelativeLayout)findViewById(R.id.relative_signup_retypepass);
        int nRelativeRetypeW = (int)rWindowW/3*2;
        int nRelativeRetypeH = (int)(80*rY);
        relativeRetype.setX(rWindowW/2 - nRelativeRetypeW/2);
        relativeRetype.setY(btnSubmit.getY() - nRelativeRetypeH);
        RelativeLayout.LayoutParams parmsRelatRetype = new RelativeLayout.LayoutParams(nRelativeRetypeW, nRelativeRetypeH);
        relativeRetype.setLayoutParams(parmsRelatRetype);

        ImageView imgRetypeLine = (ImageView)findViewById(R.id.imageView_signup_retypepass_line);
        int nImgRetypeLineW = (int)(10*rX);
        int nImgRetypeLineH = (int)(40*rY);
        imgRetypeLine.setX(50*rX);
        imgRetypeLine.setY(20*rY);
        RelativeLayout.LayoutParams parmsImgRetypeLine = new RelativeLayout.LayoutParams(nImgRetypeLineW, nImgRetypeLineH);
        imgRetypeLine.setLayoutParams(parmsImgRetypeLine);


        ImageView imgRetypeIcon = (ImageView)findViewById(R.id.imageView_signup_retypepass_key);
        int nImgRetypeIconW = nRelativeRetypeH - (int)(40*rY);
        int nImgRetypeIconH = nRelativeRetypeH - (int)(40*rY);
        imgRetypeIcon.setX(10*rX);
        imgRetypeIcon.setY(20*rY);
        RelativeLayout.LayoutParams parmsImgRetypeIcon = new RelativeLayout.LayoutParams(nImgRetypeIconW, nImgRetypeIconH);
        imgRetypeIcon.setLayoutParams(parmsImgRetypeIcon);

        ImageView imgRetypeBk = (ImageView)findViewById(R.id.imageView_signup_retypepass_bk);
        int nImgRetypeBkW = nRelativeRetypeW;
        int nImgRetypeBkH = nRelativeRetypeH;
        imgRetypeBk.setX(0);
        imgRetypeBk.setY(0);
        RelativeLayout.LayoutParams parmsImgRetypeBk = new RelativeLayout.LayoutParams(nImgRetypeBkW, nImgRetypeBkH);
        imgRetypeBk.setLayoutParams(parmsImgRetypeBk);

        editRetype = (EditText)findViewById(R.id.editText_signup_retypepass_text);
        int editRetypeW = nRelativeRetypeW - (int)(55*rX);
        int editRetypeH = nRelativeRetypeH;
        editRetype.setX(55*rX);
        editRetype.setY(0);
        RelativeLayout.LayoutParams parmsEditRetype = new RelativeLayout.LayoutParams(editRetypeW, editRetypeH);
        editRetype.setLayoutParams(parmsEditRetype);
        editRetype.setBackgroundDrawable(null);

        //password edit
        RelativeLayout relativePassword = (RelativeLayout)findViewById(R.id.relative_signup_pass);
        int nRelativePasswordW = (int)rWindowW/3*2;
        int nRelativePasswordH = (int)(80*rY);
        relativePassword.setX(rWindowW/2 - nRelativePasswordW/2);
        relativePassword.setY(relativeRetype.getY() - nRelativePasswordH);
        RelativeLayout.LayoutParams parmsRelatPass = new RelativeLayout.LayoutParams(nRelativePasswordW, nRelativePasswordH);
        relativePassword.setLayoutParams(parmsRelatPass);

        ImageView imgPassLine = (ImageView)findViewById(R.id.imageView_signup_pass_line);
        int nImgPassLineW = (int)(10*rX);
        int nImgPassLineH = (int)(40*rY);
        imgPassLine.setX(50*rX);
        imgPassLine.setY(20*rY);
        RelativeLayout.LayoutParams parmsImgPassLine = new RelativeLayout.LayoutParams(nImgPassLineW, nImgPassLineH);
        imgPassLine.setLayoutParams(parmsImgPassLine);


        ImageView imgPassIcon = (ImageView)findViewById(R.id.imageView_signup_pass_key);
        int nImgPassIconW = nRelativePasswordH - (int)(40*rY);
        int nImgPassIconH = nRelativePasswordH - (int)(40*rY);
        imgPassIcon.setX(10*rX);
        imgPassIcon.setY(20*rY);
        RelativeLayout.LayoutParams parmsImgPassIcon = new RelativeLayout.LayoutParams(nImgPassIconW, nImgPassIconH);
        imgPassIcon.setLayoutParams(parmsImgPassIcon);

        ImageView imgPassBk = (ImageView)findViewById(R.id.imageView_signup_pass_bk);
        int nImgPassBkW = nRelativePasswordW;
        int nImgPassBkH = nRelativePasswordH;
        imgPassBk.setX(0);
        imgPassBk.setY(0);
        RelativeLayout.LayoutParams parmsImgPassBk = new RelativeLayout.LayoutParams(nImgPassBkW, nImgPassBkH);
        imgPassBk.setLayoutParams(parmsImgPassBk);

        editPass = (EditText)findViewById(R.id.editText_signup_pass_text);
        int editPassW = nRelativePasswordW - (int)(55*rX);
        int editPassH = nRelativePasswordH;
        editPass.setX(55*rX);
        editPass.setY(0);
        RelativeLayout.LayoutParams parmsEditPass = new RelativeLayout.LayoutParams(editPassW, editPassH);
        editPass.setLayoutParams(parmsEditPass);
        editPass.setBackgroundDrawable(null);

        //Username edit
        RelativeLayout relativeUsername = (RelativeLayout)findViewById(R.id.relative_signup_email);
        int nRelativeUserW = (int)rWindowW/3*2;
        int nRelativeUserH = (int)(80*rY);
        relativeUsername.setX(rWindowW/2 - nRelativeUserW/2);
        relativeUsername.setY(relativePassword.getY() - nRelativeUserH);
        RelativeLayout.LayoutParams parmsRelatUser = new RelativeLayout.LayoutParams(nRelativeUserW, nRelativeUserH);
        relativeUsername.setLayoutParams(parmsRelatUser);

        ImageView imgUserLine = (ImageView)findViewById(R.id.imageView_signup_email_line);
        int nImgUserLineW = (int)(10*rX);
        int nImgUserLineH = (int)(40*rY);
        imgUserLine.setX(50*rX);
        imgUserLine.setY(20*rY);
        RelativeLayout.LayoutParams parmsImgUserLine = new RelativeLayout.LayoutParams(nImgUserLineW, nImgUserLineH);
        imgUserLine.setLayoutParams(parmsImgUserLine);


        ImageView imgUserIcon = (ImageView)findViewById(R.id.imageView_signup_email_user);
        int nImgUserIconW = nRelativeUserH - (int)(40*rY);
        int nImgUserIconH = nRelativeUserH - (int)(40*rY);
        imgUserIcon.setX(10*rX);
        imgUserIcon.setY(20*rY);
        RelativeLayout.LayoutParams parmsImgUserIcon = new RelativeLayout.LayoutParams(nImgUserIconW, nImgUserIconH);
        imgUserIcon.setLayoutParams(parmsImgUserIcon);

        ImageView imgUserBk = (ImageView)findViewById(R.id.imageView_signup_email_bk);
        int nImgUserBkW = nRelativeUserW;
        int nImgUserBkH = nRelativeUserH;
        imgUserBk.setX(0);
        imgUserBk.setY(0);
        RelativeLayout.LayoutParams parmsImgUserBk = new RelativeLayout.LayoutParams(nImgUserBkW, nImgUserBkH);
        imgUserBk.setLayoutParams(parmsImgUserBk);

        editUser = (EditText)findViewById(R.id.editText_signup_email_text);
        int editUserW = nRelativeUserW - (int)(55*rX);
        int editUserH = nRelativeUserH;
        editUser.setX(55*rX);
        editUser.setY(0);
        RelativeLayout.LayoutParams parmsEditUser  = new RelativeLayout.LayoutParams(editUserW, editUserH);
        editUser.setLayoutParams(parmsEditUser);
        editUser.setBackgroundDrawable(null);

        //Last Name edit
        RelativeLayout relativeLastName = (RelativeLayout)findViewById(R.id.relative_signup_lastname);
        int nRelativeLastW = (int)rWindowW/3*2;
        int nRelativeLastH = (int)(80*rY);
        relativeLastName.setX(rWindowW/2 - nRelativeLastW/2);
        relativeLastName.setY(relativeUsername.getY() - 20*rY - nRelativeLastH);
        RelativeLayout.LayoutParams parmsRelatLast = new RelativeLayout.LayoutParams(nRelativeLastW, nRelativeLastH);
        relativeLastName.setLayoutParams(parmsRelatLast);

        ImageView imgLastLine = (ImageView)findViewById(R.id.imageView_signup_lastname_line);
        int nImgUserLastW = (int)(10*rX);
        int nImgUserLastH = (int)(40*rY);
        imgLastLine.setX(50*rX);
        imgLastLine.setY(20*rY);
        RelativeLayout.LayoutParams parmsImgLastLine = new RelativeLayout.LayoutParams(nImgUserLastW, nImgUserLastH);
        imgLastLine.setLayoutParams(parmsImgLastLine);


        ImageView imgLastIcon = (ImageView)findViewById(R.id.imageView_signup_lastname_user);
        int nImgLastIconW = nRelativeLastH - (int)(40*rY);
        int nImgLastIconH = nRelativeLastH - (int)(40*rY);
        imgLastIcon.setX(10*rX);
        imgLastIcon.setY(20*rY);
        RelativeLayout.LayoutParams parmsImgLastIcon = new RelativeLayout.LayoutParams(nImgLastIconW, nImgLastIconH);
        imgLastIcon.setLayoutParams(parmsImgLastIcon);

        ImageView imgLastBk = (ImageView)findViewById(R.id.imageView_signup_lastname_bk);
        int nImgLastBkW = nRelativeLastW;
        int nImgLastBkH = nRelativeLastH;
        imgLastBk.setX(0);
        imgLastBk.setY(0);
        RelativeLayout.LayoutParams parmsImgLastBk = new RelativeLayout.LayoutParams(nImgLastBkW, nImgLastBkH);
        imgLastBk.setLayoutParams(parmsImgLastBk);

        editLast = (EditText)findViewById(R.id.editText_signup_lastname_text);
        int editLastW = nRelativeLastW - (int)(55*rX);
        int editLastH = nRelativeLastH;
        editLast.setX(55*rX);
        editLast.setY(0);
        RelativeLayout.LayoutParams parmsEditLast  = new RelativeLayout.LayoutParams(editLastW, editLastH);
        editLast.setLayoutParams(parmsEditLast);
        editLast.setBackgroundDrawable(null);

        //First Name edit
        RelativeLayout relativeFirstName = (RelativeLayout)findViewById(R.id.relative_signup_firstname);
        int nRelativeFirstW = (int)rWindowW/3*2;
        int nRelativeFirstH = (int)(80*rY);
        relativeFirstName.setX(rWindowW/2 - nRelativeFirstW/2);
        relativeFirstName.setY(relativeLastName.getY() - nRelativeFirstH);
        RelativeLayout.LayoutParams parmsRelatFirst = new RelativeLayout.LayoutParams(nRelativeFirstW, nRelativeFirstH);
        relativeFirstName.setLayoutParams(parmsRelatFirst);

        ImageView imgFirstLine = (ImageView)findViewById(R.id.imageView_signup_firstname_line);
        int nImgUserFirstW = (int)(10*rX);
        int nImgUserFirstH = (int)(40*rY);
        imgFirstLine.setX(50*rX);
        imgFirstLine.setY(20*rY);
        RelativeLayout.LayoutParams parmsImgFirstLine = new RelativeLayout.LayoutParams(nImgUserFirstW, nImgUserFirstH);
        imgFirstLine.setLayoutParams(parmsImgFirstLine);


        ImageView imgFirstIcon = (ImageView)findViewById(R.id.imageView_signup_firstname_user);
        int nImgFirstIconW = nRelativeFirstH - (int)(40*rY);
        int nImgFirstIconH = nRelativeFirstH - (int)(40*rY);
        imgFirstIcon.setX(10*rX);
        imgFirstIcon.setY(20*rY);
        RelativeLayout.LayoutParams parmsImgFirstIcon = new RelativeLayout.LayoutParams(nImgFirstIconW, nImgFirstIconH);
        imgFirstIcon.setLayoutParams(parmsImgFirstIcon);

        ImageView imgFirstBk = (ImageView)findViewById(R.id.imageView_signup_firstname_bk);
        int nImgFirstBkW = nRelativeFirstW;
        int nImgFirstBkH = nRelativeFirstH;
        imgFirstBk.setX(0);
        imgFirstBk.setY(0);
        RelativeLayout.LayoutParams parmsImgFirstBk = new RelativeLayout.LayoutParams(nImgFirstBkW, nImgFirstBkH);
        imgFirstBk.setLayoutParams(parmsImgFirstBk);

        editFirst = (EditText)findViewById(R.id.editText_signup_firstname_text);
        int editFirstW = nRelativeFirstW - (int)(55*rX);
        int editFirstH = nRelativeFirstH;
        editFirst.setX(55*rX);
        editFirst.setY(0);
        RelativeLayout.LayoutParams parmsEditFirst  = new RelativeLayout.LayoutParams(editFirstW, editFirstH);
        editFirst.setLayoutParams(parmsEditFirst);
        editFirst.setBackgroundDrawable(null);

        //image logo
        ImageView imgLogo = (ImageView)findViewById(R.id.imageView_signup_logo);
        int logH = (int)relativeFirstName.getY() - (int)(150*rY);
        int logW = logH;
        RelativeLayout.LayoutParams parmsImgLogo = new RelativeLayout.LayoutParams(logW, logH);
        imgLogo.setLayoutParams(parmsImgLogo);
        imgLogo.setX(rWindowW/2 - logW/2);
        imgLogo.setY(100*rY);

    }
}
