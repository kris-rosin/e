package go3treks.craig.com.go3treks.model;

public class MonitorInfo {
    public String lat = "";
    public String longi = "";
    public String county = "";
    public String _ID = "";
    public String gas = "";
    public String gasValue = "";
    public String city = "";
    public String state = "";
    public Double distanceToMe = 10000.0;  //init with big value
    public String activeStatus = "";

    public MonitorInfo()
    {
        lat = "";
        longi = "";
        county = "";
        _ID = "";
        gas = "";
        gasValue = "";
        city = "";
        state = "";
        distanceToMe = 10000.0;  //init with big value
        activeStatus = "";
    }
}


