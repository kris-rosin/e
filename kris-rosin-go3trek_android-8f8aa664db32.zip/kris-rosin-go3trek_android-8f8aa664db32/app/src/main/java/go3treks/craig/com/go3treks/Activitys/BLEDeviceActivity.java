package go3treks.craig.com.go3treks.Activitys;

import android.annotation.TargetApi;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.AnimationDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import android.support.v7.app.AppCompatActivity;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import go3treks.craig.com.go3treks.Adapter.DeviceListAdapter;
import go3treks.craig.com.go3treks.Manager.GTKBleDeviceManager;
import go3treks.craig.com.go3treks.Manager.GTKGlobal;
import go3treks.craig.com.go3treks.Manager.Go3TreksConstants;
import go3treks.craig.com.go3treks.R;
import go3treks.craig.com.go3treks.model.GTKBlueDeviceData;

@TargetApi(21)
public class BLEDeviceActivity extends AppCompatActivity {

    private float rWindowW = 0;
    private float rWindowH = 0;

    public float rX;
    public float rY;

    private ListView mListView;
    private DeviceListAdapter mAdapter;
    private ArrayList<BluetoothDevice> mDeviceList;

    private BluetoothAdapter mBluetoothAdapter;
    private int REQUEST_ENABLE_BT = 1;
    private BluetoothLeScanner mLEScanner;
    private ScanSettings settings;
    private List<ScanFilter> filters;
    private BluetoothGatt mGatt;

    private Button btnDone;
    private AnimationDrawable animation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bledevice);

        Display display = getWindowManager().getDefaultDisplay();
        rWindowW = display.getWidth();
        rWindowH = display.getHeight();

        rX = Go3TreksConstants.getRX(rWindowW);
        rY = Go3TreksConstants.getRY(rWindowH);

        mDeviceList = new ArrayList<BluetoothDevice>();
        if (GTKBleDeviceManager.getDevicesCount() > 0)
        {
            GTKBleDeviceManager.removeDevicesArray();
        }

        //skip button
        btnDone = (Button)findViewById(R.id.button_ble_done);
        btnDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Go3TreksConstants.bBleSkip = false;
                Intent mainIntent = new Intent(BLEDeviceActivity.this, MainMenuActivity.class);
                BLEDeviceActivity.this.startActivity(mainIntent);
                BLEDeviceActivity.this.finish();
            }
        });

        Button btnSkip = (Button)findViewById(R.id.button_ble_skip);
        btnSkip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Go3TreksConstants.bBleSkip = true;
                Intent mainIntent = new Intent(BLEDeviceActivity.this, MainMenuActivity.class);
                BLEDeviceActivity.this.startActivity(mainIntent);
                BLEDeviceActivity.this.finish();
            }
        });

        int nBtnSkipW = (int)rWindowW/3*2;
        int nBtnSkipH = (int) (50*rY);
        btnSkip.setX(rWindowW/2 - nBtnSkipW/2);
        btnSkip.setY(rWindowH - 100*rY - nBtnSkipH);
        RelativeLayout.LayoutParams parmsBtnSkip = new RelativeLayout.LayoutParams(nBtnSkipW, nBtnSkipH);
        btnSkip.setLayoutParams(parmsBtnSkip);

        ImageView imgtbk = (ImageView)findViewById(R.id.imageView_ble_topbar);
        int nImgGIconW = (int) (rWindowW + 30*rX);
        int nImgGIconH = (int) (90 * rY);
        imgtbk.setX(0);
        imgtbk.setY(0);
        RelativeLayout.LayoutParams parmsImgGIcon = new RelativeLayout.LayoutParams(nImgGIconW, nImgGIconH);
        imgtbk.setLayoutParams(parmsImgGIcon);


        TextView txtViewTitle = (TextView)findViewById(R.id.textView_ble_title);
        int nTxtViewTitleW = (int)rWindowW/3*2;
        int nTxtViewTitleH = (int)(50*rY);
        txtViewTitle.setX(rWindowW/2 - nTxtViewTitleW/2);
        txtViewTitle.setY(rWindowH/2 - 100*rY);
        RelativeLayout.LayoutParams parmsTxtViewTitle = new RelativeLayout.LayoutParams(nTxtViewTitleW, nTxtViewTitleH);
        txtViewTitle.setLayoutParams(parmsTxtViewTitle);
        txtViewTitle.setTextSize(txtViewTitle.getTextSize()/rY/1.5f);

        animation= new AnimationDrawable();
        animation.addFrame(getResources().getDrawable(R.drawable.device_prog_0),100); //0s
        animation.addFrame(getResources().getDrawable(R.drawable.device_prog_1), 300);
        animation.addFrame(getResources().getDrawable(R.drawable.device_prog_2), 800);
        animation.addFrame(getResources().getDrawable(R.drawable.device_prog_3),1400);
        animation.setOneShot(false);
        ImageView imageAni=(ImageView)findViewById(R.id.imageView_ble_animation);
        imageAni.setBackgroundDrawable(animation);
        int nImageAniW = (int)rWindowW/4;
        int nImageAniH = (int)rWindowW/4;
        imageAni.setX(rWindowW/2 - nImageAniW/2);
        imageAni.setY(rWindowH/2 - 120*rY - rWindowW/4);
        RelativeLayout.LayoutParams parmsImageAni = new RelativeLayout.LayoutParams(nImageAniW, nImageAniH);
        imageAni.setLayoutParams(parmsImageAni);
        imageAni.post(new Starter());


        mListView		= (ListView) findViewById(R.id.listview_epa_list);
        int nListViewW = (int)rWindowW/3*2;
        int nListViewH = (int)(rWindowH/2 - 130*rY);
        mListView.setX(rWindowW/2 - nListViewW/2);
        mListView.setY(rWindowH/2 - 50*rY);
        RelativeLayout.LayoutParams parmsListView = new RelativeLayout.LayoutParams(nListViewW, nListViewH);
        mListView.setLayoutParams(parmsListView);

        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        checkBTState();
        rescane();


        mAdapter		= new DeviceListAdapter(this, rWindowW, rWindowH);

        mAdapter.setData(mDeviceList);
        mAdapter.setListener(new DeviceListAdapter.OnItemsClickListener(){

            @Override
            public void onItemClick(int position) {

            }
        });


        mListView.setAdapter(mAdapter);
        mListView.setClickable(true);

        btnDone.setVisibility(View.INVISIBLE);
        LocalBroadcastManager.getInstance(this).registerReceiver(reSelectDevices,
                new IntentFilter(GTKGlobal.kNotificationReSelectDevice));

    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        } else {
            if (Build.VERSION.SDK_INT >= 21) {
                mLEScanner = mBluetoothAdapter.getBluetoothLeScanner();
                settings = new ScanSettings.Builder()
                        .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                        .build();
                filters = new ArrayList<ScanFilter>();
            }
            scanLeDevice(true);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mBluetoothAdapter != null && mBluetoothAdapter.isEnabled()) {
            scanLeDevice(false);
        }
    }

    @Override
    protected void onDestroy() {

        super.onDestroy();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(reSelectDevices);

        if (mGatt == null) {
            return;
        }
        mGatt.close();
        mGatt = null;

        scanLeDevice(false);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == Activity.RESULT_CANCELED) {
                //Bluetooth not enabled.
                checkBTState();
                return;
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void scanLeDevice(final boolean enable) {
        if (enable) {
//            mHandler.postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    if (Build.VERSION.SDK_INT < 21) {
//                        mBluetoothAdapter.stopLeScan(mLeScanCallback);
//                    } else {
//                        mLEScanner.stopScan(mScanCallback);
//
//                    }
//                }
//            }, SCAN_PERIOD);
            if (Build.VERSION.SDK_INT < 21) {
                mBluetoothAdapter.startLeScan(mLeScanCallback);
            } else {
                mLEScanner.startScan(filters, settings, mScanCallback);
//                mBluetoothAdapter.startLeScan(mLeScanCallback);
            }
        } else {
            if (Build.VERSION.SDK_INT < 21) {
                mBluetoothAdapter.stopLeScan(mLeScanCallback);
            } else {
                mLEScanner.stopScan(mScanCallback);
//                mBluetoothAdapter.stopLeScan(mLeScanCallback);
            }
        }
    }


    private ScanCallback mScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            Log.i("callbackType", String.valueOf(callbackType));
            Log.i("result", result.toString());
            BluetoothDevice btDevice = result.getDevice();

            ScanRecord scanRecord = result.getScanRecord();
            byte[] scanByte = scanRecord.getBytes();

            String strName = btDevice.getName();
            String strAdress = btDevice.getAddress();

            String s = null;
            try {
                s = new String(scanByte, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            connectToDevice(btDevice);

            int nIndex = s.indexOf("$");
            String strSub = s.substring(0, 6);
            Boolean bContain = strSub.contains("$");
            if (bContain == true)
            {
                String separatedStrings[] = s.split("\\|");
                if(!separatedStrings[0].isEmpty()){
                    String device  = separatedStrings[0];
                    String strDSub = device.substring(6, device.length());
                    Go3TreksConstants.g_DeviceID = strDSub;
                }
                if (mDeviceList.size() > 0)
                {
                    for (int i = 0; i< mDeviceList.size(); i++)
                    {
                        BluetoothDevice myDevice = mDeviceList.get(i);
                        String strAdress1 = myDevice.getAddress();
                        if (strAdress1.contentEquals(strAdress))
                        {
                            continue;
                        }
                        else
                        {
                            mDeviceList.add(btDevice);
                            mAdapter.notifyDataSetChanged();
                        }
                    }
                }
                else
                {
                    mDeviceList.add(btDevice);
                    mAdapter.notifyDataSetChanged();
                }
            }
        }

        @Override
        public void onBatchScanResults(List<ScanResult> results) {
            for (ScanResult sr : results) {
                Log.i("ScanResult - Results", sr.toString());
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            Log.e("Scan Failed", "Error Code: " + errorCode);
        }
    };

    private BluetoothAdapter.LeScanCallback mLeScanCallback =
            new BluetoothAdapter.LeScanCallback() {
                @Override
                public void onLeScan(final BluetoothDevice device, int rssi,
                                     final byte[] scanRecord) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Log.i("onLeScan", device.toString());

                            String strName = device.getName();
                            String strAdress = device.getAddress();

                            String s = null;
                            try {
                                s = new String(scanRecord, "UTF-8");
                            } catch (UnsupportedEncodingException e) {
                                e.printStackTrace();
                            }
                            connectToDevice(device);

                            int nIndex = s.indexOf("$");
                            String strSub = s.substring(0, 6);
                            Boolean bContain = strSub.contains("$");
                            if (bContain == true)
                            {
                                if (mDeviceList.size() > 0)
                                {
                                    for (int i = 0; i< mDeviceList.size(); i++)
                                    {
                                        BluetoothDevice myDevice = mDeviceList.get(i);
                                        String strAdress1 = myDevice.getAddress();
                                        if (strAdress1.contentEquals(strAdress))
                                        {
                                            continue;
                                        }
                                        else
                                        {
                                            mDeviceList.add(device);
                                            mAdapter.notifyDataSetChanged();
                                        }
                                    }
                                }
                                else
                                {
                                    mDeviceList.add(device);
                                    mAdapter.notifyDataSetChanged();
                                }
                            }
                        }
                    });
                }
            };

    public void connectToDevice(BluetoothDevice device) {
        if (mGatt == null) {
            mGatt = device.connectGatt(this, false, gattCallback);
            scanLeDevice(true);
        }
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            Log.i("onConnectionStateChange", "Status: " + status);
            switch (newState) {
                case BluetoothProfile.STATE_CONNECTED:
                    Log.i("gattCallback", "STATE_CONNECTED");
                    gatt.discoverServices();
                    break;
                case BluetoothProfile.STATE_DISCONNECTED:
                    Log.e("gattCallback", "STATE_DISCONNECTED");
                    break;
                default:
                    Log.e("gattCallback", "STATE_OTHER");
            }

        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            List<BluetoothGattService> services = gatt.getServices();
            Log.i("onServicesDiscovered", services.toString());
            gatt.readCharacteristic(services.get(1).getCharacteristics().get
                    (0));
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic
                                                 characteristic, int status) {
            Log.i("onCharacteristicRead", characteristic.toString());
//            gatt.disconnect();
        }
    };

    private void checkBTState() {

        if(mBluetoothAdapter==null) {
            Toast.makeText(getBaseContext(), "Device does not support bluetooth", Toast.LENGTH_LONG).show();
        } else {
            if (mBluetoothAdapter.isEnabled()) {
                Go3TreksConstants.isEnableBLE = true;
            } else {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
        }
    }

    private BroadcastReceiver reSelectDevices = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            if (GTKBleDeviceManager.getDevicesCount() == 0)
            {
                btnDone.setVisibility(View.INVISIBLE);
            }
            else
            {
                btnDone.setVisibility(View.VISIBLE);
            }
        }
    };

    class Starter implements Runnable{
        public void run(){
            animation.start();
        }
    }


    private void rescane()
    {
        new Thread(new Runnable() {
            public void run() {
                mBluetoothAdapter.getBondedDevices();
                mBluetoothAdapter.startDiscovery();
            }
        }).start();
    }


    /////////////////

}
