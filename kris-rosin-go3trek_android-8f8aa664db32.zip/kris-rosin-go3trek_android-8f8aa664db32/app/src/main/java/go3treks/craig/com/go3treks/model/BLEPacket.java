package go3treks.craig.com.go3treks.model;

import java.util.ArrayList;

public class BLEPacket {

    public String name = "";

    public ArrayList<String> _ID = new ArrayList<String>();
    public ArrayList<String> _num = new ArrayList<String>();
    public ArrayList<Double> _value = new ArrayList<Double>();
    public ArrayList<String> _valueString = new ArrayList<String>();

    public String _units = "";

    public int _indexPoint = 0;

    public Boolean isString = false;

    public BLEPacket(){

    }

    public Double getMaxValue()
    {
        Double v = 0.0;
        for(int i = 0; i < _value.size(); i++ )
        {
            Double va = _value.get(i);
            if (v < va)
            {
                v = va;
            }
        }

        return v;
    }
}
