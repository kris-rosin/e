package go3treks.craig.com.go3treks.Fragments;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;


import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import go3treks.craig.com.go3treks.Manager.GTKBleDeviceManager;
import go3treks.craig.com.go3treks.Manager.GTKGlobal;
import go3treks.craig.com.go3treks.Manager.Go3TreksConstants;
import go3treks.craig.com.go3treks.R;
import go3treks.craig.com.go3treks.model.GTKBlueDeviceData;
import go3treks.craig.com.go3treks.model.Station;

public class MapFragment extends Fragment implements LocationListener{

    private float rWindowW = 0;
    private float rWindowH = 0;

    public float rX;
    public float rY;

    private Button btnBle;
    private Button btnGas;

    Double rRate = 10000.0;
    LocationManager locationManager;

    Double curLocationLat = 0.0;
    Double curLocationLong = 0.0;

    ArrayList<String> itemGas = new ArrayList<String>();

    ArrayList<Polyline> polylines = new ArrayList<Polyline>();
    ArrayList<Polygon> polygons = new ArrayList<Polygon>();

    ArrayList<Station> annotationsMap = new ArrayList<Station>();

    int nSelectedDevice = 0;

    boolean bFirstView = true;

    String mapGasTypeName = "";


    MapView mapView;
    GoogleMap mGoogleMap;
    Location myLocation;

    public MapFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LocalBroadcastManager.getInstance(this.getContext()).registerReceiver(redrawMapReceiver,
                new IntentFilter(GTKGlobal.kNotificationRedrawMap));
    }

    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        Display display = getActivity().getWindowManager().getDefaultDisplay();
        rWindowW = display.getWidth();
        rWindowH = display.getHeight();

        rX = Go3TreksConstants.getRX(rWindowW);
        rY = Go3TreksConstants.getRY(rWindowH);

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_map, container, false);

        btnBle = (Button)view.findViewById(R.id.map_btn_1);
        int nBleW = (int)(50*rY);
        int nBleH = (int)(50*rY);
        RelativeLayout.LayoutParams parmsRelatBle = new RelativeLayout.LayoutParams(nBleW, nBleH);
        btnBle.setLayoutParams(parmsRelatBle);
        btnBle.setX((int)(20*rX));
        btnBle.setY((int)rWindowH - 270*rY);
        btnBle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        btnGas = (Button)view.findViewById(R.id.map_btn_2);
        int nGasW = (int)(50*rY);
        int nGasH = (int)(50*rY);
        RelativeLayout.LayoutParams parmsRelatGas = new RelativeLayout.LayoutParams(nGasW, nGasH);
        btnGas.setLayoutParams(parmsRelatGas);
        btnGas.setX((int)(20*rX));
        btnGas.setY((int)rWindowH - 200*rY);

        btnGas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        mapView = (MapView) view.findViewById(R.id.map_mapview);

        mapView.onCreate(savedInstanceState);
        if (mapView != null) {
            mapView.getMapAsync(new OnMapReadyCallback() {
                @Override
                public void onMapReady(GoogleMap googleMap) {
                    mGoogleMap = googleMap;
                    mGoogleMap.addMarker(new MarkerOptions()
                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.map_pin_center))
                            .anchor(0.5f, 1.0f)
                            .position(new LatLng(GTKGlobal.g_locationMyDevice.getLatitude(), GTKGlobal.g_locationMyDevice.getLongitude())));
                    mGoogleMap.getUiSettings().setMyLocationButtonEnabled(false);
                    if (ActivityCompat.checkSelfPermission(getActivity(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                            && ActivityCompat.checkSelfPermission(getActivity(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                    {

                    }
                    else
                    {
                        bFirstView = true;
                        mGoogleMap.getUiSettings().setRotateGesturesEnabled(false);
                        mGoogleMap.setMyLocationEnabled(true);
                        mGoogleMap.getUiSettings().setZoomControlsEnabled(false);
                        MapsInitializer.initialize(getActivity());
                        LatLngBounds.Builder builder = new LatLngBounds.Builder();
                        builder.include(new LatLng(GTKGlobal.g_locationMyDevice.getLatitude(), GTKGlobal.g_locationMyDevice.getLongitude()));
                        LatLngBounds bounds = builder.build();
                        int padding = 0;
                        // Updates the location and zoom of the MapView
                        CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngBounds(bounds, padding);
                        mGoogleMap.moveCamera(cameraUpdate);
                    }

                }
            });

        }
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mapView != null) {
            mapView.onResume();
        }
    }

    @Override
    public void onPause() {
        if (mapView != null) {
            mapView.onPause();
        }
        super.onPause();
    }

    @Override
    public void onDestroy() {
        LocalBroadcastManager.getInstance(this.getContext()).unregisterReceiver(redrawMapReceiver);
        if (mapView != null) {
            try {
                mapView.onDestroy();
            } catch (NullPointerException e) {

            }
        }
        super.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        if (mapView != null) {
            mapView.onLowMemory();
        }
    }


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onLocationChanged(Location location) {

        if (mGoogleMap == null)
        {
            return;
        }
        myLocation = location;
        if (bFirstView)
        {
            mGoogleMap.addMarker(new MarkerOptions()
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.map_pin_center))
                    .anchor(0.5f, 1.0f)
                    .position(new LatLng(location.getLatitude(), location.getLongitude())));
            mGoogleMap.getUiSettings().setMyLocationButtonEnabled(false);
            if (ActivityCompat.checkSelfPermission(getActivity(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(getActivity(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            {

            }
            else
            {
                mGoogleMap.getUiSettings().setRotateGesturesEnabled(false);
                mGoogleMap.setMyLocationEnabled(true);
                mGoogleMap.getUiSettings().setZoomControlsEnabled(false);
                MapsInitializer.initialize(getActivity());
                LatLngBounds.Builder builder = new LatLngBounds.Builder();
                builder.include(new LatLng(location.getLatitude(), location.getLongitude()));
                LatLngBounds bounds = builder.build();
                int padding = 0;
                // Updates the location and zoom of the MapView
                CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngBounds(bounds, padding);
                mGoogleMap.moveCamera(cameraUpdate);
            }

            redrawMap();
            bFirstView = false;


        }
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }


    private BroadcastReceiver redrawMapReceiver = new BroadcastReceiver() {
        @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
        @Override
        public void onReceive(Context context, Intent intent) {

            redrawMap();
        }
    };

    public void redrawMap()
    {
        if (mGoogleMap == null || GTKGlobal.g_locationMyDevice == null)
        {
            return;
        }
        if (GTKBleDeviceManager.getDevicesCount() > 0)
        {
            GTKBlueDeviceData dataDevice = GTKBleDeviceManager.arrayDevices.get(nSelectedDevice);

            ArrayList<LatLng> points = new ArrayList<LatLng>();

            if (dataDevice.latMyDevice.size() <= 0)
            {
                return;
            }

            itemGas.clear();

            int indexGas = 0;
            for (int i = 0; i < dataDevice.blePackets.size(); i++)
            {
                if (dataDevice.blePackets.get(i).isString == false)
                {
                    itemGas.add(dataDevice.blePackets.get(i).name);

                    if (mapGasTypeName ==  dataDevice.blePackets.get(i).name)
                    {
                        indexGas = i;
                    }
                }
                else
                {
                    continue;
                }
            }
//            tableMapBLE.reloadData()
//            tableMapGAS.reloadData()

            annotationsMap.clear();
            annotationsMap = getMapAnnotations();
            mGoogleMap.addMarker(new MarkerOptions()
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.map_pin_center))
                    .anchor(0.5f, 1.0f)
                    .position(new LatLng(GTKGlobal.g_locationMyDevice.getLatitude(), GTKGlobal.g_locationMyDevice.getLongitude())));

            polygons.clear();

            Double maxV = dataDevice.blePackets.get(indexGas).getMaxValue();

            for (int i = 0; i < dataDevice.latMyDevice.size(); i++)
            {
                LatLng location = new LatLng(dataDevice.latMyDevice.get(i), dataDevice.lonMyDevice.get(i));
                points.add(location);

                for(Polyline line : polylines)
                {
                    line.remove();
                }
                polylines.clear();

                PolylineOptions polylineOptions = new PolylineOptions();
                polylineOptions.color(Color.RED);
                polylineOptions.width(5);
                polylineOptions.addAll(points);
                Polyline polyline = mGoogleMap.addPolyline(polylineOptions);
                polylines.add(polyline);

                if ((i < dataDevice.latMyDevice.size() - 1) && (i < dataDevice.blePackets.get(indexGas)._value.size() - 1))
                {
                    LatLng location1 = new LatLng(dataDevice.latMyDevice.get(i+1), dataDevice.lonMyDevice.get(i+1));

                    for(Polygon polygon : polygons)
                    {
                        polygon.remove();
                    }
                    polylines.clear();

                    ArrayList<LatLng> polygonPoints = new ArrayList<LatLng>();
                    polygonPoints.add(new LatLng(location.latitude, location.longitude));
                    polygonPoints.add(new LatLng(location1.latitude, location1.longitude));
                    polygonPoints.add(new LatLng(location1.latitude + (5/maxV)*dataDevice.blePackets.get(indexGas)._value.get(i+1)/rRate, location1.longitude));
                    polygonPoints.add(new LatLng(location.latitude + (5/maxV)*dataDevice.blePackets.get(indexGas)._value.get(i)/rRate, location.longitude));

                    PolygonOptions polygonOptions = new PolygonOptions();
                    polygonOptions.fillColor(Color.YELLOW);
                    polygonOptions.strokeColor(Color.GREEN);
                    polygonOptions.addAll(polygonPoints);
                    Polygon polygon = mGoogleMap.addPolygon(polygonOptions);
                    polygons.add(polygon);

//                    let pointAnnotation = ValueAnnotation()
//                    pointAnnotation.pinImageName = "bubble.png"
//                    pointAnnotation.coordinate = location1.coordinate
//                    pointAnnotation.title = "\(dataDevice.blePackets[indexGas].name)"
//                    pointAnnotation.subtitle = "\(dataDevice.blePackets[indexGas]._value[i+1]) (\(dataDevice.blePackets[indexGas]._units))"
//
//                    let pinAnnotationView = MKPinAnnotationView(annotation: pointAnnotation, reuseIdentifier: "pin")
//                    mapView.addAnnotation(pinAnnotationView.annotation!)
                }


            }


        }
    }

    ArrayList<Station> getMapAnnotations()
    {
        ArrayList<Station> annotations = new ArrayList<Station>();

        if (GTKBleDeviceManager.arrayDevices.get(0).latMyDevice.size() > 0)
        {
            for(int i = 0; i < GTKBleDeviceManager.arrayDevices.get(0).latMyDevice.size(); i++)
            {
                Double lat = GTKBleDeviceManager.arrayDevices.get(0).latMyDevice.get(i);
                Double lon = GTKBleDeviceManager.arrayDevices.get(0).lonMyDevice.get(i);
                Station annotation = new Station(lat,lon);
                annotations.add(annotation);
            }
        }

        return annotations;
    }
}
