package go3treks.craig.com.go3treks.Manager;

import android.location.Location;
import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class DownloadFileFromURL extends AsyncTask<String, String, String> {

    /**
     * Before starting background thread Show Progress Bar Dialog
     * */
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    /**
     * Downloading file in background thread
     * */
    @Override
    protected String doInBackground(String... f_url) {

        try {
            URL url = new URL(f_url[0]);

            URLConnection ucon = url.openConnection();

            InputStream input = ucon.getInputStream();
//
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            String line = "";
            double dlatitude = 0;
            double dlongitude = 0;
            String strCity = "";
            double distanceBetween = 300000000; //meter

            line = reader.readLine();
            Location loc1 = new Location("");
            loc1.setLatitude(Go3TreksConstants.myCurrentLatitude);
            loc1.setLongitude(Go3TreksConstants.myCurrentLongitude);

//            int count = 0;
//            try {
//                byte[] c = new byte[1024];
//
//                int readChars = 0;
//                boolean empty = true;
//                while ((readChars = input.read(c)) != -1) {
//                    empty = false;
//                    String lines = "";
//                    String s = new String(c);
//                    for (int i = 0; i < readChars; ++i) {
//                        if (c[i] == '\n') {
//                            ++count;
//                            String strS = c.toString();
//
//                        }
//                    }
//                }
//
//            } finally {
////                input.close();
//            }

            line = reader.readLine();
            int nCount = 0;
            nCount = 0;
            while ((line = reader.readLine()) != null) {

                // do something with the line
                if (line == null)
                {
                    line = reader.readLine();
                    continue;
                }

                String[] strS = line.split("\\|");
                if (strS.length > 10)
                {
                    dlatitude = Double.parseDouble(strS[8]);
                    dlongitude = Double.parseDouble(strS[9]);
                    strCity = strS[3];

                    Location loc2 = new Location("");
                    loc2.setLatitude(dlatitude);
                    loc2.setLongitude(dlongitude);

                    float tmpDistanceBetween = loc1.distanceTo(loc2);

                    if (distanceBetween > tmpDistanceBetween / 1609.34)
                    {
                        distanceBetween = tmpDistanceBetween / 1609.34;

                        Go3TreksConstants.g_nearEPASite = strCity;
                        Go3TreksConstants.g_nearMile = String.format("%f",distanceBetween);
                        Go3TreksConstants.g_SiteLat = String.format("%f", dlatitude);
                        Go3TreksConstants.g_SiteLong = String.format("%f", dlongitude);

                    }
                }
                nCount += 1;
//                line = reader.readLine();

            }

            reader.close();
            input.close();
            Go3TreksConstants.bHadErroe = true;
            Go3TreksConstants.bFoindingEPASite = false;

        } catch (Exception e) {
            Log.e("Error: ", e.getMessage());
            Go3TreksConstants.bHadErroe = true;
            Go3TreksConstants.bFoindingEPASite = false;
        }

        return null;
    }

    /**
     * Updating progress bar
     * */
    protected void onProgressUpdate(String... progress) {
        // setting progress percentage
//        pDialog.setProgress(Integer.parseInt(progress[0]));
    }

    /**
     * After completing background task Dismiss the progress dialog
     * **/
    @Override
    protected void onPostExecute(String file_url) {
        // dismiss the dialog after the file was downloaded
//        dismissDialog(progress_bar_type);

    }

}
