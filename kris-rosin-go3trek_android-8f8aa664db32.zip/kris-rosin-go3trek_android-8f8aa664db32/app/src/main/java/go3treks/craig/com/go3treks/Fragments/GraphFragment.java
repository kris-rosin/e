package go3treks.craig.com.go3treks.Fragments;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;

import go3treks.craig.com.go3treks.Manager.GTKBleDeviceManager;
import go3treks.craig.com.go3treks.Manager.GTKGlobal;
import go3treks.craig.com.go3treks.Manager.Go3TreksConstants;
import go3treks.craig.com.go3treks.R;
import go3treks.craig.com.go3treks.model.GTKBlueDeviceData;


public class GraphFragment extends Fragment {


    private ScrollView scrollView;
    private RelativeLayout scrollRelat;

    private float rWindowW = 0;
    private float rWindowH = 0;

    public float rX;
    public float rY;

    int nCountDevices = 0;
    float preGraphScale = 1;

    float initPosXGraph = 20.0f;
    float initPosYGraph = 20.0f;

    ArrayList<TextView> arrayLabels = new ArrayList<TextView>();
    GTKDrawingView myGraphView;

    public GraphFragment() {
        // Required empty public constructor
    }

    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LocalBroadcastManager.getInstance(this.getContext()).registerReceiver(redrawGraphicReceiver,
                new IntentFilter(GTKGlobal.kNotificationRedrawGrph));
    }

    @Override
    public void onPause() {
        super.onPause();

    }

    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    @Override
    public void onResume() {
        super.onResume();
        redrawGraphic();
    }

    @Override
    public void onDestroy() {
        LocalBroadcastManager.getInstance(this.getContext()).unregisterReceiver(redrawGraphicReceiver);
        super.onDestroy();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_graph, container, false);
    }

    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Display display = getActivity().getWindowManager().getDefaultDisplay();
        rWindowW = display.getWidth();
        rWindowH = display.getHeight();

        rX = Go3TreksConstants.getRX(rWindowW);
        rY = Go3TreksConstants.getRY(rWindowH);

        scrollView = (ScrollView)getActivity().findViewById(R.id.graph_scroll);



        scrollRelat = (RelativeLayout) getActivity().findViewById(R.id.graph_scroll_r);
        scrollRelat.setY(80*rY);

        nCountDevices = GTKBleDeviceManager.getDevicesCount();
        float gasPacketCount = 0;
        GTKBlueDeviceData dataDevice = GTKBleDeviceManager.arrayDevices.get(0);
        if( dataDevice.blePackets.size() > 0)
        {
            int packetCount = dataDevice.blePackets.size();

            for ( int i = 0; i < packetCount; i++ )
            {
                if (dataDevice.blePackets.get(i).isString)
                {
                    continue; //go to next packet
                }
                gasPacketCount += 1;
            }
        }
        int nH = (int)(((nCountDevices * GTKGlobal.G_HIGH_GRAPH + initPosYGraph) * gasPacketCount)*rY);
        scrollRelat.setMinimumHeight(nH);
        if (myGraphView != null)
        {
            scrollRelat.removeView(myGraphView);
        }

        myGraphView = new GTKDrawingView(getContext());
        myGraphView.rectMyView = new Rect(0,0,scrollRelat.getWidth(), nH);
        myGraphView.countDevice = nCountDevices;
        myGraphView.setX(0);
        myGraphView.setY(0);
        int nRelativeGroupW = (int)rWindowW;
        RelativeLayout.LayoutParams parmsRelatGrup = new RelativeLayout.LayoutParams(nRelativeGroupW, nH);
        myGraphView.setLayoutParams(parmsRelatGrup);
        scrollRelat.addView(myGraphView);

        if (arrayLabels.size() > 0)
        {
            for(int i = 0; i < arrayLabels.size(); i++ )
            {
                TextView lab = arrayLabels.get(i);
                scrollRelat.removeView(lab);
            }
            arrayLabels.clear();
            arrayLabels = new ArrayList<TextView>();
            createLabels();
        }
        else
        {
            createLabels();
        }

    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    public interface OnFragmentInteractionListener2 {
        public void onFragmentInteraction(String title);
    }


    private BroadcastReceiver redrawGraphicReceiver = new BroadcastReceiver() {
        @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
        @Override
        public void onReceive(Context context, Intent intent) {
            redrawGraphic();
        }
    };


    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    public void redrawGraphic()
    {

        nCountDevices = GTKBleDeviceManager.getDevicesCount();
        float gasPacketCount = 0;
        GTKBlueDeviceData dataDevice = GTKBleDeviceManager.arrayDevices.get(0);
        if( dataDevice.blePackets.size() > 0)
        {
            int packetCount = dataDevice.blePackets.size();

            for ( int i = 0; i < packetCount; i++ )
            {
                if (dataDevice.blePackets.get(i).isString)
                {
                    continue; //go to next packet
                }
                gasPacketCount += 1;
            }
        }
        int nH = (int)(((nCountDevices * GTKGlobal.G_HIGH_GRAPH + initPosYGraph) * gasPacketCount)*rY) + (int)(200*rY);
        scrollRelat.setMinimumHeight(nH);
        if (myGraphView != null)
        {
            scrollRelat.removeView(myGraphView);
        }

        if (myGraphView != null)
        {
            scrollRelat.removeView(myGraphView);
        }
        myGraphView = new GTKDrawingView(getContext());
        myGraphView.rectMyView = new Rect(0,0,scrollRelat.getWidth(), nH);
        myGraphView.countDevice = nCountDevices;
        myGraphView.setX(0);
        myGraphView.setY(0);
        int nRelativeGroupW = (int)rWindowW;
        RelativeLayout.LayoutParams parmsRelatGrup = new RelativeLayout.LayoutParams(nRelativeGroupW, nH);
        myGraphView.setLayoutParams(parmsRelatGrup);
        scrollRelat.addView(myGraphView);

        if (arrayLabels.size() > 0)
        {
            for(int i = 0; i < arrayLabels.size(); i++ )
            {
                TextView lab = arrayLabels.get(i);
                scrollRelat.removeView(lab);
            }
            arrayLabels.clear();
            arrayLabels = new ArrayList<TextView>();
            createLabels();
        }
        else
        {
            createLabels();
        }
    }

    @TargetApi(Build.VERSION_CODES.M)
    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    public TextView createLabel(String text, Rect aframe, int aAlign) {
        TextView label = new TextView(getContext());
        label.setBackgroundColor(Color.WHITE);
        label.setAlpha((float) 0.8);
        int nTextSiteW = (int) (aframe.width());
        int nTextSiteH = (int)(20*rY);//(int) (aframe.height());

        RelativeLayout.LayoutParams parmsTxt= new RelativeLayout.LayoutParams(nTextSiteW, nTextSiteH);
        label.setLayoutParams(parmsTxt);

        label.setText(text);
        label.setTextColor(Color.GRAY);

        if (aAlign == 0)
        {
            label.setX(20*rX);
            label.setY(aframe.top);
            label.setBackgroundColor(Color.TRANSPARENT);

        }
        else if (aAlign == 1)
        {
            label.setGravity(Gravity.CENTER);
            label.setX(0);
            label.setY(aframe.top);
            label.setBackgroundColor(Color.TRANSPARENT);
        }
        else if (aAlign == 2)
        {
            label.setGravity(Gravity.RIGHT);
            label.setX(0 - 20);
            label.setY(aframe.top);
            label.setBackgroundColor(Color.TRANSPARENT);
        }
        else if (aAlign == 3)
        {
            label.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            label.setGravity(Gravity.CENTER);
            label.setX(0);
            label.setY(aframe.top);
            label.setBackgroundColor(Color.WHITE);
        }
        label.setTextSize(12);
        return label;
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    public void createLabels()
    {
        for (int j = 0; j < nCountDevices; j++)
        {
            GTKBlueDeviceData dataDevice = GTKBleDeviceManager.arrayDevices.get(j);
            if (dataDevice.blePackets.size() > 0)
            {
                int packetCount = dataDevice.blePackets.size();
                int gasPacketCount = 0;
                for (int i = 0; i < packetCount; i++ )
                {
                    if (dataDevice.blePackets.get(i).isString)
                    {
                        continue; //go to next packet
                    }
                    gasPacketCount += 1;
                }
                int iPacketCount = -1;
                for (int i = 0; i < dataDevice.blePackets.size(); i++ )
                {
                    (GTKBleDeviceManager.arrayDevices.get(j)).nIndex = j * packetCount + i;
                    if (dataDevice.blePackets.get(i).isString)
                    {
                        continue; //go to next packet
                    }
                    iPacketCount += 1;
                    String strDeviceName = dataDevice.strDeviceName;

                    int ntopCont = (int)((GTKGlobal.G_HIGH_GRAPH * ((j*gasPacketCount + iPacketCount) + 1) + (j*gasPacketCount + iPacketCount) * (int)(initPosYGraph))*rY);
                    TextView labDevice = createLabel( strDeviceName, new Rect(0, ntopCont, (int)(scrollRelat.getWidth()/3), ntopCont + (int)(20*rY)), 0);

                    scrollRelat.addView(labDevice);
                    arrayLabels.add(labDevice);
                }
                iPacketCount = -1;
                for (int i = 0; i < packetCount; i++ )
                {
                    if (dataDevice.blePackets.get(i).isString)
                    {
                        continue; //go to next packet
                    }
                    iPacketCount += 1;
                    String strGas = dataDevice.blePackets.get(i).name;
                    String strUnit = dataDevice.blePackets.get(i)._units;
                    strUnit = " - " + strUnit;
                    int ntopCont = (int)((GTKGlobal.G_HIGH_GRAPH * ((j*gasPacketCount + iPacketCount) + 1) + (j*gasPacketCount + iPacketCount) * (int)(initPosYGraph))*rY);
                    TextView labGas = createLabel(strGas + strUnit, new Rect(0, ntopCont, (int)(scrollRelat.getWidth()), ntopCont + (int)(20*rY)), 1);

                    scrollRelat.addView(labGas);
                    arrayLabels.add(labGas);
                }
                iPacketCount = -1;
                for(int i = 0; i < packetCount; i++)
                {
                    if (dataDevice.blePackets.get(i).isString)
                    {
                        continue; //go to next packet
                    }
                    iPacketCount += 1;
                    int ntopCont = (int)((GTKGlobal.G_HIGH_GRAPH * ((j*gasPacketCount + iPacketCount) + 1) + (j*gasPacketCount + iPacketCount) * (int)(initPosYGraph))*rY);
                    final TextView labDetails = createLabel("<Details>", new Rect(0, ntopCont, (int)(scrollRelat.getWidth()), ntopCont + (int)(20*rY)), 2);
                    labDetails.setTextColor(Color.BLUE);
                    labDetails.setAlpha(0.8f);
                    labDetails.setTag((j*packetCount + i));
                    labDetails.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
//                            didTap(labDetails.getTag());
                        }
                    });
                    labDetails.setOnTouchListener(new View.OnTouchListener() {
                        @Override
                        public boolean onTouch(View view, MotionEvent motionEvent) {

                            return false;
                        }
                    });

                    scrollRelat.addView(labDetails);
                    arrayLabels.add(labDetails);
                }

                iPacketCount = -1;
                for (int i = 0; i < dataDevice.blePackets.size(); i++)
                {
                    (GTKBleDeviceManager.arrayDevices.get(j)).nIndex = j * packetCount + i;
                    if (dataDevice.blePackets.get(i).isString)
                    {
                        continue; //go to next packet
                    }
                    iPacketCount += 1;

                    Double maxV = dataDevice.blePackets.get(i).getMaxValue();


                    String strMaxV = Double.toString(maxV);
                    int ntopCont = (int)((( GTKGlobal.G_HIGH_GRAPH * ((j*gasPacketCount + iPacketCount)) + (j*gasPacketCount + iPacketCount) * (int)(initPosYGraph) + 20) *rY));
                    TextView labDevice = createLabel(strMaxV, new Rect(0, ntopCont, (int)(scrollRelat.getWidth()/7), ntopCont + (int)(20*rY)), 3);

                    scrollRelat.addView(labDevice);
                    arrayLabels.add(labDevice);
                }
            }
        }
    }

    void didTap(Object sender)
    {
        for (int j = 0; j < nCountDevices; j++)
        {
            GTKBlueDeviceData dataDevice = GTKBleDeviceManager.arrayDevices.get(j);
            int packetCount = dataDevice.blePackets.size();
            for ( int i = 0; i < packetCount; i++)
            {
//                if (((TextView) sender).getTag() == j*packetCount + i)
//                {
//                    GTKGlobal.g_data.clear();
//                    GTKGlobal.g_data = dataDevice.blePackets.get(i)._value;
//                    GTKGlobal.g_countFrame = dataDevice.blePackets.get(i)._value.size();
//
//                }
            }
        }

//        let detailVC:GTKGraphDetailsVC = UIStoryboard(name:"MainMenu", bundle: nil).instantiateViewController(withIdentifier: "GraphDetailsViewController") as! GTKGraphDetailsVC
//        self.navigationController?.pushViewController(detailVC, animated: true)
//
//        hideTapBar()
    }

    class GTKDrawingView extends View {

        float scaleView = 1.0f;
        int countDevice = 1;
        Rect rectMyView = new Rect();


        public GTKDrawingView(Context context) {
            super(context);
            countDevice = GTKBleDeviceManager.getDevicesCount();
        }
        @Override
        protected void onDraw(Canvas canvas)
        {
            super.onDraw(canvas);
            drawFillColors(canvas);
            drawAxis(canvas);
            drawDataPointsLine(canvas);
        }

        void drawFillColors(Canvas canvas)
        {
            for (int j = 0; j <countDevice; j++ )
            {
                GTKBlueDeviceData dataDevice = GTKBleDeviceManager.arrayDevices.get(j);
                int packetCount = dataDevice.blePackets.size();
                int gasPacketCount = 0;
                for(int i = 0; i < packetCount; i++)
                {
                    if (dataDevice.blePackets.get(i).isString)
                    {
                        continue; //go to next packet
                    }
                    gasPacketCount += 1;
                }
                int iPacketCount = -1;
                for(int i = 0; i < packetCount; i++)
                {
                    if (dataDevice.blePackets.get(i).isString)
                    {
                        continue; //go to next packet
                    }
                    iPacketCount += 1;


                    Paint paint = new Paint();
                    paint.setAntiAlias(true);
                    paint.setColor(Color.RED);
                    paint.setAlpha(100);

                    int nLeft = (int)initPosXGraph;
                    int nTop = (int)((initPosYGraph + (float)((j*gasPacketCount + iPacketCount) * (GTKGlobal.G_HIGH_GRAPH + 20)))*rY);
                    int nRight = (int)((rectMyView.width() )/scaleView - initPosXGraph);
                    int nBottom = nTop + (int)((GTKGlobal.G_HIGH_GRAPH - 25)/3*rY);

                    Rect rectangle = new Rect(nLeft, nTop, nRight, nBottom);
                    canvas.drawRect(rectangle, paint);

                    Paint paint1 = new Paint();
                    paint1.setAntiAlias(true);
                    paint1.setColor(Color.YELLOW);
                    paint1.setAlpha(100);

                    nLeft = (int)initPosXGraph;
                    nTop = (int)((initPosYGraph + (float)((j*gasPacketCount + iPacketCount) * (GTKGlobal.G_HIGH_GRAPH + 20)) + (float)(GTKGlobal.G_HIGH_GRAPH - 25)/3)*rY);
                    nRight = (int)((rectMyView.width() )/scaleView - initPosXGraph);
                    nBottom = nTop + (int)((GTKGlobal.G_HIGH_GRAPH - 25)/3*rY);

                    Rect rectangle1 = new Rect(nLeft, nTop, nRight, nBottom);
                    canvas.drawRect(rectangle1, paint1);

                    Paint paint2 = new Paint();
                    paint2.setAntiAlias(true);
                    paint2.setColor(Color.GREEN);
                    paint2.setAlpha(100);

                    nLeft = (int)initPosXGraph;
                    nTop = (int)((initPosYGraph + (float)((j*gasPacketCount + iPacketCount) * (GTKGlobal.G_HIGH_GRAPH + 20)) + (float)(GTKGlobal.G_HIGH_GRAPH - 25)/3*2)*rY);
                    nRight = (int)((rectMyView.width() )/scaleView - initPosXGraph);
                    nBottom = nTop + (int)((GTKGlobal.G_HIGH_GRAPH - 25)/3*rY);

                    Rect rectangle2 = new Rect(nLeft, nTop, nRight, nBottom);
                    canvas.drawRect(rectangle2, paint2);

                }
            }


        }

        void drawAxis(Canvas canvas)
        {
            for (int k = 0; k < countDevice; k++)
            {
                GTKBlueDeviceData dataDevice = GTKBleDeviceManager.arrayDevices.get(k);
                int packetCount = dataDevice.blePackets.size();
                int gasPacketCount = 0;
                for(int i = 0; i < packetCount; i++)
                {
                    if (dataDevice.blePackets.get(i).isString)
                    {
                        continue; //go to next packet
                    }
                    gasPacketCount += 1;
                }
                int iPacketCount = -1;
                for(int i = 0; i < packetCount; i++)
                {
                    if( dataDevice.blePackets.get(i).isString)
                    {
                        continue; //go to next packet
                    }
                    iPacketCount += 1;

                    Paint paint = new Paint();
                    paint.setColor(Color.BLACK);
                    paint.setStrokeWidth(5);
//                    paint.setStyle(Paint.Style.STROKE);
                    canvas.drawLine(initPosXGraph,
                                    (int)((initPosYGraph + (float)((k*gasPacketCount + iPacketCount) * (GTKGlobal.G_HIGH_GRAPH + 20)))*rY),
                                    initPosXGraph,
                                    (int)((initPosYGraph + (float)((k*gasPacketCount + iPacketCount) * (GTKGlobal.G_HIGH_GRAPH + 20)) + (float)(GTKGlobal.G_HIGH_GRAPH - 25))*rY),
                                    paint
                    );
                    canvas.drawLine(initPosXGraph,
                            (int)((initPosYGraph + (float) ((k*gasPacketCount + iPacketCount) * (GTKGlobal.G_HIGH_GRAPH + 20)) + (float) (GTKGlobal.G_HIGH_GRAPH - 25))*rY),
                            (int)((rectMyView.width() )/scaleView - initPosXGraph),
                            (int)((initPosYGraph + (float) ((k*gasPacketCount + iPacketCount) * (GTKGlobal.G_HIGH_GRAPH + 20)) + (float) (GTKGlobal.G_HIGH_GRAPH - 25))*rY),
                            paint
                    );

                }
                iPacketCount = -1;
                for(int i = 0; i < packetCount; i++)
                {
                    if( dataDevice.blePackets.get(i).isString)
                    {
                        continue; //go to next packet
                    }
                    iPacketCount += 1;
                    for (int j = 0; j <= 20; j++)
                    {
                        Paint paint = new Paint();
                        paint.setColor(Color.argb(125, 0, 0, 0));
                        paint.setStrokeWidth(1);

                        int xValue = (int)(initPosXGraph + ((rectMyView.width() )/scaleView - 2 * initPosXGraph)/20 * (j));
                        int yValue = (int)((initPosYGraph + (float) ((k*gasPacketCount + iPacketCount) * (GTKGlobal.G_HIGH_GRAPH + 20)))*rY);
                        int xxValue = (int)(initPosXGraph + ((rectMyView.width() )/scaleView - 2 * initPosXGraph)/20 * (j));
                        int yyValue = (int)((initPosYGraph + (float) ((k*gasPacketCount + iPacketCount) * (GTKGlobal.G_HIGH_GRAPH + 20)) + (float) (GTKGlobal.G_HIGH_GRAPH - 25))*rY);

                        canvas.drawLine(xValue,
                                yValue,
                                xxValue,
                                yyValue,
                                paint
                        );

                    }

                }
                iPacketCount = -1;
                for(int i = 0; i < packetCount; i++)
                {
                    if( dataDevice.blePackets.get(i).isString)
                    {
                        continue; //go to next packet
                    }
                    iPacketCount += 1;
                    for (int j = 0; j <= 10; j++)
                    {
                        Paint paint = new Paint();
                        paint.setColor(Color.GRAY);
                        paint.setStrokeWidth(1);
                        paint.setAlpha(125);

                        int xValue = (int)(initPosXGraph);
                        int yValue = (int)((initPosYGraph + (float) ((k*gasPacketCount + iPacketCount) * (GTKGlobal.G_HIGH_GRAPH + 20)) + (float) (GTKGlobal.G_HIGH_GRAPH - 25)
                                - (float) (GTKGlobal.G_HIGH_GRAPH - 25)/10 * (j))*rY);
                        int xxValue = (int)((rectMyView.width() )/scaleView - initPosXGraph);
                        int yyValue = (int)((initPosYGraph
                                + (float) ((k*gasPacketCount + iPacketCount) * (GTKGlobal.G_HIGH_GRAPH + 20)) + (float) (GTKGlobal.G_HIGH_GRAPH - 25) - (float) (GTKGlobal.G_HIGH_GRAPH - 25)/10 * j)*rY);

                        canvas.drawLine(xValue,
                                yValue,
                                xxValue,
                                yyValue,
                                paint
                        );

                    }

                }
            }

        }

        void drawDataPointsLine(Canvas canvas)
        {
            Paint paint = new Paint();
            paint.setColor(Color.BLACK);
            paint.setStrokeWidth(3);

            Double nDiv = 100.0;

            for (int k = 0; k < countDevice; k++ )
            {
                GTKBlueDeviceData dataDevice = GTKBleDeviceManager.arrayDevices.get(k);
                int packetCount = dataDevice.blePackets.size();
                int gasPacketCount = 0;
                for ( int i = 0; i < packetCount; i++)
                {
                    if (dataDevice.blePackets.get(i).isString)
                    {
                        continue; //go to next packet
                    }
                    gasPacketCount += 1;
                }
                int iPacketCount = -1;
                for ( int i = 0; i < packetCount; i++)
                {
                    if (dataDevice.blePackets.get(i).isString)
                    {
                        continue; //go to next packet
                    }
                    iPacketCount += 1;

                    ArrayList<Double> dataTmp = new ArrayList<Double>();

                    if (dataDevice.blePackets.get(i)._value.size() == 0)
                    {
                        continue;
                    }
                    dataTmp = dataDevice.blePackets.get(i)._value;

                    if (dataTmp.size() > 20)
                    {
                        ArrayList<Double> dataTmpTmp = new ArrayList<Double>();
                        for(int j = (dataTmp.size() - 20); j <= (dataTmp.size()-1); j++)
                        {
                            dataTmpTmp.add(dataTmp.get(j));
                        }
                        nDiv = getMaximValue(dataTmpTmp);
                        for ( int j = (dataTmp.size() - 20); j < dataTmp.size(); j++)
                        {
                            int xValue = (int)( initPosXGraph +
                                    ((rectMyView.width() )/scaleView - 2 * initPosXGraph)/20 * (j+1) - ((rectMyView.width() )/scaleView - 2 * initPosXGraph)/20 * (dataTmp.size() - 20));
                            int yValue = (int) ((initPosYGraph
                                    + (float)((k*gasPacketCount + iPacketCount) * (GTKGlobal.G_HIGH_GRAPH + 20)) +
                                    (GTKGlobal.G_HIGH_GRAPH - 25) - (GTKGlobal.G_HIGH_GRAPH - 25) / (nDiv) * (dataTmp.get(j)))*rY);

                            int xValue2 = (int)(initPosXGraph
                                    + ((rectMyView.width() )/scaleView - 2 * initPosXGraph)/20 * (j) - ((rectMyView.width() )/scaleView - 2 * initPosXGraph)/20 * (dataTmp.size() - 20));
                            int yValue2 = (int) ((initPosYGraph
                                    + ((k*gasPacketCount + iPacketCount) * (GTKGlobal.G_HIGH_GRAPH + 20)) + (GTKGlobal.G_HIGH_GRAPH - 25) - (GTKGlobal.G_HIGH_GRAPH - 25) / (nDiv) * (dataTmp.get(j-1)))*rY);

                            canvas.drawLine(xValue,
                                    yValue,
                                    xValue2,
                                    yValue2,
                                    paint
                            );
                        }
                    }
                    else
                    {
                        if (dataTmp.size() == 0)
                        {
                            return;
                        }
                        for ( int j = 0; j < dataTmp.size(); j++)
                        {
                            nDiv = getMaximValue(dataTmp);
                            if (j == 0)
                            {
                                Point othPoint = new Point( (int)initPosXGraph,
                                        (int)((initPosYGraph + ((k*gasPacketCount + iPacketCount) * (GTKGlobal.G_HIGH_GRAPH + 20)) + (GTKGlobal.G_HIGH_GRAPH - 25))*rY) );

                                Point onethPoint =  new Point( (int)(initPosXGraph + ((rectMyView.width() )/scaleView - 2 * initPosXGraph)/20),
                                        (int)((initPosYGraph +
                                            ((k*gasPacketCount + iPacketCount) * (GTKGlobal.G_HIGH_GRAPH + 20)) +
                                                (GTKGlobal.G_HIGH_GRAPH - 25) - (GTKGlobal.G_HIGH_GRAPH - 25) / (nDiv) * (dataTmp.get(0)))*rY));

                                canvas.drawLine(othPoint.x,
                                        othPoint.y,
                                        onethPoint.x,
                                        onethPoint.y,
                                        paint
                                );
                            }
                            else
                            {
                                int xValue = (int)(initPosXGraph + ((rectMyView.width() )/scaleView - 2 * initPosXGraph)/20 * (j+1));
                                int yValue = (int)((initPosYGraph +
                                        ((k*gasPacketCount + iPacketCount) * (GTKGlobal.G_HIGH_GRAPH + 20)) +
                                        (GTKGlobal.G_HIGH_GRAPH - 25) - (GTKGlobal.G_HIGH_GRAPH - 25) / (nDiv) * (dataTmp.get(j)))*rY);

                                int xValue2 = (int)(initPosXGraph + ((rectMyView.width() )/scaleView - 2 * initPosXGraph)/20 * (j));
                                int yValue2 = (int)((initPosYGraph +
                                        ((k*gasPacketCount + iPacketCount) * (GTKGlobal.G_HIGH_GRAPH + 20)) +
                                        (GTKGlobal.G_HIGH_GRAPH - 25) - (GTKGlobal.G_HIGH_GRAPH - 25) / (nDiv) * (dataTmp.get(j-1)))*rY);
                                canvas.drawLine(xValue,
                                        yValue,
                                        xValue2,
                                        yValue2,
                                        paint
                                );

                            }
                        }
                    }

                }
            }


        }
    }

    Double getMaximValue(ArrayList<Double> data)
    {
        Double valueMax = 0.0;
        for(int i = 0; i < data.size(); i++)
        {
            if (data.get(i) > valueMax)
            {
                valueMax = data.get(i);
            }
        }
        return valueMax;
    }
}
