package go3treks.craig.com.go3treks.Activitys;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import go3treks.craig.com.go3treks.Manager.DownloadFileFromURL;
import go3treks.craig.com.go3treks.Manager.GPSTracker;
import go3treks.craig.com.go3treks.Manager.Go3TreksConstants;
import go3treks.craig.com.go3treks.R;

public class EPALocationActivity extends AppCompatActivity{

    private float rWindowW = 0;
    private float rWindowH = 0;

    public float rX;
    public float rY;

    private ProgressBar progressBar;
    private TextView textViewProg;
    private Handler handler = new Handler();
    private Handler handlerMain = new Handler();
    private Runnable mTimer1;
    private Runnable mTimer2;

    private static final int PERMISSION_ACCESS_COARSE_LOCATION = 1;

    String dwnload_file_path = "https://s3-us-west-1.amazonaws.com//files.airnowtech.org/airnow/today/monitoring_site_locations.dat";
    private int nTime = 0;

    private TextView textViewTitle;
    private TextView textViewSite;
    private TextView textViewLat;
    private TextView textViewLong;
    private TextView textViewMile;
    GPSTracker mGPS;

//    private DownloadFileFromURL mTask;

    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_epalocation);

        Go3TreksConstants.bFoindingEPASite = true;

        getWindow().getDecorView().setBackgroundColor(Color.WHITE);

        Display display = getWindowManager().getDefaultDisplay();
        rWindowW = display.getWidth();
        rWindowH = display.getHeight();

        rX = Go3TreksConstants.getRX(rWindowW);
        rY = Go3TreksConstants.getRY(rWindowH);

        //skip button
        Button btnDone = (Button) findViewById(R.id.button_epalocation_done);
        btnDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent mainIntent = new Intent(EPALocationActivity.this, BLEDeviceActivity.class);
                EPALocationActivity.this.startActivity(mainIntent);
                EPALocationActivity.this.finish();
            }
        });
        int nBtnDoneW = (int) rWindowW / 3 * 2;
        int nBtnDoneH = (int) (50 * rY);
        btnDone.setX(rWindowW / 2 - nBtnDoneW / 2);
        btnDone.setY(rWindowH - 100 * rY - nBtnDoneH);
        RelativeLayout.LayoutParams parmsBtnDone = new RelativeLayout.LayoutParams(nBtnDoneW, nBtnDoneH);
        btnDone.setLayoutParams(parmsBtnDone);

        progressBar = (ProgressBar) findViewById(R.id.progressBar_epa);
        textViewProg = (TextView) findViewById(R.id.textView_epa_prog);
        int nTextProgW = (int) rWindowW / 3 * 2;
        int nTextProgH = (int) (50 * rY);
        textViewProg.setX(rWindowW / 2 - nTextProgW / 2);
        textViewProg.setY(rWindowH / 2 + 100 * rY - nTextProgH);
        RelativeLayout.LayoutParams parmsTxtProg = new RelativeLayout.LayoutParams(nTextProgW, nTextProgH);
        textViewProg.setLayoutParams(parmsTxtProg);
        textViewProg.setText("Finding EPA Site...");

        textViewTitle = (TextView) findViewById(R.id.textView_epa_title);
        textViewSite = (TextView) findViewById(R.id.textView_epalocation_name);
        textViewLat = (TextView)findViewById(R.id.textView_epalocation_lat);
        textViewLong = (TextView) findViewById(R.id.textView_epalocation_long);
        textViewMile = (TextView) findViewById(R.id.textView_epalocation_mile);


        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[] { Manifest.permission.ACCESS_COARSE_LOCATION },
                    PERMISSION_ACCESS_COARSE_LOCATION);
        }

        mGPS = new GPSTracker(this);
        Go3TreksConstants.myCurrentLatitude = mGPS.getLatitude();
        Go3TreksConstants.myCurrentLongitude = mGPS.getLongitude();


        new Thread(new Runnable() {
            public void run() {

                while (Go3TreksConstants.bFoindingEPASite) {
                    nTime += 1;
                    // Update the progress bar and display the
                    //current value in the text view
                    handler.post(new Runnable() {
                        public void run() {

                            if (Go3TreksConstants.bFoindingEPASite == false)
                            {
                                progressBar.setVisibility(View.INVISIBLE);
                                textViewProg.setText("");
                                resetTextViews();
                            }

                        }
                    });

//                    try {
//                        Thread.sleep(1);
//                    } catch (InterruptedException e) {
//                        e.printStackTrace();
//                    }

                }

            }
        }).start();


        new DownloadFileFromURL().execute(dwnload_file_path);

        new Thread(new Runnable() {
            public void run() {
                while (Go3TreksConstants.bHadErroe == false) {

                    // Update the progress bar and display the
                    //current value in the text view
                    handlerMain.post(new Runnable() {
                        public void run() {

                            if (Go3TreksConstants.bHadErroe == true)
                            {
                                new DownloadFileFromURL().execute(dwnload_file_path);
                                Go3TreksConstants.bHadErroe = false;

                            }
                        }
                    });

                    try {
                        Thread.sleep(1);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }

            }
        }).start();


    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_ACCESS_COARSE_LOCATION:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // All good!
                } else {
                    Toast.makeText(this, "Need your location!", Toast.LENGTH_SHORT).show();
                }

                break;
        }
    }


    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    public void resetTextViews()
    {
        textViewSite.setText(Go3TreksConstants.g_nearEPASite);
        int nTextSiteW = (int) (rWindowW /7*6);
        int nTextSiteH = (int) (80 * rY);
        textViewSite.setX(rWindowW / 2 - nTextSiteW / 2);
        textViewSite.setY(textViewTitle.getY() + 100 * rY + nTextSiteH);
        RelativeLayout.LayoutParams parmsTxtSite= new RelativeLayout.LayoutParams(nTextSiteW, nTextSiteH);
        textViewSite.setLayoutParams(parmsTxtSite);

        textViewLat.setText(String.format("Langitude : %s", Go3TreksConstants.g_SiteLat));
        int nTextLatW = (int) (rWindowW - 100*rX);
        int nTextLatH = (int) (50 * rY);
        textViewLat.setX(rWindowW / 2 - nTextLatW / 2);
        textViewLat.setY(textViewSite.getY() + 40 * rY + nTextLatH);
        RelativeLayout.LayoutParams parmsTxtLat= new RelativeLayout.LayoutParams(nTextLatW, nTextLatH);
        textViewLat.setLayoutParams(parmsTxtLat);

        textViewLong.setText(String.format("Longitude : %s", Go3TreksConstants.g_SiteLong));
        int nTextLongW = (int) (rWindowW - 100*rX);
        int nTextLongH = (int) (50 * rY);
        textViewLong.setX(rWindowW / 2 - nTextLongW / 2);
        textViewLong.setY(textViewLat.getY() + 40 * rY + nTextLongH);
        RelativeLayout.LayoutParams parmsTxtLong= new RelativeLayout.LayoutParams(nTextLongW, nTextLongH);
        textViewLong.setLayoutParams(parmsTxtLong);

        textViewMile.setText(String.format("%s maile way", Go3TreksConstants.g_nearMile));
        int nTextMileW = (int) (rWindowW - 100*rX);
        int nTextMileH = (int) (50 * rY);
        textViewMile.setX(rWindowW / 2 - nTextMileW / 2);
        textViewMile.setY(textViewLong.getY() + 40 * rY + nTextMileH);
        RelativeLayout.LayoutParams parmsTxtMile= new RelativeLayout.LayoutParams(nTextMileW, nTextMileH);
        textViewMile.setLayoutParams(parmsTxtMile);

    }

    @Override
    protected void onDestroy() {
        mGPS.stopUsingGPS();
        super.onDestroy();
    }

    @Override
    protected void onPause() {

        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
}

