package go3treks.craig.com.go3treks.model;


public class DataInfo {
    public String lat = "";
    public String longt = "";
    public String county = "";
    public String _ID = "";
    public String gas = "";
    public String gasValue = "";
    public String unit = "";
    public String city = "";
    public Double distanceToMe = 10000.0;  //init with big value

    public DataInfo()
    {
        lat = "";
        longt = "";
        county = "";
        _ID = "";
        gas = "";
        gasValue = "";
        unit = "";
        city = "";
        distanceToMe = 10000.0;
    }
}
