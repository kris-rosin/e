package go3treks.craig.com.go3treks.Fragments;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import go3treks.craig.com.go3treks.Manager.Go3TreksConstants;
import go3treks.craig.com.go3treks.R;

public class HomeFragment extends Fragment {


    private Button btnHFinishTrek;
    private Button btnHistoryTrek;
    private ImageView imgLogo;

    private float rWindowW = 0;
    private float rWindowH = 0;

    public float rX;
    public float rY;

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Display display = getActivity().getWindowManager().getDefaultDisplay();
        rWindowW = display.getWidth();
        rWindowH = display.getHeight();

        rX = Go3TreksConstants.getRX(rWindowW);
        rY = Go3TreksConstants.getRY(rWindowH);

        btnHFinishTrek = (Button)getActivity().findViewById(R.id.home_btn_finishtrek);
        int nFinishW = (int)rWindowW/2;
        int nFinishH = (int)(50*rY);
        LinearLayout.LayoutParams parmsRelatFinish = new LinearLayout.LayoutParams(nFinishW, nFinishH);
        btnHFinishTrek.setLayoutParams(parmsRelatFinish);
        btnHFinishTrek.setX((int)rWindowW/4);
        btnHFinishTrek.setY((int)rWindowH - 310*rY);
        btnHFinishTrek.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                HinishTrekFragment fragfinish = (HinishTrekFragment)getFragmentManager().findFragmentById(R.id.fragment_finish);
                if (fragfinish == null ) {
                    // Make new fragment to show this selection.
                    fragfinish = HinishTrekFragment.newInstance("finish_fragment", "param2");

                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                    ft.replace(R.id.frag_home_finish, fragfinish);
                    ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                    ft.commit();
                }


            }
        });

        btnHistoryTrek = (Button)getActivity().findViewById(R.id.home_btn_historytrek);
        int nHistW = (int)rWindowW/2;
        int nHistH = (int)(50*rY);
        LinearLayout.LayoutParams parmsRelatHist = new LinearLayout.LayoutParams(nHistW, nHistH);
        btnHistoryTrek.setLayoutParams(parmsRelatHist);
        btnHistoryTrek.setX((int)rWindowW/4);
        btnHistoryTrek.setY((int)rWindowH - 270*rY);

        btnHistoryTrek.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        imgLogo = (ImageView)getActivity().findViewById(R.id.home_img_logo);
        int nLogoW = (int)rWindowW/3;
        int nLogoH = nLogoW;
        LinearLayout.LayoutParams parmsRelatLogo = new LinearLayout.LayoutParams(nLogoW, nLogoH);
        imgLogo.setLayoutParams(parmsRelatLogo);
        imgLogo.setX((int)rWindowW/2 - nLogoW/2);
        imgLogo.setY((int)(100*rY));

    }


    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

}
