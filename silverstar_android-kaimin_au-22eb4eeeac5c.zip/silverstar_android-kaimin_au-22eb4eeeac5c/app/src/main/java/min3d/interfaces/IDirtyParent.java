package min3d.interfaces;

public interface IDirtyParent 
{
	public void onDirty();
}
