
package com.dlten.lib.frmWork;

import android.graphics.Rect;

import com.dlten.kaimin.kaimin;
import com.dlten.lib.graphics.CDCView;
import com.dlten.lib.graphics.CImgObj;
import com.dlten.lib.graphics.CPoint;
import com.dlten.lib.graphics.CRect;

public class CButton {
	private	CEventWnd m_parent = null;
	
	private	CImgObj m_nor = null;
	private	CImgObj m_foc = null;
	private	CImgObj m_dis = null;
	private	CImgObj m_chk = null;
	
	private	CPoint	m_pos = new CPoint();
	private CRect	m_rect = new CRect();
	
	private boolean	m_bEnable  = false;
	private boolean m_bVisible = false;
	private boolean	m_bChecked  = false;
	private int	m_state   = BS_NORMAL;
	private int	m_command = CMD_NONE;
	
	private boolean m_bAsyncFlag = false;
	
	
	private boolean		m_bSBTV			=	false;
	private float		m_fScaleXSBTV	=	1.f;
	private float		m_fOffsetXSBTV	=	300.f;

	public void setSBTVScale( boolean bSBTV ){
		
		m_bSBTV	=	true;
		m_fScaleXSBTV	=	480.f / 640.f;
		
	}
	
	public boolean getSBTVScale(){
		
		return m_bSBTV;
		
	}
	
    public CButton() {
    }
    
    public CButton(CEventWnd parent, CPoint point, CImgObj nor, CImgObj foc, CImgObj dis) {
    	create(parent, point, nor, foc, dis, null);
    }

    public CButton(CEventWnd parent, CImgObj nor, CImgObj foc, CImgObj dis) {
    	create(parent, new CPoint(0, 0), nor, foc, dis, null);
    }
    
    public void create(CEventWnd parent, String norName, String focName, String disName) {
    	CImgObj nor = new CImgObj( norName );
    	CImgObj foc = new CImgObj( focName );
		CImgObj dis = null;
    	if(disName != null)
    		dis = new CImgObj( disName );
    	
    	create(parent, new CPoint(0, 0), nor, foc, dis, null);
    }
    
    public void create(CEventWnd parent, String norName, String focName, String disName, String chkName) {
    	CImgObj nor = new CImgObj( norName );
    	CImgObj foc = new CImgObj( focName );
		CImgObj dis = null;
    	if(disName != null)
    		dis = new CImgObj( disName );
		CImgObj chk = null;
    	if(chkName != null)
    		chk = new CImgObj( chkName );
    	
    	create(parent, new CPoint(0, 0), nor, foc, dis, chk);
    }
    
    public void create(CEventWnd parent, CPoint point, String norName, String focName, String disName) {
    	CImgObj nor = new CImgObj( norName );
    	CImgObj foc = new CImgObj( focName );
    	CImgObj dis = new CImgObj( disName );
    	
    	create(parent, point, nor, foc, dis, null);
    }
    
    public void create(CEventWnd parent, CPoint point, CImgObj nor, CImgObj foc, CImgObj dis, CImgObj chk) {
    	m_parent = parent;
    	m_parent.AddButton(this);
    	
        m_nor = nor;
        m_foc = foc;
        m_dis = dis;
        m_chk = chk;
        
    	setPoint(point);
    	setEnable(true);
    	setVisible(true);
    	setNormal();
    }
    
    public void setImage_Normal(String norName) {
    	CImgObj nor = new CImgObj( norName );
    	m_nor = nor;
    }
    
    public void setImage_Focus(String focName) {
    	CImgObj foc = new CImgObj( focName );
    	m_foc = foc;
    }

    public void setImage_Disable(String disName) {
    	CImgObj dis = new CImgObj( disName );
    	m_dis = dis;
    }
    
    public void setImage_Normal(CImgObj nor) {
    	m_nor = nor;
    }
    
    public void setImage_Focus(CImgObj foc) {
    	m_foc = foc;
    }

    public void setImage_Disable(CImgObj dis) {
    	m_dis = dis;
    }
    
    public void destroy() {
    	m_parent.RemoveButton(this);
    	
//    	m_nor.unload();
//    	m_foc.unload();
//    	m_dis.unload();
    	
    	m_pos = null;
    	m_nor = null;
    	m_foc = null;
    	m_dis = null;
    	m_chk = null;
    	
    	m_pos = null;
    	m_rect = null;
    }
    
    public void Draw() {
    	if ( !getVisible() )
    		return;
    	
    	if ( !isEnable() ) {
    		m_dis.draw(m_pos);
    		return;
    	}
    	
    	switch (m_state) {
    	case BS_NORMAL:		if(!m_bChecked) m_nor.draw(m_pos); else m_chk.draw(m_pos);	break;
    	case BS_FOCUS:		m_foc.draw(m_pos);	break;
    	default:			break;
    	}
    }
    
    public CPoint getPoint() {
    	return m_pos;
    }

    public void setPoint(float x, float y) {
    	m_pos.x = x;
    	m_pos.y = y;
    	setRect();
    }
    
    public void setPoint(CPoint point) {
    	m_pos = point;
    	setRect();
    }

    public CRect getRect() {
    	return m_rect;
    }

    private void setRect() {
//    	m_rect.left   = m_pos.x * CDCView.m_fPosScaleXFrom640;
//    	m_rect.top    = m_pos.y * CDCView.m_fPosScaleYFrom960;
//    	m_rect.width  = m_nor.getRect().width * CDCView.m_fScale;
//    	m_rect.height = m_nor.getRect().height * CDCView.m_fScale;
    	m_rect.left   = m_pos.x;
    	m_rect.top    = m_pos.y;
/*// for OpenGL
    	m_rect.width  = m_nor.getRect().width * 640 / CDCView.RES_WIDTH;
    	m_rect.height = m_nor.getRect().height * 960 / CDCView.RES_HEIGHT;
*/
    	m_rect.width  = m_nor.getRect().width * 640 / CDCView.SC_VIEW_WIDTH;
    	m_rect.height = m_nor.getRect().height * 960 / CDCView.SC_VIEW_HEIGHT;
    	
    	//kjh start
    	nLeft	=	( int ) ( m_rect.left * 480.f / 640.f) + 240;
    	nTop	=	( int ) ( m_rect.top   * 640.f / 960.f);
    	nRight	=	( int ) ( nLeft + m_nor.getRect().width * ( 480.f / 640.f ) );
    	nBottom	=	( int ) ( nTop  + m_nor.getRect().height * ( 480.f / 640.f ) );
    	//kjh end
    }
    
    int	nLeft, nTop, nRight, nBottom;
    public boolean isInside(CPoint pt) {
    	if ( !getVisible() || !isEnable() )
    		return false;
    	//kjh start
//    	return m_rect.PtInRect(pt);
    	 
    	if( kaimin.m_bSBTV ){
    		if( m_rect == null )
    			return false;
    		
//    		if( nLeft >= pt.x && nRight <= pt.x && nTop >= pt.y && nBottom <= pt.y )
    		if( nLeft <= pt.x && nRight >= pt.x ){
    			if( nTop <= pt.y && nBottom >= pt.y )
    				return true;
    			else 
    				return false;
    		}
    		else
    			return false;
    			
    	}else{
    		return m_rect.PtInRect(pt);
    	}
    	//kjh end
    }

    public boolean isEnable() {
    	return m_bEnable;
    }
    
    public void setEnable(boolean enable) {
    	m_bEnable = enable;
    }
    
    public boolean getVisible() {
    	return m_bVisible;
    }
    
    public void setVisible(boolean bVisible) {
    	m_bVisible = bVisible;
    }
    
    public int getState() {
    	return m_state;
    }
    
    public void setState(int state) {
    	m_state = state;
    }
    
    public void setNormal() {
    	m_state = BS_NORMAL;
    }
    
    public void setFocus() {
    	m_state = BS_FOCUS;
    }
    
    public int getCommand() {
    	return m_command;
    }
    
    public void setCommand(int cmd) {
    	m_command = cmd;
    }
    
    public void setChecked(boolean bChecked) {
    	m_bChecked = bChecked;
    }
    
    public void setAsyncFlag(boolean flag) {
    	m_bAsyncFlag = flag;
    }
    
    public boolean getAsyncFlag() {
    	return m_bAsyncFlag;
    }
    
    public static final int
    	CMD_NONE   = -1,
    	
    	BS_NORMAL  = 1,
    	BS_FOCUS   = 2;
}
