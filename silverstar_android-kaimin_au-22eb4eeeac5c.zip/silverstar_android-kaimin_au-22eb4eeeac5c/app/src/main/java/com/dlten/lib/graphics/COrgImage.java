package com.dlten.lib.graphics;

import android.graphics.Bitmap;
import android.graphics.Matrix;

import com.dlten.lib.CBaseView;
import com.dlten.lib.file.CResFile;

/**
 * <p>Title: CImage class</p>
 *
 * <p>Description: Image split & managing class</p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * @version 1.0
 */
public class COrgImage {

	private static float m_fResScaleX;
	private static float m_fResScaleY;
	private static Matrix m_ResMatrix = null;
	
	public static void setResScale(float fResScaleX, float fResScaleY) {
		m_fResScaleX = fResScaleX;
		m_fResScaleY = fResScaleY;
		if((fResScaleX != 1) || (m_fResScaleY != 1)) {
			m_ResMatrix = new Matrix();
			m_ResMatrix.postScale(fResScaleX, fResScaleY);
		}
	}

	// static members.
	private static CBaseView m_dcView = null;
	
    public static void Initialize( CBaseView dcView ) {
    	m_dcView = dcView;
        CBmpManager.Initialize();
    }
    public static CBaseView getDCView() {
    	return m_dcView;
    }

    // Main Object Functions.
    private Bitmap m_img = null;
    public COrgImage() {}
    
    public void load( String strAsset, boolean bRealSize ) {
    	byte[] byResult = CResFile.load(strAsset);
    	load( byResult, bRealSize );
    	byResult = null;
    }
/*    public void load( int nResID ) {
    	byte[] byResult = CResFile.load(nResID);
    	load( byResult, false );
    }*/
    private void load( byte[] byData, boolean bRealSize ) {
    	setImage( CBmpManager.loadImage(byData), bRealSize );
    }
    public void destroy() {
    	if(m_img != null) {
    		m_img.recycle();
    		m_img = null;
    	}
    }
    protected void setImage( Bitmap bmp, boolean bRealSize ) {
//    	if ((m_img != null) && (bmp == null))
//    		m_img.recycle();

    	// for OpenGL
//    	m_img = bmp;

    	// No OpenGL
    	if(bmp == null)
    		m_img = null;
    	else {
    		if((m_ResMatrix == null) || bRealSize)
    			m_img = bmp;
    		else {
    			m_img = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m_ResMatrix, true);
    			bmp.recycle();
    			bmp = null;
    		}
    	}
    }

    protected Bitmap getImage() {
    	return m_img;
    }

    protected int getWidth() {
    	if( m_img == null )
    		return 0;
    	return m_img.getWidth();
    }
    protected int getHeight() {
    	if( m_img == null )
    		return 0;
    	return m_img.getHeight();
    }

    public int[] getRGBData() {
    	if (m_img == null )
    		return null;
    	return getRGBData( 0, 0, m_img.getWidth(), m_img.getHeight() );
    }
    public int[] getRGBData(int x, int y, int w, int h ) {
    	return CBmpManager.getRGBData(m_img, x, y, w, h);
    }
/*
    public static float[] getLeftTopPos( float nWidth, float nHeight, int nAnchor ) {
    	return CBmpManager.getLeftTopPos(nWidth, nHeight, nAnchor);
    }
*/
    
    public static final int ANCHOR_TOP = CBmpManager.ANCHOR_TOP;
    public static final int ANCHOR_MIDDLE = CBmpManager.ANCHOR_MIDDLE;
    public static final int ANCHOR_VCENTER = CBmpManager.ANCHOR_MIDDLE;
    public static final int ANCHOR_BOTTOM = CBmpManager.ANCHOR_BOTTOM;
    public static final int ANCHOR_LEFT = CBmpManager.ANCHOR_LEFT;
    public static final int ANCHOR_HCENTER = CBmpManager.ANCHOR_CENTER;
    public static final int ANCHOR_CENTER = CBmpManager.ANCHOR_CENTER;
    public static final int ANCHOR_RIGHT = CBmpManager.ANCHOR_RIGHT;

    public static final int ANCHOR_V_FILTER = CBmpManager.ANCHOR_V_FILTER;
    public static final int ANCHOR_H_FILTER = CBmpManager.ANCHOR_H_FILTER;

}
