package com.dlten.kaimin;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.preference.PreferenceManager;

public class SOManager {
	protected static final String SO_CONVERSION_URL = "http://i.socdm.com/a/s/cv.html";

	public static boolean sendScaleoutConversion(String cvId, String cUrl, Activity activity) {

		if (!isConnected(activity)) {
			return true;
		}

		if (!isFirst(activity)) {
			return true;
		}

		openConversionUrl(cvId, cUrl, activity);
		return true;
	}

	private static boolean isFirst(Activity activity) {
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(activity);
		boolean state = sp.getBoolean("SCALEOUT_CV_KEY", false);

		if (!state) {
			sp.edit().putBoolean("SCALEOUT_CV_KEY", true).commit();
			return true;
		}
		return false;
	}

	private static boolean isConnected(Activity activity) {
		ConnectivityManager cm = (ConnectivityManager)activity.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo ni = cm.getActiveNetworkInfo();
		if( ni != null ){
			return cm.getActiveNetworkInfo().isConnected();
		}
		return false;
	}


	public static void openConversionUrl(String cvId, String cUrl, Activity activity) {
		Uri uri = Uri.parse(SO_CONVERSION_URL + "?cvid=" + cvId + "&c_url=" + cUrl);
		Intent intent = new Intent(Intent.ACTION_VIEW, uri);
		activity.startActivity(intent);
	}
}

