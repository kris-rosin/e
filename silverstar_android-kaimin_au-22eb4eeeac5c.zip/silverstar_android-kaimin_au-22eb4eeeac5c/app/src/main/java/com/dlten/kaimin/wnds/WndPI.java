package com.dlten.kaimin.wnds;

import com.dlten.kaimin.Globals;
import com.dlten.kaimin.frmWndMgr;
import com.dlten.kaimin.kaimin;
import com.dlten.lib.STD;
import com.dlten.lib.file.CResFile;
import com.dlten.lib.frmWork.CButton;
import com.dlten.lib.frmWork.CWnd;
import com.dlten.lib.graphics.CDCView;
import com.dlten.lib.graphics.CImgObj;

public class WndPI extends WndTimer {

	private int m_nStep;
	private	long	m_timeProc;

	private static long OPEN_FRAME_COUNT 	= 20;
	private static long CLOSE_FRAME_COUNT 	= 20;

	private CImgObj m_imgBg   = new CImgObj();
	private CImgObj m_imgMenuBg   = new CImgObj();
	private CImgObj m_imgMenuNor   = new CImgObj();
	private CImgObj[] m_imgSpeedNor   = new CImgObj[4];
	private CImgObj[] m_imgSpeedFoc   = new CImgObj[4];
	private CImgObj m_imgBtnMenuNor   = new CImgObj();
	private CImgObj m_imgBtnMenuFoc   = new CImgObj();

	private CImgObj[] m_imgNum   = new CImgObj[11];

	private CImgObj m_imgCenter1   = new CImgObj();
	private CImgObj m_imgCenter2   = new CImgObj();

	private CButton	m_btnMenu  = null;
	private CButton	m_btnSpeed  = null;
	
	private long m_CurTime;
	private float m_fCurPos;

	private	long m_timePauseStart = 0;
	private	boolean m_bPauseFinished = false;
	private byte[] m_byPI;
	private final float[] MS_PER_LETTER = new float[] {1000, 588, 416, 333};	// 한글자당 흐르는 시간
	private final int WIDTH_PER_LETTER = 32;

	private int m_nEffectLetterPos = 0;
	private int m_nSpeed = 1;

    public static final int
    	CMD_SPEED 			= 0,
		CMD_MENU_ASYNC      = 1,
		CMD_SELECT_CLOSE	= 2;
    
    //kjh start
	private static final int	BTN_FOCUS_SPEED1				=	100;
	private static final int	BTN_FOCUS_MENU					=	105;
	
	public int					m_nCurFoucus	=	-1;
	
	public void initFocusBtns(){
		
		if( m_btnSpeed != null )
			m_btnSpeed.setNormal();
		if( m_btnMenu != null )
			m_btnMenu.setNormal();
			
	}
	
	public void updateFocusBtns( int nFocusBtn ){
		
		if( !kaimin.m_bSBTV )
			return;
		
//		if( m_nCurFoucus == nFocusBtn )
//			return;
		try {
			
			initFocusBtns();
			
			switch ( nFocusBtn ) {
				case BTN_FOCUS_MENU:
					if( m_btnMenu != null )
						m_btnMenu.setFocus();
	//				m_Btns.setFocusState( true );
					break;
				case BTN_FOCUS_SPEED1:
	//				m_btnOption.setFocusState( true );
					if( m_btnSpeed != null )
						m_btnSpeed.setFocus();
					break;
			default:
				break;
			}	
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		m_nCurFoucus	=	nFocusBtn;
		
	}
	//kjh end
	
	public void OnLoadResource() {
		//setString("PI Wnd");

		//Globals.playBGM(R.raw.bgm_opening);
		
		createImages();
		
		super.OnLoadResource();
	}
	public void OnInitWindow() {
		Globals.m_bBGMDisable = true;
		Globals.m_bSEDisable = false;
		
		readText();

		m_nStep = 0;
		m_timeProc = STD.GetTickCount();

		m_CurTime = m_timeProc;
		m_fCurPos = 0;
	}
	
	public void OnShowWindow() {
	}

	private void createImages() {
		
		//kjh start
//		m_imgBg.load("COMN/COMN_background.png");
		if( kaimin.m_bSBTV ){
			m_imgBg.load("COMN/COMN_background_sbtv_landscape.png" );
		}
		else
			m_imgBg.load("COMN/COMN_background.png");
		//kjh end
		
//		m_imgMenuBg.load("COMN/COMN_menu_back.png");
//		m_imgMenuNor.load("COMN/COMN_btn_menu_1.png");
		m_imgMenuBg.load("COMN/COMN_menu_back.png", kaimin.m_bSBTV );
		m_imgMenuNor.load("COMN/COMN_btn_menu_1.png", kaimin.m_bSBTV );
		
		for(int i = 0; i < 10; i ++) {
//			m_imgNum[i] = new CImgObj("C1/C1_num_" + i + ".png");
			m_imgNum[i] = new CImgObj("C1/C1_num_" + i + ".png", kaimin.m_bSBTV );
		}
//		m_imgNum[10] = new CImgObj("C1/C1_num_period.png");
		m_imgNum[10] = new CImgObj("C1/C1_num_period.png", kaimin.m_bSBTV );
//		m_imgCenter1.load("C1/C1_center_down.png");
//		m_imgCenter2.load("C1/C1_center_up.png");
		m_imgCenter1.load("C1/C1_center_down.png", kaimin.m_bSBTV );
		m_imgCenter2.load("C1/C1_center_up.png", kaimin.m_bSBTV );
		
//		m_imgSpeedNor[0] = new CImgObj("B1/B1_btn_speed_1_1.png");
//		m_imgSpeedFoc[0] = new CImgObj("B1/B1_btn_speed_1_2.png");
//		m_imgSpeedNor[1] = new CImgObj("B1/B1_btn_speed_2_1.png");
//		m_imgSpeedFoc[1] = new CImgObj("B1/B1_btn_speed_2_2.png");
//
//		m_imgSpeedNor[2] = new CImgObj("B1/B1_btn_speed_3_1.png");
//		m_imgSpeedFoc[2] = new CImgObj("B1/B1_btn_speed_3_2.png");
//
//		m_imgSpeedNor[3] = new CImgObj("B1/B1_btn_speed_4_1.png");
//		m_imgSpeedFoc[3] = new CImgObj("B1/B1_btn_speed_4_2.png");
//
//		m_imgBtnMenuNor.load("COMN/COMN_btn_menu_1.png");
//		m_imgBtnMenuFoc.load("COMN/COMN_btn_menu_2.png");
		
		m_imgSpeedNor[0] = new CImgObj("B1/B1_btn_speed_1_1.png", kaimin.m_bSBTV );
		
		m_imgSpeedNor[1] = new CImgObj("B1/B1_btn_speed_2_1.png", kaimin.m_bSBTV );
		
		m_imgSpeedNor[2] = new CImgObj("B1/B1_btn_speed_3_1.png", kaimin.m_bSBTV );
		
		m_imgSpeedNor[3] = new CImgObj("B1/B1_btn_speed_4_1.png", kaimin.m_bSBTV );
		

		m_imgBtnMenuNor.load("COMN/COMN_btn_menu_1.png", kaimin.m_bSBTV );
		
		
		if( kaimin.m_bSBTV ){
			m_imgSpeedFoc[0] = new CImgObj("B1/B1_btn_speed_1_2_sbtv.png", kaimin.m_bSBTV );
			m_imgSpeedFoc[1] = new CImgObj("B1/B1_btn_speed_2_2_sbtv.png", kaimin.m_bSBTV );
			m_imgSpeedFoc[2] = new CImgObj("B1/B1_btn_speed_3_2_sbtv.png", kaimin.m_bSBTV );
			m_imgSpeedFoc[3] = new CImgObj("B1/B1_btn_speed_4_2_sbtv.png", kaimin.m_bSBTV );
			m_imgBtnMenuFoc.load("COMN/COMN_btn_menu_2_sbtv.png", kaimin.m_bSBTV );
		}else{
			m_imgSpeedFoc[0] = new CImgObj("B1/B1_btn_speed_1_2.png", kaimin.m_bSBTV );
			m_imgSpeedFoc[1] = new CImgObj("B1/B1_btn_speed_2_2.png", kaimin.m_bSBTV );
			m_imgSpeedFoc[2] = new CImgObj("B1/B1_btn_speed_3_2.png", kaimin.m_bSBTV );
			m_imgSpeedFoc[3] = new CImgObj("B1/B1_btn_speed_4_2.png", kaimin.m_bSBTV );
			m_imgBtnMenuFoc.load("COMN/COMN_btn_menu_2.png", kaimin.m_bSBTV );
		}

		m_imgBg.moveTo(0, 0);
		m_imgMenuBg.moveTo(0, 899);
		m_imgMenuNor.moveTo(433, 901.5f);
		m_imgCenter1.moveTo(300, 502.5f);
		m_imgCenter2.moveTo(300, 422.5f);

		m_imgSpeedNor[0].moveTo(3, 901.5f);
		m_imgSpeedNor[1].moveTo(3, 901.5f);
		m_imgSpeedNor[2].moveTo(3, 901.5f);
		m_imgSpeedNor[3].moveTo(3, 901.5f);
		
		//kjh start
		if( kaimin.m_bSBTV ){
			
//			m_imgBg.setSBTVScale( true );
			m_imgMenuBg.setSBTVScale( true );
			m_imgMenuNor.setSBTVScale( true );
			
			for(int i = 0; i <= 10; i ++)
				m_imgNum[i].setSBTVScale( true );
			
			m_imgCenter1.setSBTVScale( true );
			m_imgCenter2.setSBTVScale( true );
			for( int i = 0; i < 4; i++ ){
				m_imgSpeedFoc[ i ].setSBTVScale( true );
				m_imgSpeedNor[ i ].setSBTVScale( true );
			}
			m_imgBtnMenuNor.setSBTVScale( true );
			m_imgBtnMenuFoc.setSBTVScale( true );
			
		}
		//kjh end
	}
	
	public void createButtons() {
		CButton	btn = null;

		btn = createButton(
				m_imgBtnMenuNor,
				m_imgBtnMenuFoc,
				null);
		btn.setPoint(433, 901.5f);
		btn.setCommand( CMD_MENU_ASYNC );
		btn.setAsyncFlag(true);
		m_btnMenu = btn;

		btn = createButton(
				m_imgSpeedNor[1],
				m_imgSpeedFoc[1],
				null);
		btn.setPoint(3, 901.5f);
		btn.setCommand( CMD_SPEED );
		m_btnSpeed = btn;
		
		updateFocusBtns( BTN_FOCUS_SPEED1 );
		
	}
	
	private void readText() {
		m_byPI = CResFile.load("314.txt");
		for(int i = 0; i < m_byPI.length; i ++) {
			if(m_byPI[i] == '.')
				m_byPI[i] = 10;
			else
				m_byPI[i] -= '0';
		}
	}
	
	public void OnPaint() {
		// drawing dimmension is just Globals.RES_WIDTH * Globals.RES_HEIGHT
		drawBackGround();
		drawPI();
		
		int nAlpha = GetStepAlpha();
		setViewAlpha(nAlpha);
		
		super.OnPaint();
	}
	
	public void OnKeyDown( int keycode ) {
		switch (keycode) {
		case KEY_MENU:		OnMenu();						break;
		case KEY_BACK:		OnExit();						break;
		
		//kjh start
		case KEY_DPAD_CENTER:
			onDPADCenter();
			break;
		case KEY_DPAD_UP:
			onUpKey();
			break;
		case KEY_DPAD_LEFT:
			onLeftKey();
			break;
		case KEY_DPAD_RIGHT:
			onRightKey();
			break;
		//kjh end
		
		default:			super.OnKeyDown(keycode);		break;
		}
	}
	
	//kjh start
	
	public void onDPADCenter(){
		
		if( m_nCurFoucus == BTN_FOCUS_MENU )
			OnOption();
		else
			OnSpeed();
		
	}
	
	public void onLeftKey(){
		if( m_nCurFoucus == BTN_FOCUS_MENU )
			updateFocusBtns( BTN_FOCUS_SPEED1 );
//		else
//			updateFocusBtns( BTN_FOCUS_MENU );
	}
	
	public void onRightKey(){
		if( m_nCurFoucus == BTN_FOCUS_SPEED1 )
			updateFocusBtns( BTN_FOCUS_MENU );
//		else
//			updateFocusBtns( BTN_FOCUS_MENU );
	}
	
	public void onDownKey(){
		
	}
	
	public void onUpKey(){
		
	}
	//kjh end
	public void OnCommand(int nCmd) {
		if(m_nStep != 1)
			return;
    	switch (nCmd) {
    	case CMD_SPEED:			OnSpeed();	break;
    	case CMD_MENU_ASYNC:	OnOption();	break;
    	case CMD_SELECT_CLOSE:	Close();	break;
    	}
    }
	
	public void OnExit() {
		Close();
	}

	public void OnSpeed() {
		updateFocusBtns( BTN_FOCUS_SPEED1 );				//kjh
		m_nSpeed ++;
		if(m_nSpeed >= 4)
			m_nSpeed = 0;
		m_btnSpeed.setImage_Normal(m_imgSpeedNor[m_nSpeed]);
		m_btnSpeed.setImage_Focus(m_imgSpeedFoc[m_nSpeed]);
	}

	public void MessageBoxClosed(int dlgid) {
		switch(dlgid) {
		case 2:
			if(Globals.m_bShowYesNo) {
//		        getView().getActivity().showDialog(3);			//kjh
		        getView().getActivity().showAlertDialog( 3 );	//kjh

			}
			else {
				resume();
			}
			if (Globals.m_bClickClose) { // if user clicks close button, ...
				OnClickMenuClose();
			}
			break;
		case 3:
			if(Globals.m_bSelYes) {
				PostMessage(WM_COMMAND, CMD_SELECT_CLOSE, 0);
			}
			else {
				resume();
			}
			break;
		}
	}

	public void OnOption() {
		updateFocusBtns( BTN_FOCUS_MENU );				//kjh
		pause();
//        getView().getActivity().showDialog(2);
        getView().getActivity().showAlertDialog( 2 );	//kjh

	}
	
	private void Close() {
		RemoveAllButtons();

		m_nStep = 2;
		m_timeProc = STD.GetTickCount();
	}

	public void OnMenu() {
	}

	private int GetStepAlpha() {
		if (m_timeProc == 0)
			return 255;

		long curTime = STD.GetTickCount();
		int	nAlpha = 255;
		long timeElapse = curTime - m_timeProc;

		if(m_nStep == 0) {
			if(timeElapse >= OPEN_FRAME_COUNT * Globals.MS_PER_FRAME) {
				m_nStep ++;
				createButtons();
				m_timeProc = curTime;
				timeElapse = 0;
			}
			else {
				float	fAlpha = 255.0f;

				fAlpha *= (float)timeElapse;
				fAlpha /= (float)(OPEN_FRAME_COUNT * Globals.MS_PER_FRAME);
				nAlpha = (int)fAlpha;
			}
		}
		if(m_nStep == 2) {
			if(timeElapse >= CLOSE_FRAME_COUNT * Globals.MS_PER_FRAME) {
				nAlpha = 0;
				DestroyWindow( frmWndMgr.WND_TITLE );
			}
			else {
				float	fAlpha = 255.0f;

				fAlpha *= (float)timeElapse;
				fAlpha /= (float)(CLOSE_FRAME_COUNT * Globals.MS_PER_FRAME);
				nAlpha = (int)(255.0 - fAlpha);
			}
		}

		return nAlpha;
	}

	private void drawBackGround() {
		m_imgBg.draw();
		m_imgMenuBg.draw();
		m_imgCenter1.draw();
		m_imgCenter2.draw();
		
		if(m_nStep != 1) {
			m_imgMenuNor.draw();
			m_imgSpeedNor[m_nSpeed].draw();
		}
	}
	
		
	private void drawPI() {
		if(m_nStep != 1)
			return;
		
		long timeElapse, curTime;
		curTime = STD.GetTickCount();

		if(m_timePauseStart != 0) {
			if(m_bPauseFinished) {
				m_CurTime = curTime;
				m_timePauseStart = 0;
			}
		}
		else {
			timeElapse = curTime - m_CurTime;
			m_fCurPos += ((float)timeElapse / MS_PER_LETTER[m_nSpeed] * WIDTH_PER_LETTER);
			
			m_CurTime = curTime;
		}

		float fCurPos = m_fCurPos;
		int nCurPos = (int)(fCurPos * CDCView.m_fPosScaleXFrom640 * CDCView.m_fScale);
		fCurPos = nCurPos / (CDCView.m_fPosScaleXFrom640 * CDCView.m_fScale);

//float fTestX=0;
		//kjh start
		float fPosX = fCurPos - 640;
		if( kaimin.m_bSBTV )
			fPosX	=	fCurPos - 1500;
		//kjh end
		
		int nPosX = (int)(fPosX / WIDTH_PER_LETTER);
		fPosX = (nPosX * WIDTH_PER_LETTER - fPosX);
		if(nPosX < 0) {
			fPosX -= (nPosX * WIDTH_PER_LETTER);
			nPosX = 0;
		}
		else if(nPosX >= m_byPI.length) {
			Close(); // Back to TITLE window
			return;
		}
		
		//kjh start
		int nEnd	=	32;
		if( kaimin.m_bSBTV )
			nEnd	=	64;
		
		for(int i = 0; i < nEnd; i ++, nPosX ++, fPosX += WIDTH_PER_LETTER) {
			if(nPosX >= m_byPI.length)
				break;
			//kjh start
			if( kaimin.m_bSBTV ){
				if(fPosX >= 1500 )
					break;		
			}else
			{
				if(fPosX >= 640)
					break;				
			}
			// kjh end
			if(m_nEffectLetterPos == nPosX) {
				if(fPosX <= 320) {
					if(m_byPI[nPosX] < 10)
						Globals.playSE(m_byPI[nPosX]);
					m_nEffectLetterPos ++;
				}
			}
			
			//kjh start
			if( kaimin.m_bSBTV )
				m_imgNum[m_byPI[nPosX]].draw(fPosX - 400, 465.5f);
			else
				m_imgNum[m_byPI[nPosX]].draw(fPosX, 465.5f);
			//kjh end
			
			
/*			if(nPosX == 0)
				fTestX = fPosX;
			else if(nPosX == 1) {
				int n1 = (int)(fTestX*CDCView.m_fPosScaleXFrom640 * CDCView.m_fScale);
				int n2 = (int)(fPosX*CDCView.m_fPosScaleXFrom640 * CDCView.m_fScale);
				STD.logout("m_fCurPos="+m_fCurPos+", x1="+fTestX+", x2="+fPosX+", n1="+n1+", n2="+n2+", n2-n1="+(n2-n1));
			}*/
		}
	}

	private void pause() {
		m_timePauseStart = STD.GetTickCount();
		m_bPauseFinished = false;
	}

	private void resume() {
		m_bPauseFinished = true;
	}

	public void OnSuspend() {
		pause();
	}

	public void OnResume() {
		resume();
	}
	
//	//kjh start
//    public int WindowProc(int message, int wParam, int lParam) {
//        switch (message) {
//
////        case WM_COMMAND:
////            OnCommand(wParam);
////            break;
////    		//kjh start
////    	case WM_GENERIC_MOVE:
//////    		processGeneric( wParam, lParam );
////    		return 0;
//    	case WM_KEY_DOWN:
//    		OnKeyDown( wParam );
//    		break;
//    		//kjh end
//        default:
//            break;
//        }
//        return 0;
//    }
//    //kjh end
}
