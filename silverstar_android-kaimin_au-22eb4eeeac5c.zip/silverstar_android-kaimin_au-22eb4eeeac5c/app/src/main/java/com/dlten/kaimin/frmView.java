package com.dlten.kaimin;

import android.content.Context;
import android.os.Handler;
import android.util.AttributeSet;
import android.widget.TextView;

import com.dlten.kaimin_auOM.R;
import com.dlten.lib.*;
import com.dlten.lib.frmWork.CWndMgr;

/**
 * <p>Title: frmView</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: dlten</p>
 *
 * @author tendroid
 * @version 1.0
 */
public class frmView extends CBaseView {
	
/*	public frmView(Context context, AttributeSet attrs){
		super( context, attrs );
		Initialize();
	}*/
	public frmView(Context context){
		super(context);
		Initialize();
	}
	private void Initialize() {
		start();
	}
	public void Finish() {
		stop();
	}
	
	public CWndMgr createWndMgr() {
		kaimin activity = (kaimin) getActivity();
		return new frmWndMgr( activity, this );
	}

}
