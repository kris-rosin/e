package com.dlten.lib.graphics;

public class CSize {
    public float w;
    public float h;

    public CSize() {
    }
    public CSize(float initCX, float initCY) { 
    	w = initCX;
    	h = initCY;
    }
    public CSize(CSize initSize) {
    	w=initSize.w;
    	h=initSize.h;
    }
    public CSize(CPoint initPt) {
    	w = initPt.x;
    	h = initPt.y;
    }
}
