package com.dlten.lib.graphics;

import static android.opengl.GLES10.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.util.ArrayList;
import java.util.concurrent.Semaphore;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGL11;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.egl.EGLSurface;
import javax.microedition.khronos.opengles.GL;
import javax.microedition.khronos.opengles.GL10;

import com.dlten.lib.STD;
import com.dlten.lib.frmWork.CEventWnd;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.opengl.GLDebugHelper;
import android.opengl.GLU;
import android.opengl.GLUtils;
import android.os.Handler;
import android.os.Message;
import android.text.TextPaint;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;

public class CGLDCView extends SurfaceView {

    // graphics relation
    private SurfaceHolder m_holder;
//    private Canvas m_canvasUpdate = null;
//    private Canvas m_canvas;
//    private Bitmap m_bmpDblBuffer;

//    private static Paint m_paintColor = new Paint();

	//public static int RES_WIDTH;
	//public static int RES_HEIGHT;

    public static int RES_WIDTH;
    public static int RES_HEIGHT;
	public static int SC_WIDTH;
	public static int SC_HEIGHT;

	private static float m_fScale;
	//private static int m_nWndOffsetX;
    //private static int m_nWndOffsetY;
    public static int m_nDblOffsetX;
    public static int m_nDblOffsetY;
    
    private float m_fAlpha;

    // font relation
    //private Typeface m_fontStyle;
    //private Paint m_font;
    //private int m_nFontSize = 36;
    //private int FONT_H;
    //private int FONT_BASELINE;

    //static private View mContext;

    public static void setResSize(Handler context, TextPaint textPaint, int width, int height) {
    	//mContext = context;
    	m_handlerTextView = context;
    	m_textPaint = textPaint;
    	
    	RES_WIDTH = 640;
    	RES_HEIGHT = 960;

		SC_WIDTH = width;
		SC_HEIGHT = height;

    	float fScaleWidth = (float)SC_WIDTH/RES_WIDTH;
		float fScaleHeight = (float)SC_HEIGHT/RES_HEIGHT;
		m_fScale = STD.MIN(fScaleWidth, fScaleHeight);

    	//m_nWndOffsetX = 0; //(nBufWidth - REAL_WIDTH) / 2;
        //m_nWndOffsetY = 0; //(nBufHeight - REAL_HEIGHT) / 2;

        if(RES_WIDTH * SC_HEIGHT > SC_WIDTH * RES_HEIGHT) {
        	m_nDblOffsetX = 0;
        	m_nDblOffsetY = (SC_HEIGHT - RES_HEIGHT * SC_WIDTH / RES_WIDTH) / 2;
        }
        else {
        	m_nDblOffsetX = (SC_WIDTH - RES_WIDTH * SC_HEIGHT / RES_HEIGHT) / 2;
        	m_nDblOffsetY = 0;
        }
        
        float size;// = m_textPaint.getTextSize();
        size = 36 * m_fScale;
        m_textPaint.setTextSize(size);
    }
    
    public CGLDCView(Context context) {
        super(context);

        initCBaseView();
        
        GLThread_Constructor();

        m_vbb.order(ByteOrder.nativeOrder());
        m_tbb.order(ByteOrder.nativeOrder());
        m_ibb.order(ByteOrder.nativeOrder());

        m_vbb0.order(ByteOrder.nativeOrder());
        m_cbb0.order(ByteOrder.nativeOrder());
        m_ibb0.order(ByteOrder.nativeOrder());

        mFVertexBuffer0 = m_vbb0.asFloatBuffer();
        mIndexBuffer0 = m_ibb0.asShortBuffer();
        
        mFVertexBuffer0.put(-0.5f); mFVertexBuffer0.put(0.5f); mFVertexBuffer0.put(0);
        mFVertexBuffer0.put(-0.5f); mFVertexBuffer0.put(-0.5f); mFVertexBuffer0.put(0);
        mFVertexBuffer0.put(0.5f); mFVertexBuffer0.put(-0.5f); mFVertexBuffer0.put(0);
        mFVertexBuffer0.put(0.5f); mFVertexBuffer0.put(0.5f); mFVertexBuffer0.put(0);
        mFVertexBuffer0.position(0);
        
        mIndexBuffer0.put((short)0);
        mIndexBuffer0.put((short)1);
        mIndexBuffer0.put((short)2);
        mIndexBuffer0.put((short)3);
        mIndexBuffer0.position(0);
    }
/*    public CDCView( Context context, AttributeSet attrs )
	{
		super( context, attrs );

		initCBaseView();
	}*/
    private void initCBaseView() {
		m_holder = getHolder();
        m_holder.setType(SurfaceHolder.SURFACE_TYPE_GPU);        

        // make font
        /*m_fontStyle = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL);
        m_font = new Paint();
        m_font.setTypeface(m_fontStyle);
        m_font.setTextSize(m_nFontSize * m_fScale);
        FONT_BASELINE = (int) m_font.getFontMetrics().descent;
        FONT_H = (int) (m_font.getFontMetrics().top - m_font.getFontMetrics().bottom);
        setFont(m_font);*/
    }
    public void prepareDC() {
        // make double buffer
/*        m_bmpDblBuffer = Bitmap.createBitmap(REAL_WIDTH, REAL_HEIGHT, Bitmap.Config.RGB_565);
        m_canvas = new Canvas(m_bmpDblBuffer);
        m_paintColor.setARGB(0, 0, 0, 0);
        fillRect(0, 0, REAL_WIDTH, REAL_HEIGHT);
        m_paintColor.setAntiAlias(true);*/
        // m_paintColor.setDither(true);
        
        GLThread_run_start();
    }
    public void releaseDC() {
    	GLThread_run_end();
    }
    
    //////////////////////////////////////////////////////////////////
    // All of UI callback functions
    ////////////////////////////////////////////////////////////////// 

	// implementing update.
    synchronized public final void update( CEventWnd pWnd ) {
    	if( pWnd == null )
    		return;

    	try {
        	GLThread_run_loop();

        	if(surfaceInitialized() && pWnd.isTextureLoaded()) {
	        	clear();
	        	setTexture(-1); // pWnd.getTextureID());
	        	pWnd.DrawPrevProc();
	        	pWnd.DrawProcess();

	        	updateGraphics();
	        	
	        	pWnd.onDrawText();
        	}
        } catch (Exception e) {
        	STD.printStackTrace(e);
        }
    }
    
    // Drawing to Graphics relation
/*    public final int[] getRGBData( int x, int y, int w, int h ) {
    	try {
	    	Bitmap imgTarget = m_bmpDblBuffer; // this.getDrawingCache();
	    	return CBmpManager.getRGBData(imgTarget, x, y, w, h);
    	} catch (Exception e) {
    		e.printStackTrace();
    		return null;
    	}
    }*/
/*    private Bitmap bmpBackup = null;
    public final void captureDisp() {
    	bmpBackup = Bitmap.createBitmap(m_bmpDblBuffer); //this.getDrawingCache();
    }
    public final void restoreDisp() {
    	if( bmpBackup != null )
    		m_canvas.drawBitmap(bmpBackup, 0, 0, null);
    }*/
/*    
    // Original Image Drawing.
    public final void drawImage( Bitmap img, float nPosX, float nPosY ) {
        if ( img == null )
            return;
        m_canvas.drawBitmap(img, nPosX, nPosY, m_paintColor);
    }
    public final void drawImage( Bitmap img, Rect rtSrc, RectF rtDest ) {
        if ( img == null )
            return;
        m_canvas.drawBitmap(img, rtSrc, rtDest, m_paintColor);
    }*/
    public final void drawImage( Bitmap img, Matrix matrix ) {
    }
/*    private Rect m_rtSrc = new Rect();
    private RectF m_rtDst = new RectF();
    public final void drawImage( Bitmap img, CRect rtSrc, CRect rtDest ) {
        if ( img == null )
            return;
        if( rtSrc == null || rtDest == null )
        	return;
        
        m_rtSrc.set((int)rtSrc.left, (int)rtSrc.top, 
        		(int)(rtSrc.left+rtSrc.width), (int)(rtSrc.top+rtSrc.height));
        m_rtDst.set(rtDest.left, rtDest.top, 
        		rtDest.left+rtDest.width, rtDest.top+rtDest.height);
        m_canvas.drawBitmap(img, m_rtSrc, m_rtDst, m_paintColor);
    }*/

/*    protected final void setClip(int[] rect ) {
        setClip(rect[0], rect[1], rect[2], rect[3]);
    }
    protected final void setClip(int x, int y, int width, int height) {
        m_canvas.clipRect(x + m_nWndOffsetX, y + m_nWndOffsetY, 
        		x + m_nWndOffsetX + width, y + m_nWndOffsetY + height, Region.Op.REPLACE);
    }
    protected final void clearClip() {
    	m_canvas.clipRect(m_nWndOffsetX, m_nWndOffsetY, 
    			m_nWndOffsetX+ REAL_WIDTH, m_nWndOffsetY + REAL_HEIGHT, Region.Op.REPLACE);
    }*/
/*    protected final void copyArea(int x, int y, int width, int height, 
    		int dx, int dy) {
    	copyArea(x, y, width, height, dx, dy, ANCHOR_LEFT | ANCHOR_TOP );
    }
    protected final void copyArea(int x, int y, int width, int height, 
    		int dx, int dy, int nAnchor) {
    	x += m_nWndOffsetX;
    	y += m_nWndOffsetY;
    	dx += m_nWndOffsetX;
    	dy += m_nWndOffsetY;
    	
    	int[] imgData = getRGBData(x, y, width, height);
    	float[] offset = CBmpManager.getLeftTopPos(width, height, nAnchor);
    	m_canvas.drawBitmap(imgData, 0, width, 
    			dx+offset[0], dy+offset[1], 
    			width, height, true, null);
    }*/
/*    public final void setLineWidth( float nWidth ) {
    	m_paintColor.setStrokeWidth(nWidth);
    }
    public final void drawLine( float nLeft, float nTop, float nRight, float nBottom ) {
        m_canvas.drawLine( nLeft + m_nWndOffsetX, nTop + m_nWndOffsetY,
                nRight + m_nWndOffsetX, nBottom + m_nWndOffsetY, m_paintColor );
    }*/
/*    protected final void drawRect( int[] rect ) {
    	drawRect( rect[0], rect[1], rect[2], rect[3] );
    }
    protected final void drawRect( int nLeft, int nTop, int nWidth, int nHeight ) {
    	m_paintColor.setStyle(Paint.Style.STROKE);
    	m_paintColor.setStrokeWidth(1);
        m_canvas.drawRect( nLeft + m_nWndOffsetX, nTop + m_nWndOffsetY,
        		nLeft + m_nWndOffsetX + nWidth, nTop + m_nWndOffsetY + nHeight, m_paintColor );
    }*/
/*    protected final void fillRect( int[] rect ) {
    	fillRect( rect[0], rect[1], rect[2], rect[3] );
    }
    protected final void fillRect( int nLeft, int nTop, int nWidth, int nHeight ) {
    	m_paintColor.setStyle(Paint.Style.FILL);
        m_canvas.drawRect( nLeft + m_nWndOffsetX, nTop + m_nWndOffsetY,
        		nLeft + m_nWndOffsetX + nWidth, nTop + m_nWndOffsetY + nHeight, m_paintColor );
    }*/
/*    public final void setColor( int nColor ) {
        int nR = (nColor >>> 16) & 0xFF;
        int nG = (nColor >>> 8) & 0xFF;
        int nB = nColor & 0xFF;

        setColor( nR, nG, nB );
    }*/
/*    public final void setColor( int nR, int nG, int nB ) {
    	setARGB(0xFF, nR, nG, nB);
    }
    public final void setARGB( int nAlpha, int nR, int nG, int nB ) {
    	m_paintColor.setARGB(nAlpha, nR, nG, nB);
    }
    public final void setAlpha( int nAlpha ) {
    	m_paintColor.setAlpha(nAlpha);
    }*/
/*    public final void setRotate( float fDegress ) {
    	setRotate( fDegress, 0, 0 );
    }
    public final void setRotate( float fDegress, int x, int y ) {
    	m_canvas.rotate(fDegress, x, y);
    }*/

    

    // ===== Old Text =====
    /*public final int setFontSize(int nSize) {
    	int	nOldSize = m_nFontSize;
    	
    	if (m_nFontSize != nSize) {
        	m_nFontSize = nSize;
    		setFont();
    	}
    	return nOldSize;
    }
    public final int getFontSize() {
    	return m_nFontSize;
    }
    protected final void setFont( Paint font ) {
        m_font = font;
    	if( m_font == null )
    		return;
        FONT_H =  (int) m_font.getTextSize();
        FONT_BASELINE = (int) m_font.ascent();
    }
    protected final void setFont() {
    	m_font.setTextSize(m_nFontSize);
        setFont(m_font);
    }
    public final Paint getFont() {
        return m_font;
    }
    protected final int getFontWidth( Paint font ) {
    	float[] fWidth = new float[1];
    	font.getTextWidths("W", fWidth);
        return (int) (fWidth[0]);
    }*/
    /*protected final int getStrWidth( String str ) {
    	if( m_font == null || str == null || str.length() <= 0 )
    		return 0;

    	float fRet = 0;
    	float[] fWidth = new float[str.length()];
    	m_font.getTextWidths(str, fWidth);
    	for( int i = 0 ; i < fWidth.length ; i++ )
    		fRet += fWidth[i];
    	
    	return (int) fRet;
    }*/

/*    public int splitString( String strBook, String[] strLine, int width ) {
    	if( m_font == null || strBook == null || strLine == null || strBook.length() <= 0 )
    		return 0;

    	int nLineCount = 0;
    	while(strBook.length() > 0) {
    		int nChar = m_font.breakText (strBook, true, width * m_fScale, null);
    		String strL = strBook.substring(0, nChar);
    		int nRet = strL.indexOf("\r\n");
    		if(nRet >= 0) {
    			strLine[nLineCount] = strBook.substring(0, nRet);
    			strBook = strBook.substring(nRet + 2);
    		}
    		else {
    			strLine[nLineCount] = strBook.substring(0, nChar);
    			strBook = strBook.substring(nChar);
    		}
    		nLineCount ++;
    	}
		STD.logout("LineCount=" + nLineCount);
    	return nLineCount;
    }

    public void splitString( String strBook, ArrayList<String> strLine, int width ) {
    	if( m_font == null || strBook == null || strLine == null || strBook.length() <= 0 )
    		return;

    	while(strBook.length() > 0) {
    		int nChar = m_font.breakText (strBook, true, width * m_fScale, null);
    		String strL = strBook.substring(0, nChar);
    		int nRet = strL.indexOf("\r\n");
    		if(nRet >= 0) {
    			strLine.add(strBook.substring(0, nRet));
    			strBook = strBook.substring(nRet + 2);
    		}
    		else {
    			strLine.add(strBook.substring(0, nChar));
    			strBook = strBook.substring(nChar);
    		}
    	}
		STD.logout("LineCount=" + strLine.size());
    }*/

    public int breakText(String strText, int start, int end, int width) {
    	if( m_textPaint == null || strText == null || strText.length() <= 0 )
    		return 0;
   		return m_textPaint.breakText (strText, start, end, true, width * m_fScale, null);
    }
    
/*    // String drawing
    public final void drawString( String str, int nPosX, int nPosY ) {
    	drawString(str, nPosX, nPosY, ANCHOR_LEFT | ANCHOR_TOP );
    }*/
    public final void drawString( String str, float nPosX, float nPosY, int nAnchor ) {
/*        if( str == null )
            return;
        
        int nGap = 0;
        int nHAnchor = nAnchor & ANCHOR_H_FILTER;
        Paint.Align newAlign;
        if( nHAnchor == ANCHOR_RIGHT )
        	newAlign = Paint.Align.RIGHT;
        else if (nHAnchor == ANCHOR_HCENTER )
        	newAlign = Paint.Align.CENTER;
        else
        	newAlign = Paint.Align.LEFT;
        m_font.setTextAlign(newAlign);

        if( (nAnchor & ANCHOR_VCENTER) != 0 ) {
            nAnchor = nAnchor & (~ANCHOR_VCENTER) | ANCHOR_BOTTOM;
            nGap = -FONT_BASELINE-FONT_H/2;
        }
        else if( (nAnchor & ANCHOR_BOTTOM) != 0 ) {
            nAnchor = nAnchor & (~ANCHOR_BOTTOM) | ANCHOR_BOTTOM;
            nGap = -FONT_BASELINE-FONT_H;
        }
        else { // if( (nAnchor & ANCHOR_TOP) != 0 ) {
            nAnchor = nAnchor & (~ANCHOR_TOP) | ANCHOR_BOTTOM;
            nGap = -FONT_BASELINE;
        }
        nPosY = nPosY + nGap;

        m_font.setColor(m_paintColor.getColor());

//        m_canvas.drawText(str, nPosX + m_nWndOffsetX, nPosY + m_nWndOffsetY, m_font);
        m_canvasUpdate.drawText(str, nPosX * m_fScale + m_nDblOffsetX, nPosY * m_fScale + m_nDblOffsetY, m_font);*/
    }
    ///////////////////////////////////////////////////////
    
    // ===== New Text =====
	public final static int
		TEXTVIEW_SETPADDING = 0,
		TEXTVIEW_SETTEXT = 1,
		TEXTVIEW_GETINFO = 2,
		TEXTVIEW_SETSCROLL = 3,
		TEXTVIEW_CLEAR = 4,
		DLG_SHOW = 5;
	private static Handler m_handlerTextView = null;
	private static TextPaint m_textPaint = null;
    private String m_TextViewStr;
    public int m_nTextViewLineCount;
    public float m_fTextTotalHeight;
    public void setTextViewPosition(int left, int top, int width, int height) {
    	left = (int)(left * m_fScale + m_nDblOffsetX);
    	top = (int)(top * m_fScale + m_nDblOffsetY);
    	width = (int)(width * m_fScale);
    	height = (int)(height * m_fScale);
    	int[] pos = new int[] {left, top, SC_WIDTH-left-width, SC_HEIGHT-top-height};
    	m_handlerTextView.sendMessage(Message.obtain(m_handlerTextView, TEXTVIEW_SETPADDING, pos));
    }
    public void setTextViewString(String text) {
    	m_TextViewStr = text;
    	m_handlerTextView.sendMessage(Message.obtain(m_handlerTextView, TEXTVIEW_SETTEXT));
    }
    public void clearTextView() {
    	m_handlerTextView.sendMessage(Message.obtain(m_handlerTextView, TEXTVIEW_CLEAR));
    }
    public String getTextViewString() {
    	return m_TextViewStr;
    }
    public void setTextViewInfo(int nTextViewLineCount, float fTextTotalHeight) {
    	m_nTextViewLineCount = nTextViewLineCount;
    	m_fTextTotalHeight = fTextTotalHeight;
    }
    public int getTextViewLineCount() {
    	if(m_nTextViewLineCount == 0) {
        	m_handlerTextView.sendMessage(Message.obtain(m_handlerTextView, TEXTVIEW_GETINFO));
    	}
    	return m_nTextViewLineCount;
    }
    public float getTextViewTotalHeight() {
    	return m_fTextTotalHeight;
    }
    public void setTextViewScroll(int nX, int nY) {
    	int[] pos = new int[] {nX, nY};
    	m_handlerTextView.sendMessage(Message.obtain(m_handlerTextView, TEXTVIEW_SETSCROLL, pos));
    }
	
	public void showDialog(int nDlgID) {
		int[] pos = new int[] {nDlgID};
		m_handlerTextView.sendMessage(Message.obtain(m_handlerTextView, DLG_SHOW, pos));
	}
    ///////////////////////////////////////////////////////*/

    
    // drawing relation
    public static final int ANCHOR_TOP = CBmpManager.ANCHOR_TOP;
    public static final int ANCHOR_MIDDLE = CBmpManager.ANCHOR_MIDDLE;
    public static final int ANCHOR_VCENTER = CBmpManager.ANCHOR_MIDDLE;
    public static final int ANCHOR_BOTTOM = CBmpManager.ANCHOR_BOTTOM;
    public static final int ANCHOR_LEFT = CBmpManager.ANCHOR_LEFT;
    public static final int ANCHOR_HCENTER = CBmpManager.ANCHOR_CENTER;
    public static final int ANCHOR_CENTER = CBmpManager.ANCHOR_CENTER;
    public static final int ANCHOR_RIGHT = CBmpManager.ANCHOR_RIGHT;

    public static final int ANCHOR_V_FILTER = CBmpManager.ANCHOR_V_FILTER;
    public static final int ANCHOR_H_FILTER = CBmpManager.ANCHOR_H_FILTER;


    
    
    //=======================================================================
	private class EglHelper {
		public EglHelper() {

		}

		/**
		* Initialize EGL for a given configuration spec.
		* 
		* @param configSpec
		*/
		public void start(int[] configSpec) {
			/*
			* Get an EGL instance
			*/
			mEgl = (EGL10) EGLContext.getEGL();

			/*
			* Get to the default display.
			*/
			mEglDisplay = mEgl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);

			/*
			* We can now initialize EGL for that display
			*/
			int[] version = new int[2];
			mEgl.eglInitialize(mEglDisplay, version);

			EGLConfig[] configs = new EGLConfig[1];
			int[] num_config = new int[1];
			mEgl.eglChooseConfig(mEglDisplay, configSpec, configs, 1,
			num_config);
			mEglConfig = configs[0];

			/*
			* Create an OpenGL ES context. This must be done only once, an
			* OpenGL context is a somewhat heavy object.
			*/
			mEglContext = mEgl.eglCreateContext(mEglDisplay, mEglConfig,
			EGL10.EGL_NO_CONTEXT, null);

			mEglSurface = null;
		}

		/*
		* Create and return an OpenGL surface
		*/
		public GL createSurface(SurfaceHolder holder) {
			/*
			* The window size has changed, so we need to create a new
			* surface.
			*/
			if (mEglSurface != null) {

				/*
				* Unbind and destroy the old EGL surface, if there is one.
				*/
				mEgl.eglMakeCurrent(mEglDisplay, EGL10.EGL_NO_SURFACE,
				EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT);
				mEgl.eglDestroySurface(mEglDisplay, mEglSurface);
			}

			/*
			* Create an EGL surface we can render into.
			*/
			mEglSurface = mEgl.eglCreateWindowSurface(mEglDisplay,
			mEglConfig, holder, null);

			/*
			* Before we can issue GL commands, we need to make sure the
			* context is current and bound to a surface.
			*/
			mEgl.eglMakeCurrent(mEglDisplay, mEglSurface, mEglSurface,
			mEglContext);


			GL gl = mEglContext.getGL();
			//if (mGLWrapper != null) {
			//	gl = mGLWrapper.wrap(gl);
			//}
			return gl;
		}

		/**
		* Display the current render surface.
		* 
		* @return false if the context has been lost.
		*/
		public boolean swap() {
			mEgl.eglSwapBuffers(mEglDisplay, mEglSurface);

			/*
			* Always check for EGL_CONTEXT_LOST, which means the context and
			* all associated data were lost (For instance because the device
			* went to sleep). We need to sleep until we get a new surface.
			*/
			return mEgl.eglGetError() != EGL11.EGL_CONTEXT_LOST;
		}

		public void finish() {
			if (mEglSurface != null) {
				mEgl.eglMakeCurrent(mEglDisplay, EGL10.EGL_NO_SURFACE,
				EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT);
				mEgl.eglDestroySurface(mEglDisplay, mEglSurface);
				mEglSurface = null;
			}
			if (mEglContext != null) {
				mEgl.eglDestroyContext(mEglDisplay, mEglContext);
				mEglContext = null;
			}
			if (mEglDisplay != null) {
				mEgl.eglTerminate(mEglDisplay);
				mEglDisplay = null;
			}
		}

		EGL10 mEgl;
		EGLDisplay mEglDisplay;
		EGLSurface mEglSurface;
		EGLConfig mEglConfig;
		EGLContext mEglContext;
	}

	// GLThread
	private volatile boolean mDone;
	private boolean mPaused;
	private boolean mHasFocus;
	private boolean mHasSurface;
	private boolean mContextLost;
	private int mWidth;
	private int mHeight;
	//private Renderer mRenderer;
	private ArrayList<Runnable> mEventQueue = new ArrayList<Runnable>();
	private EglHelper mEglHelper;

	// GLSurfaceView
	private static final Semaphore sEglSemaphore = new Semaphore(1);
	private boolean mSizeChanged = true;
	//private GLThread mGLThread;
	//private GLWrapper mGLWrapper;


	public void GLThread_surfaceCreated() {
		synchronized (this) {
			mHasSurface = true;
			mContextLost = false;
			notify();
		}
	}

	public void GLThread_surfaceDestroyed() {
		synchronized (this) {
			mHasSurface = false;
			notify();
		}
	}

	public void GLThread_onWindowResize(int w, int h) {
		synchronized (this) {
			mWidth = w;
			mHeight = h;
			mSizeChanged = true;
		}
	}

	public void GLThread_onWindowFocusChanged(boolean hasFocus) {
//		synchronized (this) {
mHasFocus = true;
//			mHasFocus = hasFocus;
//			if (mHasFocus == true) {
//				notify();
//			}
//		}
	}

	public void GLThread_Constructor(/*Renderer renderer*/) {
		//super();
		mDone = false;
		mWidth = 0;
		mHeight = 0;
		//mRenderer = renderer;
		//setName("GLThread");
	}

	private boolean GLThread_needToWait() {
		return (mPaused || ( !mHasFocus) || ( !mHasSurface) || mContextLost)
			&& ( !mDone);
	}
	
	public void GLThread_run_start() {
		try {
			try {
				sEglSemaphore.acquire();
			}
			catch (InterruptedException e) {
				return;
			}
		}
		catch (Exception e) {
			// fall thru and exit normally
			return;
		}

		mEglHelper = new EglHelper();
		/*
		* Specify a configuration for our opengl session and grab the
		* first configuration that matches is
		*/
		mEglHelper.start(null);

		GLThread_local_gl = null;
		GLThread_local_tellRendererSurfaceCreated = true;
		GLThread_local_tellRendererSurfaceChanged = true;
	}
	
	public void GLThread_run_end() {
		mEglHelper.finish();
		sEglSemaphore.release();
	}

	public void GLThread_run_initWindow(CEventWnd pWnd) {
		pCurWnd = pWnd;
		GLThread_local_tellRendererSurfaceCreated = true;
		GLThread_local_tellRendererSurfaceChanged = true;
	}
	
	public void GLThread_run_loop() throws InterruptedException {
		if(mDone)
			return;

		/*
		* Update the asynchronous state (window size)
		*/
		int w, h;
		boolean changed;
		boolean needStart = false;
		synchronized (this) {
			//Runnable r;
			//while ((r = getEvent()) != null) {
			//	r.run();
			//}
			if (mPaused) {
				mEglHelper.finish();
				needStart = true;
			}
			if (GLThread_needToWait()) {
				while (GLThread_needToWait()) {
					wait();
				}
			}
			if (mDone) {
				return;
			}
			changed = mSizeChanged;
			w = mWidth;
			h = mHeight;
			mSizeChanged = false;
		}
		if (needStart) {
			mEglHelper.start(null);
			GLThread_local_tellRendererSurfaceCreated = true;
			changed = true;
		}
		if (changed) {
			GLThread_local_gl = (GL10) mEglHelper.createSurface(m_holder);
			GLThread_local_tellRendererSurfaceChanged = true;
		}
		if (GLThread_local_tellRendererSurfaceCreated) {
			//pCurWnd.surfaceCreated(GLThread_local_gl);
			setCamera();
			GLThread_local_tellRendererSurfaceCreated = false;
		}
		if (GLThread_local_tellRendererSurfaceChanged) {
			if((GLThread_local_gl != null) && (pCurWnd != null)) {
				if(!pCurWnd.isTextureLoaded())
					pCurWnd.onLoadResource2();
				GLThread_local_tellRendererSurfaceChanged = false;
			}
		}
		if ((w > 0) && (h > 0)) {
			/* draw a frame here */
			//*********mRenderer.drawFrame(GLThread_local_gl);

			/*
			* Once we're done with GL, we need to call swapBuffers()
			* to instruct the system to display the rendered frame
			*/
			mEglHelper.swap();
		}
	}

	private CEventWnd pCurWnd;
	private GL10 GLThread_local_gl = null;
	private boolean GLThread_local_tellRendererSurfaceCreated;
	private boolean GLThread_local_tellRendererSurfaceChanged;
	
	public boolean surfaceInitialized() {
		return (GLThread_local_gl == null) ? false : true;
	}

	private int m_nTextureCount = 0;
	private Bitmap[] m_TextureBitmaps;
	private Canvas[] m_TextureCanvas;
	private int[] m_nTextureIDs;

	public void initializeTexture(int nTextureCount) {
		if(m_nTextureCount != 0) {
			int n = 0;
			n = 1 / n;
			return;
		}
		m_nTextureCount = nTextureCount;
		m_TextureBitmaps = new Bitmap[m_nTextureCount];
		m_TextureCanvas = new Canvas[m_nTextureCount];
		m_nTextureIDs = new int[m_nTextureCount];
	}

	public int createTexture(int nTextureIndex, int width, int height) {
		try {
			m_TextureBitmaps[nTextureIndex] = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_4444);//RGB_565, ARGB_4444, ARGB_8888, ALPHA_8
		}
		catch(Exception e) {
			int n = 1;
			n = n + 1;
		}
		m_TextureCanvas[nTextureIndex] = new Canvas(m_TextureBitmaps[nTextureIndex]);

		glDisable(GL_DITHER);

        /*
         * Some one-time OpenGL initialization can be made here
         * probably based on features of this particular context
         */
        glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST);

        glClearColor(0, 0, 0, 1);
        glShadeModel(GL_SMOOTH);
        glEnable(GL_DEPTH_TEST);
        glEnable(GL_TEXTURE_2D);

        /*
         * Create our texture. This has to be done each time the
         * surface is created.
         */

        int[] textures = new int[1];
        glGenTextures(1, textures, 0);

        int TextureID = textures[0];
        glBindTexture(GL_TEXTURE_2D, TextureID);

        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

//        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
//        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

//        glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

        m_nTextureIDs[nTextureIndex] = TextureID;

        return TextureID;
	}
	
	public void copyBitmap(Bitmap bmp, int nTextureIndex, int xpos, int ypos, CRect rectTexture) {
		try {
			if(xpos + bmp.getWidth() > m_TextureBitmaps[nTextureIndex].getWidth()
					|| ypos + bmp.getHeight() > m_TextureBitmaps[nTextureIndex].getHeight()) {
				STD.logout("Bitmap region overflow !!!!!!!");
				int n = 0;
				n = 1 / n;
			}
		}
		catch(Exception e) {
			int n = 0;
			n = 1 / n;
		}
		m_TextureCanvas[nTextureIndex].drawBitmap(bmp, xpos, ypos, null);
		
		rectTexture.left = (float)xpos / m_TextureBitmaps[nTextureIndex].getWidth();
		rectTexture.top = (float)ypos / m_TextureBitmaps[nTextureIndex].getHeight();
		rectTexture.width = (float)bmp.getWidth() / m_TextureBitmaps[nTextureIndex].getWidth();
		rectTexture.height = (float)bmp.getHeight() / m_TextureBitmaps[nTextureIndex].getHeight();
	}

	public void finalizeTexture() {
		for(int i = 0; i < m_nTextureCount; i ++) {
	        glBindTexture(GL_TEXTURE_2D, m_nTextureIDs[i]);

	        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

//	        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
//	        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

//	        glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

	        GLUtils.texImage2D(GL_TEXTURE_2D, 0, m_TextureBitmaps[i], 0);

	        m_TextureBitmaps[i].recycle();
	        m_TextureBitmaps[i] = null;
	        m_TextureCanvas[i] = null;
		}
        m_TextureCanvas = null;
        m_TextureBitmaps = null;
	}

	public void deleteTexture() {
        glDeleteTextures(m_nTextureCount, m_nTextureIDs, 0);
        
        m_nTextureIDs = null;
        m_nTextureCount = 0;
	}

	private void setCamera() {
        glViewport(m_nDblOffsetX, m_nDblOffsetY, SC_WIDTH-2*m_nDblOffsetX, SC_HEIGHT-2*m_nDblOffsetY);

        /*
        * Set our projection matrix. This doesn't have to be done
        * each time we draw, but usually a new projection needs to
        * be set when the viewport is resized.
        */

        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glFrustumf(-0.25f, 0.25f, -0.25f, 0.25f, 2.5f, 5.5f);
	}
	
	private int m_nCurTextureIndex;
	private void setTexture(int nTextureIndex) {
		if(nTextureIndex == -1) {
			m_nCurTextureIndex = -1;
			return;
		}

		if(m_nCurTextureIndex == nTextureIndex)
			return;
		
		m_nCurTextureIndex = nTextureIndex;
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, m_nTextureIDs[m_nCurTextureIndex]);
	}

	
	private static final int MAX_RECT_COUNT = 200;
	private ByteBuffer m_vbb = ByteBuffer.allocateDirect(MAX_RECT_COUNT * 4 * 3 * 4);
	private ByteBuffer m_tbb = ByteBuffer.allocateDirect(MAX_RECT_COUNT * 4 * 2 * 4);
	private ByteBuffer m_ibb = ByteBuffer.allocateDirect(MAX_RECT_COUNT * 4 * 2);
    private FloatBuffer mFVertexBuffer;
    private FloatBuffer mTexBuffer;
    private ShortBuffer mIndexBuffer;
    private int[] mTextureIndexes = new int[MAX_RECT_COUNT];
    private int m_nCurRectCount;

	private ByteBuffer m_vbb0 = ByteBuffer.allocateDirect(4 * 3 * 4);
	private ByteBuffer m_cbb0 = ByteBuffer.allocateDirect(4 * 4 * 4);
	private ByteBuffer m_ibb0 = ByteBuffer.allocateDirect(4 * 2);
    private FloatBuffer mFVertexBuffer0;
    private FloatBuffer mColorBuffer0;
    private ShortBuffer mIndexBuffer0;

    public final void clear() {
        /*
         * By default, OpenGL enables features that improve quality
         * but reduce performance. One might want to tweak that
         * especially on software renderer.
         */
        glDisable(GL_DITHER);

        glTexEnvx(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

        /*
         * Usually, the first thing one might want to do is to clear
         * the screen. The most efficient way of doing this is to use
         * glClear().
         */

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        /*
         * Now we're ready to draw some 3D objects
         */

        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        GLU.gluLookAt(GLThread_local_gl, 0, 0, 5, 0, 0, 0, 0, 1, 0);

        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_TEXTURE_COORD_ARRAY);

        mFVertexBuffer = m_vbb.asFloatBuffer();
        mTexBuffer = m_tbb.asFloatBuffer();
        mIndexBuffer = m_ibb.asShortBuffer();

        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
        
        m_nCurRectCount = 0;
        m_fAlpha = 1;
    }

    public final void drawImage( int nTextureIndex, float x, float y, float w, float h, float scaleX, float scaleY, CRect rectTexture ) {
    	if(m_nCurRectCount >= MAX_RECT_COUNT) {
    		STD.logout("m_nCurRectCount >= MAX_RECT_COUNT !!!!!!!!!!!!!!!!!!");
    	}
    	float zero = 0;
    	float left, top, right, bottom;

    	left = x / RES_WIDTH - 0.5f;
    	top = 0.5f - y / RES_HEIGHT;
    	right = (x + w * scaleX) / RES_WIDTH - 0.5f;
    	bottom = 0.5f - (y + h * scaleY) / RES_HEIGHT;

    	mFVertexBuffer.put(left);  	mFVertexBuffer.put(top);   	mFVertexBuffer.put(zero);
    	mFVertexBuffer.put(left);  	mFVertexBuffer.put(bottom);	mFVertexBuffer.put(zero);
    	mFVertexBuffer.put(right); 	mFVertexBuffer.put(bottom);	mFVertexBuffer.put(zero);
    	mFVertexBuffer.put(right); 	mFVertexBuffer.put(top);	mFVertexBuffer.put(zero);
    	
    	left = rectTexture.left;
    	top = rectTexture.top;
    	right = rectTexture.Right();
    	bottom = rectTexture.Bottom();
    	mTexBuffer.put(left);	mTexBuffer.put(top);
    	mTexBuffer.put(left);	mTexBuffer.put(bottom);
    	mTexBuffer.put(right);	mTexBuffer.put(bottom);
    	mTexBuffer.put(right);	mTexBuffer.put(top);
    	
    	for(int i = m_nCurRectCount * 4; i < m_nCurRectCount * 4 + 4; i ++) {
            mIndexBuffer.put((short) i);
    	}

    	mTextureIndexes[m_nCurRectCount] = nTextureIndex;
    	m_nCurRectCount ++;
    }

    private void makeAllTexture(float tex_l, float tex_t, float tex_r, float tex_b) {
    	m_nCurRectCount = 0;
    	mFVertexBuffer.position(0);
        mTexBuffer.position(0);
        mIndexBuffer.position(0);

    	float zero = 0;
    	float left, top, right, bottom;

    	left = -0.5f;
    	top = 0.5f;
    	right = 0.5f;
    	bottom = -0.5f;

    	mFVertexBuffer.put(left);  	mFVertexBuffer.put(top);   	mFVertexBuffer.put(zero);
    	mFVertexBuffer.put(left);  	mFVertexBuffer.put(bottom);	mFVertexBuffer.put(zero);
    	mFVertexBuffer.put(right); 	mFVertexBuffer.put(bottom);	mFVertexBuffer.put(zero);
    	mFVertexBuffer.put(right); 	mFVertexBuffer.put(top);	mFVertexBuffer.put(zero);
    	
    	left = tex_l;
    	top = tex_t;
    	right = tex_r;
    	bottom = tex_b;
    	mTexBuffer.put(left);	mTexBuffer.put(top);
    	mTexBuffer.put(left);	mTexBuffer.put(bottom);
    	mTexBuffer.put(right);	mTexBuffer.put(bottom);
    	mTexBuffer.put(right);	mTexBuffer.put(top);
    	
    	for(int i = m_nCurRectCount * 4; i < m_nCurRectCount * 4 + 4; i ++) {
            mIndexBuffer.put((short) i);
    	}

    	m_nCurRectCount ++;
    }

    protected final void updateGraphics() {
    	//makeAllTexture(0, 0, 1, 1); //== this is for CheckTexture

    	mFVertexBuffer.position(0);
        mTexBuffer.position(0);

        glFrontFace(GL_CW);
        glVertexPointer(3, GL_FLOAT, 0, mFVertexBuffer);
        glEnable(GL_TEXTURE_2D);
        glTexCoordPointer(2, GL_FLOAT, 0, mTexBuffer);

        for(int i = 0; i < m_nCurRectCount; i ++) {
            mIndexBuffer.position(i*4);
            setTexture(mTextureIndexes[i]);

	        glDrawElements(GL_TRIANGLE_FAN, 4, GL_UNSIGNED_SHORT, mIndexBuffer);
        }
        
        if(m_fAlpha != 1) {
            mColorBuffer0 = m_cbb0.asFloatBuffer();
            for(int i = 0; i < 4; i ++) {
                mColorBuffer0.put(0);
                mColorBuffer0.put(0);
                mColorBuffer0.put(0);
                mColorBuffer0.put(1 - m_fAlpha);
            }
            mColorBuffer0.position(0);

            glDisableClientState(GL_TEXTURE_COORD_ARRAY);
            glEnableClientState(GL_COLOR_ARRAY);
            glDisable(GL_TEXTURE_2D);

            glVertexPointer(3, GL_FLOAT, 0, mFVertexBuffer0);
            glColorPointer(4, GL_FLOAT, 0, mColorBuffer0);

	        glDrawElements(GL_TRIANGLE_FAN, 4, GL_UNSIGNED_SHORT, mIndexBuffer0);

            glEnableClientState(GL_TEXTURE_COORD_ARRAY);
            glDisableClientState(GL_COLOR_ARRAY);
            glEnable(GL_TEXTURE_2D);
        }
    }
    
    public void setAlpha(float fAlpha) {
    	m_fAlpha = fAlpha;
    }
}
