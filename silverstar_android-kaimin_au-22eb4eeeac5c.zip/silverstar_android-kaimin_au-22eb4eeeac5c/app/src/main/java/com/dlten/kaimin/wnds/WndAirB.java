package com.dlten.kaimin.wnds;

import android.content.Context;
import android.graphics.Rect;
import android.os.Vibrator;

import com.dlten.kaimin.Globals;
import com.dlten.kaimin.frmWndMgr;
import com.dlten.kaimin.kaimin;
import com.dlten.lib.STD;
import com.dlten.lib.frmWork.CButton;
import com.dlten.lib.graphics.CDCView;
import com.dlten.lib.graphics.CImgObj;

public class WndAirB extends WndTimer {

    private static final int nInitVibT = 30;
    private static final int nNextVibT = 80;
    private static final int nFirstPressT = 4;

    private static final int nCountAirBubble = 35;
    private static final float rScaleAirBubble = 110.0f/500;

    private CImgObj imgBk = new CImgObj();
    private CImgObj[] imgAirBubbles = new CImgObj[nCountAirBubble];

    private Rect[] recAirBubbles = new Rect[nCountAirBubble];

    private CImgObj imgMenuBg   	= new CImgObj();
    private CImgObj imgScoreBg   	= new CImgObj();
    private CImgObj[] imgScoreNum   = new CImgObj[10];

    private CImgObj imgMenuNor   	= new CImgObj();
    private CImgObj imgMenuFoc   	= new CImgObj();

    private int nScore = 0;

    private int m_nStep;
    private	long	m_timeProc;

    private CButton	btnMenu  = null;

    private static final int
            CMD_AUTO = 0,
            CMD_SPEED  = 1,
            CMD_MENU_ASYNC      = 2,
            CMD_SELECT_CLOSE = 3;

    private static long OPEN_FRAME_COUNT = 20;
    private static long CLOSE_FRAME_COUNT = 20;

    private int nSelectedIndex = -1;
//    private Boolean[] bSelected = new Boolean[nCountAirBubble];

    private int nStep = 0;
    private int nStepTime = 0;

    private int nResetAirBTime = 0;

    boolean bStart = false;

    @Override
    public void OnLoadResource() {
        Globals.playBGM(Globals.m_nBGMType_WndSheet);
        createImages();
        super.OnLoadResource();
    }

    @Override
    public void OnInitWindow() {
        m_nStep = 0;
        m_timeProc = STD.GetTickCount();

        Globals.m_bBGMDisable = false;
        Globals.m_bSEDisable = false;

        nSelectedIndex = -1;

        bStart = true;
        super.OnInitWindow();
    }

    @Override
    public void OnShowWindow() {
        super.OnShowWindow();
    }

    @Override
    public void OnPaint() {

        if (bStart == false)
            return;
        if (nStep == 1)
        {
            nStepTime ++;
            if (nStepTime == nFirstPressT)
            {
                imgAirBubbles[nSelectedIndex].resetImgName("G1/air_bubble_broken.png");
                imgAirBubbles[nSelectedIndex].resetImage("G1/air_bubble_broken.png", false);
//                bSelected[nSelectedIndex] = true;
                playSound();
                setVibrate(nNextVibT);
                nStep = 2;
                nStepTime += 1;

                nScore += 1;
            }
        }

        drawCreatedImages();
        int nAlpha = GetStepAlpha();
        setViewAlpha(nAlpha);

        if (isAllBroken())
        {
            nResetAirBTime ++;
            if (nResetAirBTime == 15)
            {
                resetAirBubbleImgs();
                nResetAirBTime = 0;
            }
        }

        super.OnPaint();
    }

    @Override
    public void OnKeyDown(int keycode) {
        switch (keycode) {
            case KEY_BACK:		OnExit();						break;
            case KEY_DPAD_DOWN:
            case KEY_DPAD_UP:
            case KEY_DPAD_LEFT:
            case KEY_DPAD_RIGHT:
                OnTouchDown( 0, 0 );
                return;
            //kjh end

            default:			super.OnKeyDown(keycode);		break;
        }
    }

    @Override
    public void OnCommand(int nCmd) {
        if(m_nStep != 1)
            return;
        switch (nCmd) {
            case CMD_MENU_ASYNC:	OnOption();	break;
            case CMD_SELECT_CLOSE:	OnExit();	break;
        }
        super.OnCommand(nCmd);
    }

    @Override
    public void MessageBoxClosed(int dlgid) {
        switch(dlgid) {
            case 2:
                if(Globals.m_bShowYesNo) {
                    getView().getActivity().showAlertDialog( 3 );
                }

                Globals.m_nBGMType_WndSheet = Globals.GetBGMType();

                if (Globals.m_bClickClose) { // if user clicks close button, ...
                    OnClickMenuClose();
                }
                break;
            case 3:
                if(Globals.m_bSelYes) {
                    PostMessage(WM_COMMAND, CMD_SELECT_CLOSE, 0);
                }
                break;
        }
        super.MessageBoxClosed(dlgid);
    }

    @Override
    public void onTouchDown(int wParam, int lParam) {

        if (bStart == false)
            return;
        for (int i = 0; i < nCountAirBubble; i++)
        {
            if (wParam > recAirBubbles[i].left
                    && wParam < recAirBubbles[i].right
                    && lParam > recAirBubbles[i].top
                    && lParam < recAirBubbles[i].bottom)
            {
                if (imgAirBubbles[i].strName == "G1/air_bubble_normal.png")
                {
                    setVibrate(nInitVibT);
                    nSelectedIndex = i;
                    nStep = 1;
                    nStepTime = 0;
                }

            }
        }

        super.onTouchDown(wParam, lParam);
    }

    @Override
    public boolean onTouchUp(int wParam, int lParam) {
        nStep = 3;
        return super.onTouchUp(wParam, lParam);
    }

    @Override
    public void OnSuspend() {
        if(Globals.m_nBGMType_WndSheet < Globals.m_nBGMIDs.length) {
            Globals.pauseBGM();
        }
        super.OnSuspend();
    }

    @Override
    public void OnResume() {
        if(Globals.m_nBGMType_WndSheet < Globals.m_nBGMIDs.length) {
            Globals.resumeBGM();
        }
        super.OnResume();
    }

    @Override
    public void OnDestroy() {

        bStart = false;
        OnExit();
        super.OnDestroy();
    }

    private void createImages()
    {
        if( kaimin.m_bSBTV ){
            imgBk.load( "G1/air_bubble_bk.png" );
        }
        else{
            if (CDCView.m_fScale <= 1) {
                imgBk.load("G1/air_bubble_bk.png", true);
                imgBk.moveTo(320 * (1 - 1 / CDCView.m_fScale), 300 * (1 - 1 / CDCView.m_fScale));
            }
            else
                imgBk.load("G1/air_bubble_bk.png");
        }

        for (int i = 0; i < nCountAirBubble; i++)
        {
            imgAirBubbles[i] = new CImgObj("G1/air_bubble_normal.png", kaimin.m_bSBTV );
            imgAirBubbles[i].resetImgName("G1/air_bubble_normal.png");
            imgAirBubbles[i].setScale(rScaleAirBubble, rScaleAirBubble);
            if (kaimin.m_bSBTV)
            {
                imgAirBubbles[i].setSBTVScale(true);
            }

            float rLeftMargin = 9;
            float rTopMargin = 50;
            if ((i / 5) % 2 == 1)
            {
                rLeftMargin = 67;
            }
            imgAirBubbles[i].moveTo(rLeftMargin + (i%5)*115, rTopMargin + (i/5)*115);

            recAirBubbles[i] = new Rect( (int)(rLeftMargin + (i%5)*115),
                    (int)(rTopMargin + (i/5)*115),
                    (int)(rLeftMargin + (i%5)*115 + 110),
                    (int)(rTopMargin + (i/5)*115 + 110));

//            bSelected[i] = new Boolean(false);
        }

        imgMenuBg.load("COMN/COMN_menu_back.png", kaimin.m_bSBTV );
        imgScoreBg.load("G1/air_bubble_calculate.png", kaimin.m_bSBTV );

        imgMenuNor.load("COMN/COMN_btn_menu_1.png", kaimin.m_bSBTV );
        if( kaimin.m_bSBTV ){
            imgMenuFoc.load("COMN/COMN_btn_menu_2_sbtv.png", kaimin.m_bSBTV );
        }else{
            imgMenuFoc.load("COMN/COMN_btn_menu_2.png");
        }


        for(int i = 0; i < 10; i ++) {
            imgScoreNum[i] = new CImgObj("COMN/COMN_num_" + i + ".png", kaimin.m_bSBTV );
        }

        if( kaimin.m_bSBTV )
        {
            imgMenuBg.setSBTVScale( true );
            imgScoreBg.setSBTVScale( true );

            imgMenuNor.setSBTVScale( true );
            imgMenuFoc.setSBTVScale( true );

            for(int i = 0; i < 10; i ++) {
                imgScoreNum[i].setSBTVScale( true );
            }
        }

        imgMenuBg.moveTo(0, 899);
        imgScoreBg.moveTo(10, 906);
        imgMenuNor.moveTo(433, 901.5f);
    }

    private void drawCreatedImages()
    {
        imgBk.draw();
        for (int i = 0; i < nCountAirBubble; i++)
        {
            imgAirBubbles[i].draw();
        }

        imgMenuBg.draw();
        imgScoreBg.draw();
        imgMenuNor.draw();
        drawScore();

    }

    private void drawScore1(int nScore, float x)
    {
        int nOOO = 100000;
        for(int i = 0; i < 6; i ++) {
            int nOne = nScore / nOOO;
            nScore -= nOne * nOOO;
            nOOO /= 10;

            imgScoreNum[nOne].draw(x + 19 * i, 919.5f);
        }
    }

    private void drawScore()
    {
        drawScore1(nScore, 299.5f);
    }

    private int GetStepAlpha() {
        if (m_timeProc == 0)
            return 255;

        int	nAlpha = 255;
        long timeElapse = STD.GetTickCount() - m_timeProc;

        if(m_nStep == 0) {
            if(timeElapse >= OPEN_FRAME_COUNT * Globals.MS_PER_FRAME) {
                m_nStep ++;
                createButtons();
                m_timeProc = STD.GetTickCount();
                timeElapse = 0;
            }
            else {
                float	fAlpha = 255.0f;

                fAlpha *= (float)timeElapse;
                fAlpha /= (float)(OPEN_FRAME_COUNT * Globals.MS_PER_FRAME);
                nAlpha = (int)fAlpha;
            }
        }
        if(m_nStep == 2) {
            if(timeElapse >= CLOSE_FRAME_COUNT * Globals.MS_PER_FRAME) {
                Globals.stopBGM();

                nAlpha = 0;
                DestroyWindow( frmWndMgr.WND_TITLE );
            }
            else {
                float	fAlpha = 255.0f;

                fAlpha *= (float)timeElapse;
                fAlpha /= (float)(CLOSE_FRAME_COUNT * Globals.MS_PER_FRAME);
                nAlpha = (int)(255.0 - fAlpha);
            }
        }

        return nAlpha;
    }

    public void OnExit() {

        Close();
    }


    private void Close() {
        RemoveAllButtons();

        m_nStep = 2;
        m_timeProc = STD.GetTickCount();

    }

    public void createButtons() {
        CButton btn = null;
        btn = createButton(
                imgMenuNor,
                imgMenuFoc,
                null);
        btn.setPoint(433, 901.5f);
        btn.setAsyncFlag(true);
        btn.setCommand( CMD_MENU_ASYNC );
        btnMenu = btn;

        if( kaimin.m_bSBTV ){
            if( btnMenu != null )
                btnMenu.setFocus();
        }
    }

    public void OnOption() {

        Globals.SetBGMType(Globals.m_nBGMType_WndSheet);

//        getView().getActivity().showDialog(2);
        getView().getActivity().showAlertDialog( 2 );


    }

    private void setVibrate(long lgMilSec)
    {
        Vibrator v = (Vibrator)getView().getActivity().getSystemService(Context.VIBRATOR_SERVICE);
//        v.vibrate(lgMilSec);
        long[] pattern = {lgMilSec, lgMilSec};
        v.vibrate(pattern, -1);
    }

    private void playSound()
    {
        Globals.playSoundForAirBubble();
    }

    private boolean isAllBroken()
    {
        boolean bFlag = true;
        for (int i = 0; i < nCountAirBubble; i++)
        {
            if (imgAirBubbles[i].strName == "G1/air_bubble_normal.png")
            {
                bFlag = false;
                break;
            }
        }
        return bFlag;
    }

    private void resetAirBubbleImgs()
    {
        for (int i = 0; i < nCountAirBubble; i++)
        {
            imgAirBubbles[i].resetImage("G1/air_bubble_normal.png", kaimin.m_bSBTV);

            imgAirBubbles[i].resetImgName("G1/air_bubble_normal.png");
        }
    }

}
