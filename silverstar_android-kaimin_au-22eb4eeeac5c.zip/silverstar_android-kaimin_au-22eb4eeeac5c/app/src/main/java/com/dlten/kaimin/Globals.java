package com.dlten.kaimin;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.media.MediaPlayer.OnCompletionListener;

import com.dlten.kaimin_auOM.R;
import com.dlten.lib.STD;
import com.dlten.lib.Sound.SoundManager;
import com.dlten.lib.file.CConFile;

public class Globals {

	// SKY:1120:start
    public static MediaPlayer			player = null;
    public static MediaPlayer			player2 = null;
    // SKY:end

    // constants.
    public static float FPS = 33;

	public static final long MS_PER_FRAME = 16;	// milisecond/frame

	public static int m_nTextFileID;
	
	public static Activity mainActivity;
	
	public static boolean		m_bFirst = true;
	public static final String SETINFO_FILE		= "SetInfo.dat";

	// Screen & Resource relations.
	//public static int SC_WIDTH; // px screen_width
	//public static int SC_HEIGHT; // px screen_height
/*	private static float m_fScale; // screen_width/res_width
	private static float m_fDensity; // screen_width(pxl)/screen_width(dip)
	public static int m_nOffsetWidth; // pixel unit.
	public static int m_nOffsetHeight; // pixel unit.*/
	public static void Initialize(Context context) {
		//SC_WIDTH = nScreenWidth;
		//SC_HEIGHT = nScreenHeight;
		
//		frmView.setResSize(RES_WIDTH, RES_HEIGHT);

/*		float fScaleWidth = (float)nScreenWidth/RES_WIDTH;
		float fScaleHeight = (float)nScreenHeight/RES_HEIGHT;
		m_fScale = STD.MIN(fScaleWidth, fScaleHeight);

		m_nOffsetWidth = (int)((SC_WIDTH - RES_WIDTH*m_fScale) / 2);
		m_nOffsetHeight = (int)((SC_HEIGHT - RES_HEIGHT*m_fScale) / 2);

		m_fDensity = context.getResources().getDisplayMetrics().density;
		STD.logout("Density=" + m_fDensity);*/
		mainActivity = (Activity)context;
	}
	public static void Finalize() {
		
	}
	
	public static void SaveSetting() {
		g_Global.SaveSetInfo();
	}
	
	public boolean	SaveSetInfo() {
		boolean		bRet = false;
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(baos);

        	dos.writeBoolean(m_bFirst);        	
        	
            byte[] buf = baos.toByteArray();
            dos.close();
            baos.close();
            
            bRet = CConFile.write(SETINFO_FILE, buf);
        } catch (Exception e) {
        	STD.printStackTrace(e);
        	bRet = false;
        }
        
        return bRet;
	}
	public boolean	LoadSetInfo() {
		boolean		bRet = false;
        byte[] buf = CConFile.read(SETINFO_FILE);
        if (buf == null)
            return false;
        
        try {
            ByteArrayInputStream baos = new ByteArrayInputStream(buf);
            DataInputStream dis = new DataInputStream(baos);

			m_bFirst = dis.readBoolean();

			dis.close();
            baos.close();
            
            bRet = true;
        }
        catch (Exception e) {
        	STD.printStackTrace(e);
            bRet = false;
        }
        
		return bRet;
	}
/*	
	public static float getScale() {
		return m_fScale;
	}
	public static int getDiffHeight() {
		return m_nOffsetHeight;
	}
	public static int getHeightDip() {
		return (int) pixel2dip(SC_HEIGHT);
	}

	
	public static float RES_DIP_HEIGHT() {
		return res2dip( RES_HEIGHT );
	}
	public static float RES_DIP_WIDTH() {
		return res2dip( RES_WIDTH );
	}
	public static float SC_DIP_HEIGHT() {
		return pixel2dip( SC_HEIGHT );
	}
	public static float SC_DIP_WIDTH() {
		return pixel2dip( SC_WIDTH );
	}

	public static float res2screen( float resPx ) {
		return (resPx*m_fScale);
	}
	public static float screen2res( float screenPx ) {
		return (screenPx/m_fScale);
	}
	public static float pixel2dip(float pixels) {
		float dips = pixels/m_fDensity;
	    return dips;
	}
	public static float dip2pixel(float dips)	{
	    float den = m_fDensity;
	    if(den != 1)
	        return (int)(dips*den+0.5);
	    return dips;
	}
	public static float res2dip( float resPx ) {
		float sPx = res2screen(resPx);
		return pixel2dip(sPx);
	}
	public static float dip2res( float dips ) {
		float sPx = dip2pixel(dips);
		return screen2res(sPx);
	}
*/
	

	public static Globals		g_Global     = null;
	public static SoundManager	g_Sound      = null;

	public static void createGlobalValues( Activity context ) {
		g_Global     = getInstance();
		g_Global.LoadSetInfo();
		
		g_Sound = new SoundManager();
		g_Sound.changeContext( context );
		g_Sound.setEnable(true);
//		g_Sound.setEnable(false);

		// SKY:121120:start
		timer.scheduleAtFixedRate(task, 0, INTERVAL);//30fps
		// SKY:end
	}
	
	public static void deleteGlobalValues() {
		g_Global     = null;

		// SKY:121120:start
		if (timer != null) {
			timer.cancel();
			timer = null;
		}
		// SKY:end
	}

	public static boolean m_bBGMDisable;
	public static boolean m_bSEDisable;
	public static boolean m_bSoundTheatre = false;
	public static boolean m_bSoundEnable;

	private static int m_nBGMType = 0;
	private static int m_nSE = 0;
	private static int m_nTimerType = 0;
	private static int m_nScreenOffType = 0;
	private static int m_nMSpeedType = 0;

	public static int m_nBGMType_WndRead = 0;
	public static int m_nBGMType_WndSheet = 1;
	public static int m_nBGMType_WndDrive = 1;
	public static int m_nBGMType_WndBlock = 1;
	public static int m_nBGMType_WndLaw = 1; // SKY:120615
	public static int m_nBGMType_WndRPG1 = 3;
	public static int m_nBGMType_WndRPG2 = 4;

	public static boolean m_bShowYesNo = false;
	public static boolean m_bSelYes;
	
	public static boolean m_bClickClose = false;
	public static int m_nTimerTick = -1;
    public static long suicideStartTick = 0;
    public static boolean m_bOpenMenu = false;

    private static Globals _instance = null;
    public static Globals getInstance() {
        if( _instance == null ) {
        	_instance = new Globals();
        }
        return _instance;
    }
    
	public Globals() {
		m_nBGMType = 0;
		m_nSE = 0;
	}
	
	public static int	GetBGMType() {
		return m_nBGMType;
	}
	public static void	SetBGMType(int nBGMType) {
		m_nBGMType = nBGMType;
	}
	public static int GetTimerType() {
		return m_nTimerType;
	}
	public static void SetTimerType(int nTimerType) {
		m_nTimerType = nTimerType;
		m_nTimerTick = GetTimerValue(m_nTimerType);
		
		if (m_nTimerType > 0) { //timer : off
			if (Globals.m_nTimerTick <= 0)
				Globals.m_nTimerTick = 1;
			kaimin main = (kaimin)mainActivity;
			main.setSuicideAlarm(m_nTimerTick);
		}		
	}
	public static int GetScreenOffType() {
		return m_nScreenOffType;
	}
	public static void SetScreenOffType(int nType) {
		m_nScreenOffType = nType;
		kaimin main = (kaimin)mainActivity;
		main.setScreenOffType(nType);
	}
	public static int GetTimerValue(int type) {
		int ret = 0;
		switch(type) {
		case 0://OFF
			ret = -1;				break;
		case 1://05分00秒
			ret = 5 * 60;			break;
		case 2://10分00秒
			ret = 10 * 60;			break;
		case 3://15分00秒
			ret = 15 * 60;			break;
		case 4://30分00秒
			ret = 30 * 60;			break;
		case 5://45分00秒
			ret = 45 * 60; 			break;
		case 6://60分00秒
			ret = 60 * 60;			break;
		case 7://90分00秒
			ret = 90 * 60;			break;
		}
		return ret;
	}

	public static int	GetSE() {
		return m_nSE;
	}
	public static void	SetSE(int nSE) {
		m_nSE = nSE;
	}
	
	public static int	GetMSpeedType() {
		return m_nMSpeedType;
	}
	public static void	SetMSpeedType(int nMSpeedType) {
		m_nMSpeedType = nMSpeedType;
	}
	
	public static int max(int a, int b) {
		return (a > b) ? a : b;
	}

	public static int min(int a, int b) {	
		return (a > b) ? b : a;
	}

	public static final int[] m_nBGMIDs = {
		R.raw.bgm01_mix, 
		R.raw.bgm02_mix, 
		R.raw.mushi,
		R.raw.rpg_field,
		R.raw.rpg_battle
		};
	public static final int[] m_nBGMIDs_SoundTheater = {
		R.raw.sound_forest,
		R.raw.sound_mushi,
		R.raw.sound_dusk,
		R.raw.sound_frog,
		R.raw.sound_rain,
		R.raw.sound_water,
		R.raw.sound_wave,
		R.raw.sound_jinari,
		R.raw.sound_metronome
	};
	public static void playSE(int se) {
		if(m_nSE == 0)
			g_Sound.soundpool_PlaySE(se);
	}
	public static void playBGM(int bgm) {
		if(bgm < m_nBGMIDs.length)
			g_Sound.playBGM(m_nBGMIDs[bgm]);
//T		if ( m_bBGM == true )
//T			g_Sound.playBGM(bgm);
//T		else
//T			g_Sound.stopBGM();
	}
	public static void playBGM_SoundTheater(int bgm) {
		if(bgm < m_nBGMIDs_SoundTheater.length)
			g_Sound.playBGM(m_nBGMIDs_SoundTheater[bgm]);
	}
	public static void resumeBGM() {
		g_Sound.resumeBGM();
	}
	public static void pauseBGM() {
		g_Sound.pauseBGM();
	}
	public static void stopBGM() {
		g_Sound.stopBGM();
	}
	////////////////////////////////////////////////////////////////////////////////////////////////
	// SKY:121120:start
	
	private static int m_nSndIndex = 0;
    private static final String[] SOUND_FILEPATHNAME = new String[]
     {	
    	"wav/forest.ogg",
    	"wav/mushi_s.ogg",
    	"wav/dusk.ogg",
    	"wav/frog.ogg",
    	"wav/rain.ogg",
    	"wav/water.ogg",
    	"wav/wave.ogg",
    	"wav/jinari.ogg",
    	"wav/metronome.ogg",
    	"wav/bgm01.mp3",
    	"wav/bgm02.mp3",
    	"wav/mushi03.mp3",
			 "wav/air_bubble_broken.wav",
			 "wav/sheep_closed.wav",
    };

    private static boolean m_bStartPlay = false;
    private static boolean m_bPlayMyBgm = false; // SKY:121128
    private static long LIMIT_COUNT = 0; 
    private static int m_nPlayingNo = 0;
	public static void playMyBGM(int bgm)
	{
		if (mainActivity == null)
			return;
		if(bgm < SOUND_FILEPATHNAME.length)
		{
			// stop the current playing
			stopSound();
			stopSound2();
			
			m_nSndIndex = bgm;
			m_bStartPlay = true;
			m_bPlayMyBgm = true;
			// start to play
			LIMIT_COUNT = (long)(FRAME_TIME[m_nSndIndex] * 1000.0f / (double)INTERVAL) - 1 - REPEAT_FRAME;
			if (LIMIT_COUNT <= 0)
				LIMIT_COUNT = 2;
			m_nPlayingNo = 0;
			
			playSound();
		}
	}
	public static void stopMyBGM()
	{
		m_bStartPlay = false;
		m_bPlayMyBgm = false;
		m_nPlayingNo = 0;
		stopSound();
		stopSound2();
	}
	
	// SKY:121128:start
	public static void pauseMyBGM()
	{
		m_bPlayMyBgm = false;
		if ( player != null && player.isPlaying() )
			player.pause();
		if ( player2 != null && player2.isPlaying() )
			player2.pause();
	}
	public static void resumeMyBGM()
	{
		m_bPlayMyBgm = true;
		if ( player != null )
			player.start();
		if ( player2 != null )
			player2.start();
	}
	// SKY:end
	
	///// inner functions

	public static void playSound()
	{
		stopSound();
		player	=	getMediaPlayer( mainActivity, SOUND_FILEPATHNAME[m_nSndIndex], false );
		player.start();
		player.setOnCompletionListener( new OnCompletionListener() {
			
			@Override
			public void onCompletion(MediaPlayer mp) {
				// TODO Auto-generated method stub
//				stopSound();
//				playSound();
				
//				setSEPlaying(false);
			}
		});
//		System.out.println("palyer start");
	}

	public static void playSoundForAirBubble()
	{
		stopSound();
		player	=	getMediaPlayer( mainActivity, SOUND_FILEPATHNAME[12], false );
		player.start();
		player.setOnCompletionListener( new OnCompletionListener() {

			@Override
			public void onCompletion(MediaPlayer mp) {
				// TODO Auto-generated method stub
			}
		});
	}

	public static void playSoundForSheepBox()
	{
		stopSound();
		player	=	getMediaPlayer( mainActivity, SOUND_FILEPATHNAME[13], false );
		player.start();
		player.setOnCompletionListener( new OnCompletionListener() {

			@Override
			public void onCompletion(MediaPlayer mp) {
				// TODO Auto-generated method stub
			}
		});
	}
	
	public static void stopSound()
	{
//		m_bStartPlay = false;
		if ( player != null )
		{
			if( player.isPlaying() )
				player.stop();
			player.release();
			player = null;
		}
	}
    
	public static void playSound2( )
	{
		stopSound2();
		player2	=	getMediaPlayer( mainActivity, SOUND_FILEPATHNAME[m_nSndIndex], false );
		player2.start();
		player2.setOnCompletionListener( new OnCompletionListener() {
			
			@Override
			public void onCompletion(MediaPlayer mp) {
				// TODO Auto-generated method stub
//				playSound2( );
//				stopSound();
				
//				setSEPlaying(false);
			}
		});
		
//		System.out.println("palyer2 start");
	}
	
	public static void stopSound2()
	{
//		m_bStartPlay = false;
		if ( player2 != null )
		{
			if( player2.isPlaying() )
				player2.stop();
			player2.release();
			player2 = null;
		}
	}
	static MediaPlayer	getMediaPlayer( Context pContext, String strFilePath, boolean bLoop ){

	    MediaPlayer	player	=	new MediaPlayer( );
	    try {
		    AssetFileDescriptor	descriptor	=	pContext.getAssets().openFd( strFilePath );
			player.setDataSource( descriptor.getFileDescriptor(), descriptor.getStartOffset(), descriptor.getLength() );
			player.setLooping( bLoop );
			player.prepare();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return player;
	}
	
	static final double FRAME_TIME[] = {
		12.468231, // forest
		18.229955, // mushi
		18.197347, // dusk
		11.067687, // frog
		6.149887, // rain
		12.760136, // water
		13.354422, // wave --------------------
    	3.741633, // jinari
    	1.251451, // metron -----------------------
    	
    	12.760136, // bgm1 -----------------------
    	12.760136, // bgm2 -----------------------
    	12.760136 // bgm3 -----------------------
	};
	static int REPEAT_FRAME = 10; //10*INTERVAL = 330ms
	static long INTERVAL = 33;
	static Timer timer = new Timer();  
	static TimerTask task = new TimerTask(){  
        public void run() {  
        	OnTimer();  
        }  
    };
    static long m_counter = 0;
	static public void OnTimer() {
		if ( !m_bStartPlay )
			return;
		if ( ! m_bPlayMyBgm ) // SKY:121128
			return;
		
		m_counter ++;
		if (m_counter > LIMIT_COUNT) {
			m_counter = 0;
			
			// replace
			if ( m_nPlayingNo == 0 )
			{
				m_nPlayingNo = 1;
				playSound2();
			}
			else
			{
				m_nPlayingNo = 0;
				playSound();
			}
		}
	}
	
	
	public static boolean m_bHomekeyPressed = false; // SKY:121128

	// SKY:end

}
