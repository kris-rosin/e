package com.dlten.lib.graphics;

import com.dlten.kaimin.frmWndMgr;
import com.dlten.kaimin.kaimin;
import com.dlten.lib.CBaseView;
import com.dlten.lib.STD;

import android.graphics.Matrix;
import android.graphics.Bitmap;

public class CImgObj {

	private static int m_nResSizeIndex;
	public static void setResSizeIndex(int nResSizeIndex) {
		m_nResSizeIndex = nResSizeIndex;
	}

	private CImage m_imgParent;
	public String strName;
	private CRect m_rect = new CRect();
	private CRect m_rtTemp = new CRect();
	private int m_nAnchor;
	private int m_nFilterColor;
	private int m_nAlpha = 255;
	private float m_scaleX, m_scaleY;

//NO===	private int m_rotate; // 0~359

	//kjh start
	// this is variable for SBTV
	private boolean		m_bSBTV			=	false;
	private float		m_fScaleXSBTV	=	1.f;
	private float		m_fOffsetXSBTV	=	300.f;
//	private float		m_fOffsetXSBTV	=	267.5f;
	
	private boolean		m_visible = true;

	public void setSBTVScale( boolean bSBTV ){
		m_bSBTV	=	true;
		m_fScaleXSBTV	=	480.f / 640.f;
	}
	
	public boolean getSBTVScale(){
		return m_bSBTV;
	}
	
	public void setVisible(boolean visible) {
		m_visible = visible;
	}
	
	//kjh end
	
	public CImgObj() {
		init();
	}
	public CImgObj( String strAsset ) {
		init();
		load( strAsset );
	}
	
	//kjh start
	public CImgObj( String strAsset, boolean bRealSize ) {
		init();
		load( strAsset, bRealSize );
		
	}
	//kjh end
	public void destroy() {
		if(m_imgParent != null) {
			m_imgParent.destroy();
			m_imgParent = null;
		}
		m_rect = null;
		m_rtTemp = null;
	}
	private void init() {
		setAnchor( CImage.ANCHOR_LEFT | CImage.ANCHOR_TOP );
		setFilterColor( 0xFFFFFF );
//NO===		setAlpha( 0xFF );
//NO===		rotateTo( 0 );
		setScaleX(1.0f);
		setScaleY(1.0f);
		
	}
	
	public void load( String strAsset ) {
		load(strAsset, false);
	}
	public void load( String strAsset, boolean bRealSize ) {
		if (strAsset == null) {
			STD.logout("CImgObj.load()	File name is null!");
			return;
		}
		
		CImage img = new CImage();
		img.load(m_nResSizeIndex + "/" + strAsset, bRealSize);
		setParent(img);
	}
	public void setParent( CImage imgParent ) {
		m_imgParent = imgParent;
		m_rect.SetRectEmpty();
		updateSize();
	}
	private void updateSize() {
		if( m_imgParent != null ) {
			m_rect.width = m_imgParent.getCWidth();
			m_rect.height = m_imgParent.getCHeight();
		}
	}
	private void updateWidth() {
		if( m_imgParent != null ) {
			m_rect.width = m_imgParent.getCWidth();
		}
	}
	private void updateHeight() {
		if( m_imgParent != null ) {
			m_rect.height = m_imgParent.getCHeight();
		}
	}

	public void resetImage(String strAsset, boolean bRealSize) // for air bubble
	{
		CImage img = new CImage();
		img.load(m_nResSizeIndex + "/" + strAsset, bRealSize);
		m_imgParent = img;
	}

	public void resetImgName(String str) // for air bubble
	{
		strName = str;
	}

	public CImage getParent() {
		return m_imgParent;
	}
	
	public void draw() {
		drawImpl(m_rect.left, m_rect.top);
	}
	public void draw( CPoint pt ) {
		if( pt == null )
			return;
		
		draw( pt.x, pt.y );
	}
	public void draw(float x, float y) {
		drawImpl(x, y);
	}

	private void drawImpl( float fPosX, float fPosY ) {
		if (!m_visible)
			return;
		
/* for OpenGL
		drawImpl2(fPosX, fPosY);
		return;//*/
///*
		if( m_imgParent == null )
			return;
		//kjh start
		
//		fPosX *= CDCView.m_fPosScaleXFrom640;
//		fPosY *= CDCView.m_fPosScaleYFrom960;
		
		if( m_bSBTV ){
			fPosX *=	m_fScaleXSBTV;
			fPosX +=	m_fOffsetXSBTV;
			fPosY *=	m_fScaleXSBTV;
		}else{
			fPosX *= CDCView.m_fPosScaleXFrom640;
			fPosY *= CDCView.m_fPosScaleYFrom960;	
		}
		//kjh end
		
		CDCView dc = CImage.getDCView();
		
		// reflect : scale, rotate with matrix
		Bitmap bmp = m_imgParent.getBmp();
		
		//testCode
		int 	nWidth	=	bmp.getWidth();
		int 	nHeight	=	bmp.getHeight();
		//testCode
		
//		if((m_rotate != 0) || (m_scaleX != 1) || (m_scaleY != 1)) {
		//kjh start
		if( m_bSBTV ){
			
			Matrix matrix = new Matrix();

			matrix.postScale( m_fScaleXSBTV, m_fScaleXSBTV, 0, 0 );
			matrix.postTranslate( fPosX, fPosY );

			// reflect alpha
			if( m_nAlpha != 0xFF ) {
				dc.setAlpha(m_nAlpha);
			}
			// TODO : reflect color_filter
			dc.drawImage(bmp, matrix);
	
			// reflect alpha
			if( m_nAlpha != 0xFF ) {
				dc.setAlpha(0xFF);
			}
			
		}else{
			if((m_scaleX != 1) || (m_scaleY != 1)) {
				Matrix matrix = new Matrix();
//				if( m_rotate != 0 )
//					matrix.postRotate(m_rotate, -offset[0], -offset[1]);
				if( m_scaleX != 1 || m_scaleY != 1 )
					matrix.postScale(m_scaleX, m_scaleY, 0, 0);
				matrix.postTranslate(fPosX * CDCView.m_fScale, fPosY * CDCView.m_fScale);
				// reflect alpha
				if( m_nAlpha != 0xFF ) {
					dc.setAlpha(m_nAlpha);
				}
				// TODO : reflect color_filter
				dc.drawImage(bmp, matrix);
		
				// reflect alpha
				if( m_nAlpha != 0xFF ) {
					dc.setAlpha(0xFF);
				}
			}
			else {
				// reflect alpha
				if( m_nAlpha != 0xFF ) {
					dc.setAlpha(m_nAlpha);
				}
				// TODO : reflect color_filter
				dc.drawImage(bmp, fPosX, fPosY);
		
				// reflect alpha
				if( m_nAlpha != 0xFF ) {
					dc.setAlpha(0xFF);
				}
			}//*/
		}
		//kjh end
	}

	public void moveTo(float x, float y) {
		m_rect.left = x;
		m_rect.top = y;
	}
	public void moveTo( CPoint pt ) {
		moveTo(pt.x, pt.y);
	}
	public void move(float dx, float dy) {
		m_rect.OffsetRect(dx, dy);
	}

	public CPoint getPos() {
		return getRect().TopLeft();
	}
	public CPoint getCenterPos() {
		return getRect().CenterPoint();
	}
	public CRect getRect() {
		m_rtTemp.CopyRect(m_rect);
//		float[] posOffset = CImage.getLeftTopPos(m_rtTemp.width, m_rtTemp.height, m_nAnchor);
//		m_rtTemp.OffsetRect(posOffset[0], posOffset[1]);
		return m_rtTemp;
	}
	
	public void setAnchor( int nAnchor ) {
		m_nAnchor = nAnchor;
	}
	public int getAnchor() {
		return m_nAnchor;
	}
	
	public void setFilterColor( int nColor ) {
		m_nFilterColor = nColor;
	}
	public int getFilterColor() {
		return m_nFilterColor;
	}

	public void setAlpha( int nAlpha ) {
		m_nAlpha = nAlpha;
	}
/*	public int getAlpha() {
		return m_nAlpha;
	}*/
/*//NO===	
	public void rotate(int dr) {
		m_rotate += dr;
		checkImageChange();
	}
	public void rotateTo(int r) {
		m_rotate = r;
		checkImageChange();
	}
*/
	public void setScale(float scaleX, float scaleY) {
		setScaleX(scaleX);
		setScaleY(scaleY);
	}
	public void setScaleX(float scaleX)	{
		updateWidth();
		m_scaleX = scaleX;
//		m_rect.width = m_rect.width * scaleX;
	}
	public void setScaleY(float scaleY) {
		updateHeight();
		m_scaleY = scaleY;
//		m_rect.height = m_rect.height * scaleY;
	}
	public float getscaleX() {
		return m_scaleX;
	}
	public float getScaleY() {
		return m_scaleY;
	}

	
	
	
// for OpenGL	
	///////////////////////////////////////////////////////////////////////////
	private CRect m_rectTexture = new CRect();
	private int m_nTextureIndex;
	public void load( String strAsset, int nTextureIndex, int xpos, int ypos ) {
		if (strAsset == null) {
			STD.logout("CImgObj.load()	File name is null!");
			return;
		}
		
		CImage img = new CImage();
		img.load(strAsset, false);
		setParent(img);

		Bitmap bmp = m_imgParent.getBmp();
		CImage.getDCView().copyBitmap(bmp, nTextureIndex,xpos, ypos, m_rectTexture);
		
		img = null;
		m_imgParent = null;
		
		m_nTextureIndex = nTextureIndex;
	}

	public CImgObj( String strAsset, int nTextureIndex, int xpos, int ypos ) {
		init();
		load( strAsset, nTextureIndex, xpos, ypos );
	}

	private void drawImpl2( float fPosX, float fPosY ) {
		CBaseView dc = CImage.getDCView();
		dc.drawImage(m_nTextureIndex, fPosX, fPosY, m_rect.width, m_rect.height, m_scaleX, m_scaleY, m_rectTexture); // for CGLDCView
	}
}
