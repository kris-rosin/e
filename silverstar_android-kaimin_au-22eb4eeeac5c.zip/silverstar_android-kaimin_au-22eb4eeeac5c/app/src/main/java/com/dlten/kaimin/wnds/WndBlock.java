package com.dlten.kaimin.wnds;

import android.util.Log;

import com.dlten.kaimin.Globals;
import com.dlten.kaimin.frmWndMgr;
import com.dlten.kaimin.kaimin;
import com.dlten.lib.STD;
import com.dlten.lib.frmWork.CButton;
import com.dlten.lib.frmWork.CWnd;
import com.dlten.lib.graphics.CDCView;
import com.dlten.lib.graphics.CImgObj;
import com.dlten.lib.graphics.CRect;

public class WndBlock extends WndTimer {

	private int m_nStatus;
	private int m_nStatusOldForSuspend;
	private	long	m_timeProc;

	private static long OPEN_FRAME_COUNT = 20;
	private static long CLOSE_FRAME_COUNT = 20;

	private CImgObj m_imgBg   			= new CImgObj();
	private CImgObj m_imgMsg   			= new CImgObj();
	private CImgObj m_imgBall   		= new CImgObj();
	private CImgObj m_imgMenuBg   		= new CImgObj();
	private CImgObj m_imgScoreBg   		= new CImgObj();
	private CImgObj[] m_imgScoreNum   	= new CImgObj[10];
	private CImgObj m_imgBar   			= new CImgObj();

	private CImgObj m_imgMenuNor   = new CImgObj();
	private CImgObj m_imgMenuFoc   = new CImgObj();
	private CImgObj m_imgStartNor   = new CImgObj();
	private CImgObj m_imgStartFoc   = new CImgObj();

	//kjh start
	private CImgObj m_imgLeftSideBack   	= new CImgObj();
	private CImgObj m_imgRightSideBack   	= new CImgObj();
	//kjh end
	
	private CButton	m_btnMenu  = null;
	private CButton	m_btnStart  = null;
	
	private boolean m_bMenu = false; //by LYM 2012/12/30

	private int m_nScore = 0;

	private float m_fBarPosX;
	private int m_nBarTargetPosX;
	private long m_timeBarPrev;

	private float m_fBallPosX;
	private float m_fBallPosY;
	private long m_timeBallPrev;
	private int m_nBallMotion;

	private long m_timePaused;

    public static final int
		CMD_MENU_ASYNC      = 0,
		CMD_SELECT_CLOSE1	= 1,
		CMD_SELECT_CLOSE2	= 2,
		CMD_START			= 3,
		CMD_SELECT_RETRY	= 4;
    
    static final int
    	STATUS_SHOW = 1,
    	STATUS_WAIT = 2,
    	STATUS_PLAY = 3,
    	STATUS_DOWN = 4,
    	STATUS_FAIL = 5,
    	STATUS_HIDE = 6,
    	STATUS_FAILED = 7,
    	STATUS_CLOSE = 8,
    	STATUS_PAUSED = 9;

	private static final int BAR_POS_Y = 701 - 32;
	private static float BALL_SPEED = 72; // 330 pixel/second
	private static final float BAR_SPEED = 264; // 660 pixel/second

	private static final int BALL_SIZE = 32;
	private static final int BAR_SIZE_X = 144;
	private static final int BAR_SIZE_Y = 24;
	private static final int DOWN_POS_Y = 867;
	
	private static final int
		MOTION_RIGHT = 1,
		MOTION_TOP = 2,
		MOTION_LEFT = 4,
		MOTION_BOTTOM = 8,
		MOTION_RIGHTTOP = 3,
		MOTION_LEFTTOP = 6,
		MOTION_RIGHTBOTTOM = 9,
		MOTION_LEFTBOTTOM = 12;
	
	   //kjh start
	private static final int	BTN_FOCUS_START				=	100;
	private static final int	BTN_FOCUS_MENU				=	101;
	
	public int					m_nCurFoucus	=	-1;
	
	public void initFocusBtns(){
		
			if( m_btnMenu != null )
				m_btnMenu.setNormal();
			if( m_btnStart != null )
				m_btnStart.setNormal();
			
	}
	
	public void updateFocusBtns( int nFocusBtn ){
		
		if( !kaimin.m_bSBTV )
			return;
		
//		if( m_nCurFoucus == nFocusBtn )
//			return;
		try {
			
			initFocusBtns();
			
			switch ( nFocusBtn ) {
				case BTN_FOCUS_MENU:
					if( m_btnMenu != null )
						m_btnMenu.setFocus();
					else
						return;
	//				m_Btns.setFocusState( true );
					break;
				case BTN_FOCUS_START:
	//				m_btnOption.setFocusState( true );
					if( m_btnStart != null ){
						if( m_btnStart.getVisible() )
							m_btnStart.setFocus();
						else
							return;
					}else
						return;
					break;

			default:
				break;
			}	
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		m_nCurFoucus	=	nFocusBtn;
		
	}
	//kjh end

	public void OnLoadResource() {
		Globals.playBGM(Globals.m_nBGMType_WndBlock);
		
		createImages();
		createButtons();
		
		super.OnLoadResource();
	}
	public void OnInitWindow() {
		Globals.m_bBGMDisable = false;
		Globals.m_bSEDisable = false;
		
		SetStatus(STATUS_SHOW);
	}
	public void OnShowWindow() {
	}

	private void createImages() {
		m_imgBg.load("F1/F1_background.png", kaimin.m_bSBTV );
		m_imgMsg.load("F1/F1_msg.png", kaimin.m_bSBTV  );

		m_imgBall.load("F1/F1_ball.png", kaimin.m_bSBTV );
		m_imgBar.load("F1/F1_bar.png", kaimin.m_bSBTV );
		m_imgMenuBg.load("COMN/COMN_menu_back.png", kaimin.m_bSBTV );
		m_imgScoreBg.load("F1/F1_info.png");

		if( kaimin.m_bSBTV ){
			m_imgMenuNor.load("COMN/COMN_btn_menu_1.png", kaimin.m_bSBTV );
			m_imgMenuFoc.load("COMN/COMN_btn_menu_2_sbtv.png", kaimin.m_bSBTV );
		}else{
			m_imgMenuNor.load("COMN/COMN_btn_menu_1.png");
			m_imgMenuFoc.load("COMN/COMN_btn_menu_2.png");	
		}
		
		
		if( kaimin.m_bSBTV ){
			m_imgStartNor.load("COMN/COMN_btn_start_1.png", kaimin.m_bSBTV );
			m_imgStartFoc.load("COMN/COMN_btn_start_2_sbtv.png", kaimin.m_bSBTV );	
		}else{
			m_imgStartNor.load("COMN/COMN_btn_start_1.png");
			m_imgStartFoc.load("COMN/COMN_btn_start_2.png");
		}
		

		for(int i = 0; i < 10; i ++) {
			m_imgScoreNum[i] = new CImgObj("COMN/COMN_num_" + i + ".png");
		}

		
		//kjh start
		
		if( kaimin.m_bSBTV ){
			
			m_imgLeftSideBack	=	new CImgObj( "back_side.png", kaimin.m_bSBTV );
			m_imgLeftSideBack.setSBTVScale( true );
			m_imgRightSideBack	=	new CImgObj( "back_side.png", kaimin.m_bSBTV );
			m_imgRightSideBack.setSBTVScale( true );
			m_imgLeftSideBack.moveTo(-400, 0 );
			m_imgRightSideBack.moveTo(640, 0 );
			
			m_imgBg.setSBTVScale( true );
			m_imgMsg.setSBTVScale( true );

			m_imgBall.setSBTVScale( true );
			m_imgBar.setSBTVScale( true );
			m_imgMenuBg.setSBTVScale( true );
			m_imgScoreBg.setSBTVScale( true );

			m_imgMenuNor.setSBTVScale( true );
			m_imgMenuFoc.setSBTVScale( true );

			m_imgStartNor.setSBTVScale( true );
			m_imgStartFoc.setSBTVScale( true );
			
			for(int i = 0; i < 10; i ++) {
				m_imgScoreNum[i].setSBTVScale( true );
			}
			
			
		}
		//kjh end
		m_imgMsg.moveTo(44.5f, 550.5f);
		m_imgMenuBg.moveTo(0, 899);
		m_imgScoreBg.moveTo(6, 906);
		m_imgMenuNor.moveTo(433, 901.5f);

	}

	public void createButtons() {
		
		CButton	btn = null;

		btn = createButton(
				m_imgMenuNor,
				m_imgMenuFoc,
				null);
		btn.setPoint(433, 901.5f);
		btn.setAsyncFlag(true);
		btn.setCommand( CMD_MENU_ASYNC );
		btn.setVisible(false);
		m_btnMenu = btn;

		btn = createButton(
				m_imgStartNor,
				m_imgStartFoc,
				null);
		btn.setPoint(81, 446);
		btn.setCommand( CMD_START );
		btn.setVisible(false);
		m_btnStart = btn;

		btn.setPoint(81, 446);
		
		updateFocusBtns( BTN_FOCUS_START );		//kjh
		
	}
	
	void SetStatus(int step) {
		m_nStatus = step;
		switch (step) {
		case STATUS_SHOW:	// Open
			m_nScore = 0;
			m_timeProc = STD.GetTickCount();
			m_fBarPosX = 247.5f - 32;
			m_fBallPosX = m_fBarPosX + BAR_SIZE_X / 2 - BALL_SIZE / 2;
			m_fBallPosY = BAR_POS_Y - BALL_SIZE;
			m_bBarMoving = false;
			break;
		case STATUS_WAIT: // Start Button
			m_btnMenu.setVisible(true);
			m_btnStart.setVisible(true);
			updateFocusBtns( BTN_FOCUS_START );				//kjh
			break;
		case STATUS_PLAY: // Moving
			m_btnStart.setVisible(false);

			m_nBallMotion = MOTION_RIGHTTOP;
			m_timeBallPrev = STD.GetTickCount();
			break;
		case STATUS_HIDE: // Hide
			m_timeProc = STD.GetTickCount();
			break;
		case STATUS_CLOSE: // Close
			m_timeProc = STD.GetTickCount();
			break;
		case STATUS_FAILED: // Failed
//	        getView().showDialog(4);			//kjh
	        getView().getActivity().showAlertDialog( 4 );	//kjh

			break;
		}
	}
	
	//kjh start
    public void OnKeyUp( int keycode ){
		m_bBarMoving	=	false;
    }
	//kjh end
    
	public void OnKeyDown( int keycode ) {
		switch (keycode) {
		case KEY_MENU:		OnMenu();						break;
		case KEY_BACK:		OnExit();						break;
		
//		kjh start
		case KEY_DPAD_CENTER:
			onDPADKey();
			return;
		case KEY_DPAD_LEFT:
			onLeftKey();
			return;
		case KEY_DPAD_RIGHT:
			onRightKey();
			return;
		case KEY_DPAD_DOWN:
			onDownKey();
			return;
		case KEY_DPAD_UP:
			onUpKey();
			return;
//		kjh end
		default:			super.OnKeyDown(keycode);		break;
		}
	}

	//kjh start
	public void onDownKey(){
		if( m_nCurFoucus == BTN_FOCUS_MENU ){
			return;
		}else if( m_nCurFoucus == BTN_FOCUS_START ){
			updateFocusBtns( BTN_FOCUS_MENU );
		}
	}
	
	public void onUpKey(){
		if( m_nCurFoucus == BTN_FOCUS_MENU ){
			if( m_btnStart != null && m_btnStart.getVisible() ){
				updateFocusBtns( BTN_FOCUS_START );
			}
		}
//		else if( m_nCurFoucus == BTN_FOCUS_START ){
//			return;
//		}
	}
	
	public void onLeftKey(){
		
//		if (m_nStatus == STATUS_PLAY || m_nStatus == STATUS_DOWN){
////			m_bBarMoving	=	true;
//			m_fBarPosX	-=	10;
//			if( m_fBarPosX <= 10 )
//				m_fBarPosX	=	10;
//		}
		if (m_nStatus == STATUS_PLAY || m_nStatus == STATUS_DOWN) {
//			if((y - 32 >= BAR_POS_Y - BALL_SIZE) && (y - 32 <= BAR_POS_Y + 24)){
				m_bBarMoving = true;
				m_timeBarPrev = STD.GetTickCount();
				m_nBarTargetPosX = 32;
//			}
		}

		return;
		
	}
	
	public void onRightKey(){
		
//		if (m_nStatus == STATUS_PLAY || m_nStatus == STATUS_DOWN){
//			m_fBarPosX	+=	10;
//			if( m_fBarPosX > 630- 144 - 32 * 2 )
//				m_fBarPosX	=	630 - 144 - 32 * 2;
//		}
//		return;
		if (m_nStatus == STATUS_PLAY || m_nStatus == STATUS_DOWN) {
//			if((y - 32 >= BAR_POS_Y - BALL_SIZE) && (y - 32 <= BAR_POS_Y + 24)){
				m_bBarMoving = true;
				m_timeBarPrev = STD.GetTickCount();
				m_nBarTargetPosX = 640 - 32;
//			}
		}

		return;
		
	}
	
	public void onDPADKey(){
		
		if( m_nCurFoucus == BTN_FOCUS_START ){
			if( !m_btnStart.getVisible() )
				return;
			OnCommand( CMD_START );
			updateFocusBtns( BTN_FOCUS_MENU );
			return;
		}
		else if( m_nCurFoucus == BTN_FOCUS_MENU ){
			if( !m_btnMenu.getVisible())
				return;
			OnCommand( CMD_MENU_ASYNC );
			return;
			
		}
			
	}
	
	//kjh end
	public void OnCommand(int nCmd) {
//		if(m_nStep != 1)
//			return;
    	switch (nCmd) {
    	case CMD_MENU_ASYNC:
    		if ((m_nStatus == STATUS_WAIT) || (m_nStatus == STATUS_PLAY) || (m_nStatus == STATUS_DOWN))
    			OnOption();
    		break;
    	case CMD_SELECT_CLOSE1:
    		Close();
    		break;
    	case CMD_SELECT_CLOSE2:
    		RemoveAllButtons();
    		SetStatus(STATUS_CLOSE);
    		break;
    	case CMD_START:
    		updateFocusBtns( BTN_FOCUS_START );					//kjh
    		SetStatus(STATUS_PLAY);
    		break;
    	case CMD_SELECT_RETRY:
    		SetStatus(STATUS_SHOW);
    		break;
    	}
    }

	public void MessageBoxClosed(int dlgid) {
		switch(dlgid) {
		case 2:
			if(Globals.m_bShowYesNo) {
//		        getView().getActivity().showDialog(3);		//kjh
		        getView().getActivity().showAlertDialog( 3 );	//kjh

			}
			else {
				m_bMenu = false; //by LYM 2012/12/30			
				resume();
			}
			Globals.m_nBGMType_WndBlock = Globals.GetBGMType();
			if (Globals.m_bClickClose) { // if user clicks close button, ...
				OnClickMenuClose();
			}
			break;
		case 3:
			if(Globals.m_bSelYes) {
				PostMessage(WM_COMMAND, CMD_SELECT_CLOSE2, 0);
			}
			else {
				m_bMenu = false; //by LYM 2012/12/30
				resume();
			}
			break;
		case 4:
			if(Globals.m_bSelYes) {
				PostMessage(WM_COMMAND, CMD_SELECT_CLOSE1, 0);
			}
			else {
				Globals.playBGM(Globals.m_nBGMType_WndBlock);
				PostMessage(WM_COMMAND, CMD_SELECT_RETRY, 0);
			}
			break;
		}
	}

	public void OnOption() {
		m_bMenu = true; //by LYM 2012/12/30
		updateFocusBtns( BTN_FOCUS_MENU );					//kjh
		pause();

		Globals.SetBGMType(Globals.m_nBGMType_WndBlock);
//        getView().getActivity().showDialog(2);			//kjh
        getView().getActivity().showAlertDialog( 2 );	//kjh

	}
	
	public void OnExit() {
		SetStatus(STATUS_CLOSE);
	}
	
	private void Close() {
		RemoveAllButtons();

		DestroyWindow( frmWndMgr.WND_TITLE );
	}

	public void OnMenu() {
	}

	private int GetStepAlpha() {
		if (m_nStatus == STATUS_FAILED)
			return 0;
		if ((m_nStatus != STATUS_SHOW) && (m_nStatus != STATUS_HIDE) && (m_nStatus != STATUS_CLOSE))
			return 255;
		if (m_timeProc == 0)
			return 255;

		int	nAlpha = 255;
		long timeElapse = STD.GetTickCount() - m_timeProc;

		if(m_nStatus == STATUS_SHOW) {
			if(timeElapse >= OPEN_FRAME_COUNT * Globals.MS_PER_FRAME) {
				SetStatus(STATUS_WAIT);
				m_timeProc = STD.GetTickCount();
				timeElapse = 0;
			}
			else {
				float	fAlpha = 255.0f;

				fAlpha *= (float)timeElapse;
				fAlpha /= (float)(OPEN_FRAME_COUNT * Globals.MS_PER_FRAME);
				nAlpha = (int)fAlpha;
			}
		}
		else if(m_nStatus == STATUS_HIDE || m_nStatus == STATUS_CLOSE) {
			if(timeElapse >= CLOSE_FRAME_COUNT * Globals.MS_PER_FRAME) {
				Globals.stopBGM();

				if(m_nStatus == STATUS_HIDE) {
					nAlpha = 0;
					SetStatus(STATUS_FAILED);
				}
				else {	// STATUS_CLOSE
					nAlpha = 0;
					DestroyWindow( frmWndMgr.WND_TITLE );
				}
			}
			else {
				float	fAlpha = 255.0f;

				fAlpha *= (float)timeElapse;
				fAlpha /= (float)(CLOSE_FRAME_COUNT * Globals.MS_PER_FRAME);
				nAlpha = (int)(255.0 - fAlpha);
			}
		}

		return nAlpha;
	}
	
	public void OnPaint() {
		// drawing dimmension is just Globals.RES_WIDTH * Globals.RES_HEIGHT
		drawBackGround1();
		drawBar();
		drawBall();
		drawBackGround2();
		drawScore();

		int nAlpha = GetStepAlpha();
		setViewAlpha(nAlpha);
		
		if (m_nStatus == STATUS_FAIL) {
			SetStatus(STATUS_HIDE);
		}
		
		drawSideBackground();
		
		super.OnPaint();
	}

	//kjh start
	public void drawSideBackground(){
		
		if( !kaimin.m_bSBTV )
			return;
		m_imgLeftSideBack.draw();
		m_imgRightSideBack.draw();
		
	}
	//kjh end
	private void drawBackGround1() {
		m_imgBg.draw();
		if (m_btnStart.getVisible()){
			
			//kjh start
			if( kaimin.m_bSBTV )
				return;
			//kjh end
			
			m_imgMsg.draw();
		}
	}

	private void drawBackGround2() {
		m_imgMenuBg.draw();
		m_imgScoreBg.draw();

		if(m_nStatus == STATUS_SHOW || m_nStatus == STATUS_HIDE || m_nStatus == STATUS_CLOSE) {
			m_imgMenuNor.draw();
		}
	}

	private void drawBar() {
		
		moveBar();
		m_imgBar.draw(m_fBarPosX + 32, BAR_POS_Y + 32);
		
	}

	private void drawBall() {
		if(m_nStatus == STATUS_PLAY || m_nStatus == STATUS_DOWN) {
			moveBall();
		}

		m_imgBall.draw(m_fBallPosX + 32, m_fBallPosY + 32);
	}
	
	private void drawScore1(int nScore, float x) {
		int nOOO = 100000;
		for(int i = 0; i < 6; i ++) {
			int nOne = nScore / nOOO;
			nScore -= nOne * nOOO;
			nOOO /= 10;

			m_imgScoreNum[nOne].draw(x + 19 * i, 919.5f);
		}
	}

	private void drawScore() {
		drawScore1(m_nScore, 24.5f);
	}

	private boolean m_bBarMoving = false;
	@Override
	public void OnTouchDown(int x, int y) {
		
//		//kjh start
//		if( kaimin.m_bSBTV )
//			return;
//		//kjh end
		
		if (m_nStatus == STATUS_PLAY || m_nStatus == STATUS_DOWN) {
//			if((y - 32 >= BAR_POS_Y - BALL_SIZE) && (y - 32 <= BAR_POS_Y + 24)){
				m_bBarMoving = true;
				m_timeBarPrev = STD.GetTickCount();
				
//kjh start
				if( !kaimin.m_bSBTV )
					m_nBarTargetPosX = x - 32;
				else
//					m_nBarTargetPosX = (int) (x * 720.f / 960.f - 32.f);
					m_nBarTargetPosX	= (int) ( ( x - 267 ) * 640.f / 426.f - 32 );
				
				//kjh end
//			}
				
		}

		super.OnTouchDown(x, y);
	}

	@Override
	public void OnTouchMove(int x, int y) {
		if(m_bBarMoving) {
			if( !kaimin.m_bSBTV )
				m_nBarTargetPosX = x - 32;
			else
				m_nBarTargetPosX	= (int)( ( x - 267 ) * 640.f / 426.f - 32);
		}

		super.OnTouchMove(x, y);
	}

	@Override
	public boolean OnTouchUp(int x, int y) {
		if(m_bBarMoving) {
			
			if( !kaimin.m_bSBTV )
				m_nBarTargetPosX = x - 32;
			else
				m_nBarTargetPosX	= (int) ((x - 267 ) * 640.f / 426.f - 32);
			
			m_bBarMoving = false;
		}

		return super.OnTouchUp(x, y);
	}
	
	void IncScore() {
		if (m_nScore < 999999)
			m_nScore ++;
	}

	private void moveBar() {
		if(!m_bBarMoving || (m_nStatus == STATUS_PAUSED))
			return;

		int targetX = m_nBarTargetPosX - (BAR_SIZE_X / 2);

		long curTime = STD.GetTickCount();
		long diffTime = curTime - m_timeBarPrev;
		m_timeBarPrev = curTime;

		float fBarOldPosX = m_fBarPosX;
		if(targetX >= m_fBarPosX) {
			m_fBarPosX += (diffTime * BAR_SPEED / 1000);
			if(m_fBarPosX > targetX)
				m_fBarPosX = targetX;
			if(m_fBarPosX > 608 - 32 - BAR_SIZE_X)
				m_fBarPosX = 608 - 32 - BAR_SIZE_X;
			
			if(m_nStatus == STATUS_DOWN) { // Check Hit Ball
				if((fBarOldPosX + BAR_SIZE_X <= m_fBallPosX) && (m_fBarPosX + BAR_SIZE_X > m_fBallPosX)) {
					if(m_fBallPosY + BALL_SIZE / 2 < BAR_POS_Y + BAR_SIZE_Y / 2) {
						IncScore();
						m_nBallMotion = MOTION_RIGHTTOP;
						m_nStatus = STATUS_PLAY;
					}
					else if(m_fBallPosY < BAR_POS_Y + BAR_SIZE_Y) {
						m_nBallMotion = MOTION_RIGHTBOTTOM;
					}
				}
			}
		}
		else {
			m_fBarPosX -= (diffTime * BAR_SPEED / 1000);
			if(m_fBarPosX < targetX)
				m_fBarPosX = targetX;
			if(m_fBarPosX < 0)
				m_fBarPosX = 0;
			
			if(m_nStatus == STATUS_DOWN) { // Check Hit Ball
				if((fBarOldPosX >= m_fBallPosX + BALL_SIZE) && (m_fBarPosX < m_fBallPosX + BALL_SIZE)) {
					if(m_fBallPosY + BALL_SIZE / 2 < BAR_POS_Y + BAR_SIZE_Y / 2) {
						IncScore();
						m_nBallMotion = MOTION_LEFTTOP;
						m_nStatus = STATUS_PLAY;
					}
					else if(m_fBallPosY < BAR_POS_Y + BAR_SIZE_Y) {
						m_nBallMotion = MOTION_LEFTBOTTOM;
					}
				}
			}
		}
	}
	
	private void moveBall() {
		long curTime = STD.GetTickCount();
		float fMoveDistance = (curTime - m_timeBallPrev) * BALL_SPEED / 1000f;
		m_timeBallPrev = curTime;
		
		while(fMoveDistance > 0) {
			if(m_nStatus == STATUS_PLAY) {
				if(m_nBallMotion == MOTION_RIGHTTOP) {
					fMoveDistance = moveRightTop(fMoveDistance);
				}
				else if(m_nBallMotion == MOTION_LEFTTOP) {
					fMoveDistance = moveLeftTop(fMoveDistance);
				}
				else if(m_nBallMotion == MOTION_RIGHTBOTTOM) {
					fMoveDistance = moveRightBottom(fMoveDistance);
				}
				else if(m_nBallMotion == MOTION_LEFTBOTTOM) {
					fMoveDistance = moveLeftBottom(fMoveDistance);
				}
			}
			else if(m_nStatus == STATUS_DOWN) {
				if(m_nBallMotion == MOTION_RIGHTBOTTOM) {
					fMoveDistance = moveRightBottom_Down(fMoveDistance);
				}
				else if(m_nBallMotion == MOTION_LEFTBOTTOM) {
					fMoveDistance = moveLeftBottom_Down(fMoveDistance);
				}
			}
		}
	}
	
	private float moveRightTop(float fMoveDistance) {
		float fFocusPosX = m_fBallPosX + BALL_SIZE;
		float fFocusPosY = m_fBallPosY;

		float fDisX = (640 - 32 * 2) - fFocusPosX;
		float fDisY = fFocusPosY;

		if((fDisX > fMoveDistance) && (fDisY > fMoveDistance)) {
			m_fBallPosX += fMoveDistance;
			m_fBallPosY -= fMoveDistance;
			fMoveDistance = 0;
		}
		else {
			if (fDisX < fDisY) { // Check Right Wall
				fMoveDistance -= fDisX;
				m_fBallPosX += fDisX;
				m_fBallPosY -= fDisX;
				
				m_nBallMotion = MOTION_LEFTTOP;
			}
			else { // Check Top Wall
				fMoveDistance -= fDisY;
				m_fBallPosX += fDisY;
				m_fBallPosY -= fDisY;
				
				m_nBallMotion = MOTION_RIGHTBOTTOM;
			}
		}
		
//		Log.d("KJH", String.format("%d-%d", m_fBallPosX, m_fBallPosY ) );
		
		return fMoveDistance;
	}
	
	private float moveLeftTop(float fMoveDistance) {
		float fFocusPosX = m_fBallPosX;
		float fFocusPosY = m_fBallPosY;

		float fDisX = fFocusPosX;
		float fDisY = fFocusPosY;

		if((fDisX > fMoveDistance) && (fDisY > fMoveDistance)) {
			m_fBallPosX -= fMoveDistance;
			m_fBallPosY -= fMoveDistance;
			fMoveDistance = 0;
		}
		else {
			if (fDisX < fDisY) { // Check Left Wall
				fMoveDistance -= fDisX;
				m_fBallPosX -= fDisX;
				m_fBallPosY -= fDisX;
				
				m_nBallMotion = MOTION_RIGHTTOP;
			}
			else { // Check Top Wall
				fMoveDistance -= fDisY;
				m_fBallPosX -= fDisY;
				m_fBallPosY -= fDisY;
				
				m_nBallMotion = MOTION_LEFTBOTTOM;
			}
		}
		
		return fMoveDistance;
	}
	
	private float moveRightBottom(float fMoveDistance) {
		float fFocusPosX = m_fBallPosX + BALL_SIZE;
		float fFocusPosY = m_fBallPosY + BALL_SIZE;

		float fDisX = (640 - 32 * 2) - fFocusPosX;
		float fDisY = BAR_POS_Y - fFocusPosY;;

		if((fDisX > fMoveDistance) && (fDisY > fMoveDistance)) {
			m_fBallPosX += fMoveDistance;
			m_fBallPosY += fMoveDistance;
			fMoveDistance = 0;
		}
		else {
			if (fDisX <= fDisY) { // Check Right Wall
				fMoveDistance -= fDisX;
				m_fBallPosX += fDisX;
				m_fBallPosY += fDisX;
				
				m_nBallMotion = MOTION_LEFTBOTTOM;
			}
			else {
				fMoveDistance -= fDisY;
				m_fBallPosX += fDisY;
				m_fBallPosY += fDisY;
				
				if((m_fBallPosX + BALL_SIZE <= m_fBarPosX) || (m_fBallPosX >= m_fBarPosX + BAR_SIZE_X)) {
					m_nStatus = STATUS_DOWN;
//					fMoveDistance = 0;
				}
				else {
					IncScore();
					
					if(m_fBallPosX + BALL_SIZE < m_fBarPosX + 10) {
						m_nBallMotion = MOTION_LEFTTOP;
					}
					else {
						m_nBallMotion = MOTION_RIGHTTOP;
					}
				}
			}
		}

		return fMoveDistance;
	}
	
	private float moveLeftBottom(float fMoveDistance) {
		float fFocusPosX = m_fBallPosX;
		float fFocusPosY = m_fBallPosY + BALL_SIZE;

		float fDisX = fFocusPosX;
		float fDisY = BAR_POS_Y - fFocusPosY;

		if((fDisX > fMoveDistance) && (fDisY > fMoveDistance)) {
			m_fBallPosX -= fMoveDistance;
			m_fBallPosY += fMoveDistance;
			fMoveDistance = 0;
		}
		else {
			if(fDisX <= fDisY) { // Check Left Wall
				fMoveDistance -= fDisX;
				m_fBallPosX -= fDisX;
				m_fBallPosY += fDisX;
				
				m_nBallMotion = MOTION_RIGHTBOTTOM;
			}
			else {
				fMoveDistance -= fDisY;
				m_fBallPosX -= fDisY;
				m_fBallPosY += fDisY;
				
				if((m_fBallPosX + BALL_SIZE <= m_fBarPosX) || (m_fBallPosX >= m_fBarPosX + BAR_SIZE_X)) {
					m_nStatus = STATUS_DOWN;
//					fMoveDistance = 0;
				}
				else {
					IncScore();

					if(m_fBallPosX > m_fBarPosX + BAR_SIZE_X - 10) {
						m_nBallMotion = MOTION_RIGHTTOP;
					}
					else {
						m_nBallMotion = MOTION_LEFTTOP;
					}
				}
			}
		}

		return fMoveDistance;
	}
	
	private float moveRightBottom_Down(float fMoveDistance) {

		float fBarDist = m_fBarPosX - m_fBallPosX - BALL_SIZE;
		float fWallDist = (640 - 32 * 2) - m_fBallPosX - BALL_SIZE;
		float fDownDist = DOWN_POS_Y - m_fBallPosY;
		
		if(fBarDist < 0 || m_fBallPosY + fBarDist + BALL_SIZE < BAR_POS_Y || m_fBallPosY + fBarDist > BAR_POS_Y + BAR_SIZE_Y)
			fBarDist = 100000f; // Max Value

		if((fMoveDistance <= fBarDist) && (fMoveDistance <= fWallDist) && (fMoveDistance <= fDownDist)) {
			m_fBallPosX += fMoveDistance;
			m_fBallPosY += fMoveDistance;
			fMoveDistance = 0;
		}
		else if((fDownDist <= fBarDist) && (fDownDist <= fWallDist)) { // Dropped
			m_fBallPosX += fDownDist;
			m_fBallPosY += fDownDist;
			m_nStatus = STATUS_FAIL;
			fMoveDistance = 0;
		}
		else if(fWallDist <= fBarDist) { // Right Wall
			m_fBallPosX += fWallDist;
			m_fBallPosY += fWallDist;
			m_nBallMotion = MOTION_LEFTBOTTOM;
			fMoveDistance -= fWallDist;
		}
		else { // Bar
			if(m_fBallPosY + fBarDist + BALL_SIZE / 2 < BAR_POS_Y + BAR_SIZE_Y / 2) {
				m_fBallPosX += fBarDist;
				m_fBallPosY += fBarDist;
				IncScore();
				m_nBallMotion = MOTION_LEFTTOP;
				m_nStatus = STATUS_PLAY;
				fMoveDistance -= fBarDist;
			}
			else {
				m_fBallPosX += fBarDist;
				m_fBallPosY += fBarDist;
				m_nBallMotion = MOTION_LEFTBOTTOM;
				fMoveDistance -= fBarDist;
			}
		}
		
		return fMoveDistance;
	}
	
	private float moveLeftBottom_Down(float fMoveDistance) {

		float fBarDist = m_fBallPosX - m_fBarPosX - BAR_SIZE_X;
		float fWallDist = m_fBallPosX;
		float fDownDist = DOWN_POS_Y - m_fBallPosY;
		
		if(fBarDist < 0 || m_fBallPosY + fBarDist + BALL_SIZE < BAR_POS_Y || m_fBallPosY + fBarDist > BAR_POS_Y + BAR_SIZE_Y)
			fBarDist = 100000f; // Max Value
		
		if((fMoveDistance <= fBarDist) && (fMoveDistance <= fWallDist) && (fMoveDistance <= fDownDist)) {
			m_fBallPosX -= fMoveDistance;
			m_fBallPosY += fMoveDistance;
			fMoveDistance = 0;
		}
		else if((fDownDist <= fBarDist) && (fDownDist <= fWallDist)) { // Dropped
			m_fBallPosX -= fDownDist;
			m_fBallPosY += fDownDist;
			m_nStatus = STATUS_FAIL;
			fMoveDistance = 0;
		}
		else if(fWallDist <= fBarDist) { // Left Wall
			m_fBallPosX -= fWallDist;
			m_fBallPosY += fWallDist;
			m_nBallMotion = MOTION_RIGHTBOTTOM;
			fMoveDistance -= fWallDist;
		}
		else { // Bar
			if(m_fBallPosY + fBarDist + BALL_SIZE / 2 < BAR_POS_Y + BAR_SIZE_Y / 2) {
				m_fBallPosX -= fBarDist;
				m_fBallPosY += fBarDist;
				IncScore();
				m_nBallMotion = MOTION_RIGHTTOP;
				m_nStatus = STATUS_PLAY;
				fMoveDistance -= fBarDist;
			}
			else {
				m_fBallPosX -= fBarDist;
				m_fBallPosY += fBarDist;
				m_nBallMotion = MOTION_RIGHTBOTTOM;
				fMoveDistance -= fBarDist;
			}
		}
		
		return fMoveDistance;
	}

	private void pause() {
		m_nStatusOldForSuspend = m_nStatus;
		m_nStatus = STATUS_PAUSED;
		m_timePaused = STD.GetTickCount();
	}

	private void resume() {
		long difTime = STD.GetTickCount() - m_timePaused;
		m_timeBallPrev += difTime;
		
		m_nStatus = m_nStatusOldForSuspend;
	}

	public void OnSuspend() {
		if(Globals.m_nBGMType_WndBlock < Globals.m_nBGMIDs.length) {
			Globals.pauseBGM();
		}
		if (m_bMenu == false) //by LYM 2012/12/30
			pause();
	}

	public void OnResume() {
		if(Globals.m_nBGMType_WndBlock < Globals.m_nBGMIDs.length) {
			Globals.resumeBGM();
		}
		if (m_bMenu == false) //by LYM 2012/12/30
			resume();
	}
}
