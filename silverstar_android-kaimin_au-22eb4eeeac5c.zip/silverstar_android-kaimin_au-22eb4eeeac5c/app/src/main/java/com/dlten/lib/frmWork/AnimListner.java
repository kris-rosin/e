package com.dlten.lib.frmWork;

/**
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2009</p>
 *
 * @author not attributable
 * @version 1.0
 */
public interface AnimListner {
    public abstract void onAnimAction( CAnimation anim, Object param );
}
