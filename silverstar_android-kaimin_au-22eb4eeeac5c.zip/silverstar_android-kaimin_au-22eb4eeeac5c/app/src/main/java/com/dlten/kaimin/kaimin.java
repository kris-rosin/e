package com.dlten.kaimin;

//import biz.appvisor.push.android.sdk.AppVisorPush;
//import biz.appvisor.push.android.sdk.ChangePushStatusListener;

//import net.gree.reward.sdk.GreeRewardFactory;
//import net.gree.reward.sdk.GreeRewardAction;

//import java.io.File;
//import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.EncodedKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Calendar;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import min3d.core.Object3dContainer;
import min3d.core.RendererActivity;
import min3d.parser.IParser;
import min3d.parser.Parser;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManager;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.dlten.kaimin.wnds.WndDrive;
import com.dlten.kaimin_auOM.R;
import com.dlten.lib.CBaseView;
import com.dlten.lib.STD;
import com.dlten.lib.frmWork.CWnd;
import com.kddi.market.alml.lib.ALMLClient;
import com.kddi.market.alml.lib.ALMLClient.IALMLClientCallback;
import com.kddi.market.alml.util.ALMLConstants;
import com.kddi.market.alml.util.Base64;
//import android.os.Environment;
//import android.util.Log;
//import android.view.Menu;
//import android.view.MenuItem;


//import android.os.Bundle;

public class kaimin extends RendererActivity implements View.OnClickListener {
	
//	private AppVisorPush appVisorPush;
	private kaimin m_MainActivity;
	private frmView m_viewMain = null;
	private WebView			m_viewHelp = null;
	private LinearLayout	m_lytHelp  = null;
	private int				m_nShowHelp = 0; //0:mainview, 1:help
//	private final String	m_strOther_InfoUrl = "http://www.silverstar.co.jp/ausmart/info/";
	private final String	m_strOther_InfoUrl = "http://www.silverstar.co.jp/ausmart/link/";
	private final String	m_strOther_LinkUrl = "http://www.silverstar.co.jp/ausmart/link/";
	private int			m_nSuspendHelp = 0;
	private TextView		m_txtHelpTitle = null;
	
	private AlertDialog m_dlg2 = null;
    private TextView m_textView = null;

//*************************** AU Code Start *********************************
	/** Called when the activity is first created. */
    // SKY:120214:start
//  private boolean m_bHasFocus = false;
  public boolean m_bCertiEnd = false;
  public boolean m_bCertSuccess = false;

  // SKY:end

  /////////////////////////////////////////////////////////////////////////////////////////
	// SKY:120125:start:auOneMarket
//	boolean m_bUseToast = true;// ------------------------------->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>!!!!!!!!!!!!!!!!
	private final Handler handler = new Handler();
	
	boolean m_bBind = false;
	
	final int IDM_BIND_APP_NOTHING 		= 0;
	final int IDM_BIND_APP_ERROR 		= 1;
	
	final int IDM_AU_CONNECT_ERROR 		= 2;
	final int IDM_AU_SERVER_ERROR		= 3;
	final int IDM_AU_SERVER_MAINTENANCE = 4;
	final int IDM_AU_AUTH_ERROR			= 5;
	final int IDM_AU_UPDATING 			= 6;
	final int IDM_AU_NEED_VERSIONUP 	= 7;
	final int IDM_AU_ILLEGAL_ACCESS 	= 8;
	final int IDM_AU_CAPTCA 			= 9;
	
	final int IDM_KEY_ERROR				= 10;

	final int IDM_ILLEGAL_USER			= 11;
	
	final int IDM_AU_NO_BU_APPLI 		= 12;
	final int IDM_AU_BU_NOT_JOINED		= 13;
	final int IDM_AU_BU_STATUS_ERROR	= 14;
	
	final int IDM_ERR_DECODE_1			= 100;
	final int IDM_ERR_DECODE_2			= 101;
	final int IDM_ERR_INVALID_KEY		= 102;
	final int IDM_ERR_CIPHER_1			= 103;
	final int IDM_ERR_CIPHER_2			= 104;
	
	// KLMLインスタンス
	private ALMLClient mAlmlClient;
	// ライセンス認証キャッシュ保持期間[秒]
	private static final long CACHE_TIME = 86400;//3600;
	// ライセンス認証用SEED
	private static final String SEED = "SEED_AU_GINSEI_KAIMIN";
	
	// 提供された公開鍵を設定
	private static final String ALML_PUBLIC_KEY = "" +
//			"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCbG6JIWgm+36L62SHyzOJ09XwI" + "" +
//			"9awcVUbM12EixHwhd+Hxv04H8uA3HfbGf3SSMqJdZbZsBB9qIfRco/4tHzH7VAeM" + "" +
//			"cIulWXe6C+ToL/3Q3gWRYzX3AB63/GEKV8tGXoNQ0izVmES2CpVU7A3zcDRPjvnV" + "" +
//			"pBYm2pQj4NblEb+ugQIDAQAB"; // real!!!
	
	"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCHBVA7m66ak/M9xGoG21pl4RMYCFO8Dsu" + "" +
	"JAJp4gOHlZ+YIgEkNkYTb+r+llDUD1jjizWq1OLTYaQ1Yj04tQ71neQ1wdwvduSP+CJDPjtSpwJFtCxc" + "" +
	"QSleXMdMB5BJHeVtjtUnBYmKE34bP35NVEgs5LAFAIO9s6iuV/i7qkM+zTwIDAQAB"; // test
	
//	private static final String GCM_SENDER_ID = "977032931711";
//	private static final String TAG = "AppVisor Demo";
	
	// 公開鍵オブジェクト
	private PublicKey mPublicKey;
	
	// SKY:end
	
	  private void startMainProgram() { // SKY:120208
//	    	new Thread(new Runnable(){
//				
//	      	  	@Override
//	      	  	public void run() {
//	      	  		handler.post(new Runnable() {
//	      	  			public void run() {
	      	  				startProgram();
//	      	  			}
//	      	  		});
//	      	  	}
//	      	}).start();
	    }

	    private void startProgram() {
	        
	        
	        // SKY:120214:start
	        m_bCertiEnd = true;
	        m_bCertSuccess = true;
//			myInit(m_bCertiEnd && m_bHasFocus);
			// SKY:end
	    	myInit(true);
			
			STD.logout("start Program");
	    }
	    
//	    public void onPushNotification() {
//	    	//sdk初期化(必須)
//	    	this.appVisorPush = AppVisorPush.sharedInstance();
//	    	//AppVisorPush用のAPPIDを設定します。
//	    	String appID = "qm8CBdumyc";
//	    	this.appVisorPush.setAppInfor(getApplicationContext(), appID);
//	    	//通知関連の内容を設定します。(GCM_SENDER_ID,通知アイコン,ステータスバーアイコン,通知で起動するClass名、デフォルトの通知タイトル)
//	    	this.appVisorPush.startPush(GCM_SENDER_ID, R.drawable.icon, R.drawable.statusbar_icon, kaimin.class, getString(R.string.app_name));
//
//	    	//Push反応率チェック(必須)
//	    	this.appVisorPush.trackPushWithActivity(this);
//	    	
//	    	//ActivityがAppVisorPushで起動かどうかの判断(Option)
//	        if( this.appVisorPush.checkIfStartByAppVisorPush(this) )
//	        {
//	        	//例：Push内のメーセージ内容をAlertで表示させる。
//	        	Log.d(TAG,"get Push by AppVisorPush ...");
//	        	Bundle bundle = this.appVisorPush.getBundleFromAppVisorPush(this);
//	        	String messageStr = bundle.getString("message");
//	        	
//	        	AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
//	        	// アラートダイアログのタイトルを設定します
//	            alertDialogBuilder.setTitle("キャンペーン情報");
//	            // アラートダイアログのメッセージを設定します
//	            alertDialogBuilder.setMessage(messageStr);
//	            alertDialogBuilder.setPositiveButton("OK", null);
//	            //アラートダイアログを表示します
//	            alertDialogBuilder.create().show();
//	        };
//	    }
	    
//	    //必須
//	    protected void onNewIntent (Intent intent) 
//	    {
//		    super.onNewIntent(intent);
//		    //画面表示時に再度起動された際にgetIntent()を更新する。
//		    setIntent(intent);
//	    }
//	    
//	    //Push　On/off切替用メソッド(Option)
//	    public void changePushStatus(boolean on) 
//	    {
//		    ChangePushStatusListener listener = new ChangePushStatusListener()
//		    {
//			    @Override
//			    public void changeStatusSucceeded(boolean pushStatus)
//			    {
//			    //切替成功の時に呼ばれます
//			    }
//			    @Override
//			    public void changeStatusFailed(boolean pushStatus)
//			    {
//			    //切替失敗の時に呼ばれます
//			    }
//		    };
//	
//		    //Event listener 設定
//		    this.appVisorPush.addChangePushStatusListener(listener);
//	
//		    //On/Off 変更
//		    this.appVisorPush.changePushRecieveStatus(on);
//		}
//	    
//	    public boolean getPushStatus() {
//	    	boolean pushEnabled = this.appVisorPush.getPushRecieveStatus();
//	    	return pushEnabled;
//	    }
	    
	 // Initiating Menu XML file (menu.xml)
//	    @Override
//	    public boolean onCreateOptionsMenu(Menu menu)
//	    {
//	        getMenuInflater().inflate(R.layout.menu, menu);
//	        return true;
//	    }
//	     
//	    /**
//	     * Event Handling for Individual menu item selected
//	     * Identify single menu item by it's id
//	     * */
//	    @Override
//	    public boolean onOptionsItemSelected(MenuItem item)
//	    {
//	         
//	        switch (item.getItemId())
//	        {
//	        case R.id.menu_push_on:
//	        	changePushStatus(true);
//	            return true;
//	 
//	        case R.id.menu_push_off:
//	        	changePushStatus(false);
//	            return true;
//	 
//	        default:
//	            return super.onOptionsItemSelected(item);
//	        }
//	    } 
	    
//		public void onGree() {
//			GreeRewardAction action = GreeRewardFactory.getActionInstance(this);
//			action.sendAction(3896, "install", 0, "kaimin://");
//		}
		
	    public void processCertificate() {
			
	        /////////////////////////////////////////////////////////////////////////////////////////
	    	// SKY:120125:start:auOneMarket

	    	m_bBind = false;
	        
	        // 公開鍵のデコード
	        byte[] decodePublicKey = Base64.decode(ALML_PUBLIC_KEY, Base64.NO_WRAP);
	        try {
	        	// RSA暗号化方式を設定
	        	KeyFactory keyFactory = KeyFactory.getInstance("RSA");
	        	// デコードした公開鍵を元に公開鍵オブジェクトを生成する
	        	EncodedKeySpec keySpec = new X509EncodedKeySpec(decodePublicKey);
	        	// 公開鍵オブジェクトの生成
	        	mPublicKey = keyFactory.generatePublic(keySpec);
	        } catch (NoSuchAlgorithmException e) {
	        	// TODO
	        	MessageBox(IDM_KEY_ERROR);
	        	return;
	        } catch (InvalidKeySpecException e) {
	        	// TODO
	        	MessageBox(IDM_KEY_ERROR);
	        	return;
	        }
	        
	        startMainProgram();
//	        certificateAU();
	        // SKY:end
	        //////////////////////////////////////////////////////////////////////////////////////////

	    }
	    
		// SKY:120125:start:auOneMarket
	    private void certificateAU() {
	    	auUnbind();
	    	if (mAlmlClient != null)
	    	{
	    		mAlmlClient = null;
	    		System.gc();
	    	}
	    	
	        // KLMLインスタンスの生成
	        mAlmlClient = new ALMLClient();
	        // Bind Service
	        int result = mAlmlClient.bind(this);
	        if (ALMLConstants.ALML_SUCCESS == result) {
	        	// バインド成功
	        	m_bBind = true;
	        	
	        	// ライセンス認証を行う
	        	mAlmlClient.authorizeLicense(this.getPackageName(), mAlmlCallback, CACHE_TIME, SEED);
	        } else {
	        	// aLMLに接続できない場合
	        	// TODO
	        	if (ALMLConstants.ALML_MARKET_APP_NOTHING == result)
	        		MessageBox(IDM_BIND_APP_NOTHING);
	        	else 
	        		MessageBox(IDM_BIND_APP_ERROR);
	        	return;
	        }
	    }
	    
	    private void certificateLicense(String license, String createTime) {
	    	
	    	// ライセンス認証情報のデコード
	    	byte[] base64decode = Base64.decode(license, Base64.NO_WRAP);
	    	// 復号化オブジェクト
	    	Cipher cipher = null;
	    	try {
	    		// RSA復号を指定
	    		cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
//	    		cipher = Cipher.getInstance("RSA/ECB/NoPadding");
	    	} catch (NoSuchAlgorithmException e) {
	    		// TODO
	    		MessageBox(IDM_ERR_DECODE_1);
	    	} catch (NoSuchPaddingException e) {
	    		// TODO
	    		MessageBox(IDM_ERR_DECODE_2);
	    	}
	    	
	    	// 復号化オブジェクトの初期化
	    	try {
	    		// 復号モードと公開鍵を設定
	    		cipher.init(Cipher.DECRYPT_MODE, mPublicKey);
	    	} catch (InvalidKeyException e) {
	    		// TODO
	    		MessageBox(IDM_ERR_INVALID_KEY);
	    	}
	    	
	    	// 復号ライセンス情報格納領域
	    	byte[] decode = null;
	    	// 復号化の実施
	    	try {
	    		decode = cipher.doFinal(base64decode);
	    	} catch (IllegalBlockSizeException e) {
	    		// TODO
	    		MessageBox(IDM_ERR_CIPHER_1);
	    	} catch (BadPaddingException e) {
	    		// TODO
	    		MessageBox(IDM_ERR_CIPHER_2);
	    	}
	    	
	    	// 復号ライセンス認証情報を文字列に変換
	    	String decodeLicense = new String(decode);
	    	// 「作成時刻(YYYYMMDDHMMSS) + seed情報」と一致しているか確認
	    	if ( decodeLicense.equals(createTime + SEED) ) {
	    		// 正規の利用者
	    		// TODO
//	    		startProgram();
	    		
	    		startMainProgram();
	    		
	    	} else {
	    		// 不正な利用者
	    		// TODO
	    		MessageBox(IDM_ILLEGAL_USER);
	    	}
	    }
	    
	    // ライセンス認証コールバック
	    private IALMLClientCallback mAlmlCallback = new IALMLClientCallback() {
	    	
	        @Override
	        public void onAuthorizeLicenseResult(final int resultCode, final String license, final String createTime,
	        		final Map<String, Object> resultInfo) {
	        // 月額課金ステータスの取得
//	        int status = resultInfo.get("accountStatus");
//	        if (ALMLConstants.ALML_STATUS_JOINED == status) {
//	        	// 課金済み
//	        	// TODO
//	        } else {
//	        	// 課金済みでない or 通信エラー等で取得不可
//	        	// TODO
//	        }

	            // ライセンス認証結果判定
	            if (ALMLConstants.ALML_SUCCESS == resultCode) {
	            	// ライセンス認証成功
	            	// TODO
	            	int buStatus = (Integer) resultInfo.get("apassStatus");
	            	switch (buStatus) {
	            	case ALMLConstants.ALML_APASS_STATUS_NOT_APASS_APPLI:
	            		MessageBox(IDM_AU_NO_BU_APPLI);
	            		break;
	            	case ALMLConstants.ALML_APASS_STATUS_JOINED:
	            		certificateLicense(license, createTime);
	            		break;
	            	case ALMLConstants.ALML_APASS_STATUS_NOT_JOINED:
	            		MessageBox(IDM_AU_BU_NOT_JOINED);
	            		break;
	            	case ALMLConstants.ALML_APASS_STATUS_ERROR:
	            		MessageBox(IDM_AU_BU_STATUS_ERROR);
	            		break;
	            	}
	            } else {
	            	// ライセンス認証失敗
	            	// TODO
	            	switch (resultCode) {
	            	case ALMLConstants.ALML_CONNECT_ERROR: // 通信エラー
	            		MessageBox(IDM_AU_CONNECT_ERROR);
	            		break;
	            	case ALMLConstants.ALML_SERVER_ERROR:// サーバエラー
	            		MessageBox(IDM_AU_SERVER_ERROR);
	            		break;
	            	case ALMLConstants.ALML_SERVER_MAINTENANCE:// サーバメンテナンス中
	            		MessageBox(IDM_AU_SERVER_MAINTENANCE);
	            		break;
	            	case ALMLConstants.ALML_AUTH_ERROR:// ユーザ認証エラー
//	            		if (m_bUseToast)
//	            			ShowToast(IDM_AU_AUTH_ERROR);
//	            		else
	            			MessageBox(IDM_AU_AUTH_ERROR);
	            		break;
	            	case ALMLConstants.ALML_UPDATING:// バージョンアップ中
	            		MessageBox(IDM_AU_UPDATING);
	            		break;
	            	case ALMLConstants.ALML_NEED_VERSION_UP: // バージョンアップ未実施
//	            		if (m_bUseToast)
//	            			ShowToast(IDM_AU_NEED_VERSIONUP);
//	            		else
	            		
	            		killProcess();
	            		
//	            			MessageBox(IDM_AU_NEED_VERSIONUP);
	            		break;
	            	case ALMLConstants.ALML_ILLEGAL_ACCESS: // 不正アクセス
	            		MessageBox(IDM_AU_ILLEGAL_ACCESS);
	            		break;
	            	case ALMLConstants.ALML_INPUT_ERROR:// 入力値エラー
	            		MessageBox(IDM_AU_ILLEGAL_ACCESS);
	            		break;
	            	case ALMLConstants.ALML_CAPTCHA_ERROR:// CAPTCHA認証エラー
//	            		if (m_bUseToast)
//	            			ShowToast(IDM_AU_CAPTCA);
//	            		else
	            			MessageBox(IDM_AU_CAPTCA);
	            		break;
	            	case ALMLConstants.ALML_MARKET_APP_DISCONNECT:// au one Market接続エラー
	            		MessageBox(IDM_AU_ILLEGAL_ACCESS);
	            		break;
	            	case ALMLConstants.ALML_APPLICATION_ERROR:// 予期しないエラー
	            		MessageBox(IDM_AU_ILLEGAL_ACCESS);
	            		break;
	            	}
	            }
	        }
	    };
	    
	    private void MessageBox(int nMsgID) 
	    {
			m_strMsgTitle = getString(R.string.au_alert_title);
			m_strMsg = "";
			
			m_nMsgType = DIALOG_OK_KILL_APP;
	    	switch (nMsgID)
	    	{
			case IDM_BIND_APP_NOTHING:
				m_nMsgType = DIALOG_DOWNLOAD;
				m_strMsg = getString(R.string.au_app_nothing);
				break;

			case IDM_AU_CONNECT_ERROR:
				m_nMsgType = DIALOG_CONNECT;
				m_strMsg = getString(R.string.au_connect_error);
				break;

			
			case IDM_BIND_APP_ERROR:
				m_strMsg = getString(R.string.au_app_error);
				break;
			case IDM_AU_SERVER_ERROR:
				m_strMsg = getString(R.string.au_server_error);
				break;
			case IDM_AU_SERVER_MAINTENANCE:
				m_strMsg = getString(R.string.au_server_maintenance);
				break;
			case IDM_AU_UPDATING:
				m_strMsg = getString(R.string.au_updating);
				break;
			case IDM_AU_ILLEGAL_ACCESS:
				m_strMsg = getString(R.string.au_illegal_access);
				break;
			case IDM_KEY_ERROR:
				m_strMsg = getString(R.string.au_key_error);
				break;
			case IDM_ILLEGAL_USER:
				m_strMsg = getString(R.string.au_illegal_user);
				break;
				
			case IDM_AU_NO_BU_APPLI:
				m_strMsg = getString(R.string.au_no_bu_appli);
				break;
			case IDM_AU_BU_NOT_JOINED:
				m_strMsg = getString(R.string.au_bu_not_joined);
				break;
			case IDM_AU_BU_STATUS_ERROR:
				m_strMsg = getString(R.string.au_bu_status_error);
				break;
				
			case IDM_ERR_DECODE_1:
				m_strMsg = getString(R.string.au_decode_error_1);
				break;
			case IDM_ERR_DECODE_2:
				m_strMsg = getString(R.string.au_decode_error_2);
				break;
			case IDM_ERR_INVALID_KEY:
				m_strMsg = getString(R.string.au_decode_invalid_key);
				break;
			case IDM_ERR_CIPHER_1:
				m_strMsg = getString(R.string.au_cipher_1);
				break;
			case IDM_ERR_CIPHER_2:
				m_strMsg = getString(R.string.au_cipher_2);
				break;

	    	
	    	case IDM_AU_AUTH_ERROR:
	    		m_strMsg = getString(R.string.au_auth_error);
	    		break;
	    		
	    	case IDM_AU_NEED_VERSIONUP:
	    		m_nMsgType = DIALOG_TOAST;
	    		m_strMsg = getString(R.string.au_need_versionup);
	    		break;
	    		
	    	case IDM_AU_CAPTCA:
	    		m_nMsgType = DIALOG_CERTIFICATE;
				m_strMsg = getString(R.string.au_captcha_error);
	    		break;
	    	default:;
	    	}
	    	
	    	new Thread(new Runnable(){
				AlertDialog dialog;
				
	      	  	@Override
	      	  	public void run() {
	      	  		handler.post(new Runnable() {
	      	  			public void run() {
	      	  				try{
	      	  					
	      	  					if (m_nMsgType == DIALOG_TOAST) {
//	      	  						Toast.makeText(frmActivity.this, m_strMsg, Toast.LENGTH_LONG).show();
	          	  					// 	then kill the process
	      	  						killProcess();//???-0--------------------
	      	  						return;
	      	  					}
	      	  					     	  					
	      	  					if ( dialog != null ) 
	      	  						return;
	      	  					
	      	  					switch (m_nMsgType) {
	          	  		        case DIALOG_OK_KILL_APP:
	      	  						dialog = new AlertDialog.Builder(kaimin.this)
	      	  							//.setIcon(R.drawable.alert_dialog_icon)
	      	  							.setCancelable(false)
	      	  							.setTitle(m_strMsgTitle)
	      	  							.setMessage(m_strMsg)
	      	  							.setPositiveButton("OK", new DialogInterface.OnClickListener() {
	      	  								public void onClick(DialogInterface dialog, int whichButton) {

	      	  									// User clicked OK so do some stuff
	      	  									killProcess();
	      	  								}
	      	  							}).create();
	      	  						break;
	      	  						
	          	  		        case DIALOG_DOWNLOAD:
	          	  		        	dialog = new AlertDialog.Builder(kaimin.this)
	          	  		        		//.setIcon(R.drawable.alert_dialog_icon)
	          	  		        		.setCancelable(false)
	          	  		        		.setTitle(m_strMsgTitle)
	          	  		        		.setMessage(m_strMsg)
	          	  		        		.setPositiveButton("Download", new DialogInterface.OnClickListener() {
	          	  		        			public void onClick(DialogInterface dialog, int whichButton) {

	          	  		        				Uri uriUrl = Uri.parse("http://market.kddi.com/update_info/");  
	          	  		        				Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriUrl);
	          	  		        				startActivity(launchBrowser);
	          		    					
	          	  		        				killProcess();//???-0--------------------
	          	  		        			}
	          	  		        		})
	          	  		        		.setNegativeButton("キャンセル", new DialogInterface.OnClickListener() {
	          	  		        			public void onClick(DialogInterface dialog, int whichButton) {
	          	  		        				killProcess();
	          	  		        			}
	          	  		        		})
	          	  		        		.create();
	          	  		        	break;
	          	  		        	
	          	  		        case DIALOG_CONNECT:
	          	  		        	dialog = new AlertDialog.Builder(kaimin.this)
	          	  		        		//.setIcon(R.drawable.alert_dialog_icon)
	          	  		        		.setCancelable(false)
	          	  		        		.setTitle(m_strMsgTitle)
	          	  		        		.setMessage(m_strMsg)
	          	  		        		.setPositiveButton("はい", new DialogInterface.OnClickListener() {
	          	  		        			public void onClick(DialogInterface dialog, int whichButton) {

	          	  		        				certificateAU();
	          	  		        			}
	          	  		        		})
	          	  		        		.setNegativeButton("いいえ", new DialogInterface.OnClickListener() {
	          	  		        			public void onClick(DialogInterface dialog, int whichButton) {
	          	  		        				killProcess();
	          	  		        			}
	          	  		        		})
	          	  		        		.create();
	          	  		        	break;

	          	  		        case DIALOG_CERTIFICATE:
	          	  		        	dialog = new AlertDialog.Builder(kaimin.this)
	          	  		        		//.setIcon(R.drawable.alert_dialog_icon)
	          	  		        		.setCancelable(false)
	          	  		        		.setTitle(m_strMsgTitle)
	          	  		        		.setMessage(m_strMsg)
	          	  		        		.setPositiveButton("Webへ", new DialogInterface.OnClickListener() {
	          	  		        			public void onClick(DialogInterface dialog, int whichButton) {

	          	  		        				Uri uriUrl = Uri.parse("https://integration.auone.jp/login/CMN2101E00.do?targeturl=http://auone.jp/");  
	          	  		        				Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriUrl);
	          	  		        				startActivity(launchBrowser);
	          		    					
	          	  		        				killProcess();//?????????????????????????????????????????????
	          	  		        			}
	          	  		        		})
	          	  		        		.setNegativeButton("キャンセル", new DialogInterface.OnClickListener() {
	          	  		        			public void onClick(DialogInterface dialog, int whichButton) {
	          	  		        				killProcess();
	          	  		        			}
	          	  		        		}).create();
	          	  		        	break;
	      	  					default:;
	      	  					}
	      	  					
	      	  					if (dialog != null)
	      	  						dialog.show();
	        	          
	      	  				} catch (Exception e) {
	      	  					System.out.println("toast error!!!");
	      	  				}
	      	  			}
	      	  		});
	      	  	}
	      	}).start();
	    	
	    	if (m_nMsgType != DIALOG_CONNECT)
	    		m_bCertiEnd = true; // SKY:120322
//	    	// Toastのインスタンスを生成
//	    	Toast toast = Toast.makeText(/*frmActivity.*/this, m_strMsg, Toast.LENGTH_LONG);
//	    	// 表示位置を設定
//	    	toast.setGravity(Gravity.CENTER, 0, 0);
//	    	// メッセージを表示
//	    	toast.show();
//	    	
//	    	// then kill the process
//			killProcess();//???-0--------------------
	    }
		
		// Message variables
	    private static final int DIALOG_TOAST			= 6000;
	    private static final int DIALOG_OK_KILL_APP 	= 4000;
	    private static final int DIALOG_DOWNLOAD 		= 4001;
	    private static final int DIALOG_CONNECT			= 4002;
	    private static final int DIALOG_CERTIFICATE		= 4003;
	    
		private String m_strMsgTitle;
		private String m_strMsg;
		
		private int m_nMsgType;

	    private void auUnbind() {
	    	// 必ずunbindして終えること
			if ( m_bBind )
			{
		    	mAlmlClient.unbind();
		    	m_bBind = false;
		    	
		    	System.out.println("AU unbind success");
			}
	    }
	    
		public void killProcess() {
			auUnbind();
			
			// kill
			int pid = android.os.Process.myPid();
			android.os.Process.killProcess(pid);
			Runtime r = Runtime.getRuntime();
			r.gc();
			System.gc();
		}

	
	
//	**************************** AU Code END
  /////////////////////////////////////////////////////////////////////////////////////////

	//kjh start
	public static boolean		m_bSBTV		=	false;
	//kjh end    
	
    @Override
    // public void onCreate(Bundle savedInstanceState) {
    // super.onCreate(savedInstanceState);
    
    public void onCreateSetContentView() {

//    	kjh start
//    	if( android.os.Build.MODEL.equals( "SMARTTVBOX" ) )		//test Code
//    		m_bSBTV	=	true;
    	//processCertificate();
    	if( m_bSBTV )
    		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE );
    	else
    		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT );
    	
    	m_handlerDialog =	new Handler(){
            @Override
            public void handleMessage(Message msg) {
            	onCreateDialog( msg.what );
            	super.handleMessage(msg);
            }
        };				
    	//kjh end
    	
        //AU Code	start
    	m_bCertiEnd = false; // SKY:120322
    	m_bCertSuccess = false;
//        AU Code End
        m_MainActivity = this;

        // requestKillProcess();
       
       setContentView(R.layout.main);
       
       //help view
       m_lytHelp = (LinearLayout)findViewById(R.id.lytHelp);
       Button btn;
       btn = (Button)findViewById(R.id.wndhelp_btn_back);		btn.setOnClickListener(this);

       //ListView lst;
       m_viewHelp = (WebView)findViewById(R.id.wndhelp_webview);
       m_viewHelp.loadUrl(m_strOther_InfoUrl);
       m_viewHelp.getSettings().setJavaScriptEnabled(true);
       
       m_txtHelpTitle = (TextView)findViewById(R.id.wndother_title); //LYM: 2012/12/26
       
       m_viewHelp.setVisibility(View.GONE);
       m_lytHelp.setVisibility(LinearLayout.GONE);
       m_nShowHelp = 0;
       m_nSuspendHelp = 0;

        m_textView = (TextView) findViewById(R.id.txtMain);

    }
    

	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
/*		Rect rect = new Rect();
		Window win = m_MainActivity.getWindow();
		win.getDecorView().getWindowVisibleDisplayFrame(rect);*/
		// TODO Auto-generated method stub
		super.onWindowFocusChanged(hasFocus);
		STD.logout("onWindowFocusChanged : " + hasFocus);
		//// SKY:120214:start
		//m_bHasFocus = hasFocus;
		//	
		//myInit(m_bCertiEnd && m_bHasFocus);
		myInit(hasFocus);
		// SKY:end
	}
	
	synchronized private void myInit(boolean hasFocus) {
		if (hasFocus && (m_viewMain == null)) {
	        firstInit();
    
		    m_viewMain = new frmView(this);
		
			FrameLayout frmLyt = (FrameLayout) findViewById(R.id.frmLyt);
			FrameLayout.LayoutParams param;
			param = new FrameLayout.LayoutParams(
					FrameLayout.LayoutParams.FILL_PARENT, CBaseView.SC_HEIGHT);
			frmLyt.addView(m_viewMain, param);
			
			//LYM TEST_start<
//			String state = android.os.Environment.getExternalStorageState();
//			if(!state.equals(android.os.Environment.MEDIA_MOUNTED))  {
//                try {
//                    throw new IOException("SD Card is not mounted.  It is " + state + ".");
//                } catch (IOException e) {
//                    // TODO Auto-generated catch block
//                    e.printStackTrace();
//                }
//            }
//			
//			try {
//				String fPath = "/mnt/sdcard/kaimin.txt";
//			    File filename = new File(fPath);
//			    boolean bExist = filename.exists();
//			    boolean bCreated = filename.createNewFile(); 
//			    String cmd = "logcat -f "+filename.getAbsolutePath();
//			    Runtime.getRuntime().exec(cmd);
//			} catch (IOException e) {
//			    // TODO Auto-generated catch block
//			    e.printStackTrace();
//			}
			//TEST_end>
			
			STD.logout("myInit");
			
//			onPushNotification();
//			onGree();
			processCertificate(); // SKY:120322
//			m_bCertSuccess = true; //LYM_TEST
//			startProgram();
		}
	}
	
	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch( id ) {
			case R.id.wndhelp_btn_back:
				if (m_nShowHelp != 0) {
					showHelp(false, false);
				}
				break;
		}
	}
	
	public void showHelp(boolean bShow, boolean bInfo) {
		
		if( bShow ) {
			if (bInfo) {
				m_viewHelp.loadUrl(m_strOther_InfoUrl);
				m_txtHelpTitle.setText(R.string.wndother_infotitle);
			} else {
				m_viewHelp.loadUrl(m_strOther_LinkUrl);
				m_txtHelpTitle.setText(R.string.wndother_linktitle);
			}
			
			if(m_viewMain != null)
				m_viewMain.suspend();
			m_viewMain.setVisibility(View.GONE);
			m_viewHelp.setVisibility(View.VISIBLE);
			m_lytHelp.setVisibility(LinearLayout.VISIBLE);
			m_nShowHelp = 1;
		}
		else {
			if(m_viewMain != null)
				m_viewMain.resume();
			m_viewMain.setVisibility(View.VISIBLE);
			m_viewHelp.setVisibility(View.GONE);
			m_lytHelp.setVisibility(LinearLayout.GONE);
			m_nShowHelp = 0;
		}
		
		FrameLayout layout = (FrameLayout) findViewById(R.id.frmLyt);
		layout.requestLayout();
	}
	
//	public void showPrivacy()
//	{
//		Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://img.au-market.com/mapi/policy/2927500000019"));
//		startActivity(browserIntent);
//	}

	@Override
	protected void onDestroy() {
		if( m_viewMain != null )
			m_viewMain.Finish();
		m_viewMain = null;
		super.onDestroy();
		
		// SKY:start
		auUnbind();
		// SKY:end

		clearApplicationCache(null);
		System.runFinalizersOnExit(true); 
		System.exit(0) ; 
	}
	private boolean m_bPaused = false;
	@Override
	protected void onPause() {
		if (m_nShowHelp != 0) {
			m_nSuspendHelp = m_nShowHelp;
//			showHelp(false);
		}
		
		super.onPause();
		
		if(m_viewMain != null && m_nShowHelp == 0)
			m_viewMain.suspend();
		m_bPaused = true;
	}
	@Override
	protected void onResume() {
		super.onResume();
		
//		SOManager.sendScaleoutConversion("2731", "kaiminapp://jp.scaleout.kaiminapp", this);
		
		if (m_nSuspendHelp != 0) {
//    		showHelp(true);
    		m_nSuspendHelp = 0;
    	}
		
		if(m_bPaused) {
			if(m_viewMain != null && m_nShowHelp == 0)
				m_viewMain.resume();
			m_bPaused = false;
		}
	}

	// override keyproc functions.
	
	// SKY:121128:start
	@Override
	protected void onUserLeaveHint() {
		// TODO Auto-generated method stub
		super.onUserLeaveHint();
		
		Globals.m_bHomekeyPressed = true;
	}
	// SKY:end

	//kjh start
	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if( m_viewMain!= null )
			m_viewMain.PostMessage( CWnd.WM_KEY_UP, event.getKeyCode(), 0 );
		return super.onKeyUp(keyCode, event);
	}
	//kjh end
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		switch( keyCode ) {
		case KeyEvent.KEYCODE_MENU:
			if( m_viewMain!= null )
				m_viewMain.PostMessage( CWnd.WM_KEY_DOWN, CWnd.KEY_MENU, 0 );
			else
				return super.onKeyDown(keyCode, event);
			break;
		case KeyEvent.KEYCODE_BACK:
			if (m_nShowHelp != 0) {
				showHelp(false, true);
			} else if( m_viewMain != null )
				m_viewMain.PostMessage( CWnd.WM_KEY_DOWN, CWnd.KEY_BACK, 0 );
			else
				return super.onKeyDown(keyCode, event);

			break;
		case KeyEvent.KEYCODE_VOLUME_DOWN:
			mediaVolumeDown();
			break;
		case KeyEvent.KEYCODE_VOLUME_UP:
			mediaVolumeUp();
			break;
		//kjh start
		case KeyEvent.KEYCODE_DPAD_DOWN:
			if( m_viewMain != null )
				m_viewMain.PostMessage( CWnd.WM_KEY_DOWN, CWnd.KEY_DPAD_DOWN, 0 );
			break;
		case KeyEvent.KEYCODE_DPAD_LEFT:
			if( m_viewMain != null )
				m_viewMain.PostMessage( CWnd.WM_KEY_DOWN, CWnd.KEY_DPAD_LEFT, 0 );
			break;
		case KeyEvent.KEYCODE_DPAD_RIGHT:
			if( m_viewMain != null )
				m_viewMain.PostMessage( CWnd.WM_KEY_DOWN, CWnd.KEY_DPAD_RIGHT, 0 );
			break;
		case KeyEvent.KEYCODE_DPAD_UP:
			if( m_viewMain != null )
				m_viewMain.PostMessage( CWnd.WM_KEY_DOWN, CWnd.KEY_DPAD_UP, 0 );
			break;
		case KeyEvent.KEYCODE_DPAD_CENTER:
		case KeyEvent.KEYCODE_SPACE:
//			m_view.PostMessage( CWnd.WM_KEY_DOWN, event.getKeyCode() , 0 );
			if( m_viewMain != null )
				m_viewMain.PostMessage( CWnd.WM_KEY_DOWN, CWnd.KEY_DPAD_CENTER, 0 );
			return false;
		//kjh end
		default:
			return super.onKeyDown(keyCode, event);
		}
		return true;
	}



	private void firstInit() {
/*		Display d = ((WindowManager) getSystemService(Activity.WINDOW_SERVICE)).getDefaultDisplay(); 
		int width = d.getWidth();
		int height = d.getHeight();*/

		Rect rect = new Rect();
		Window win = m_MainActivity.getWindow();
		win.getDecorView().getWindowVisibleDisplayFrame(rect);
		int width = rect.width();
		int height = rect.height();

		STD.logout("width=" + width + ", height=" + height);
		Globals.Initialize(this);
		
		//kjh start
//		CBaseView.setResSize(handlerTextView, m_textView.getPaint(), width, height);
		if( m_bSBTV ){
			CBaseView.setResSize(handlerTextView, m_textView.getPaint(), 1280, 720);
		}else{
			CBaseView.setResSize(handlerTextView, m_textView.getPaint(), width, height);
		}
		init3d();
	}
	
    private void mediaVolumeDown(){
    	AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
    	am.adjustStreamVolume(
    			AudioManager.STREAM_MUSIC, 
    			AudioManager.ADJUST_LOWER, 
    			AudioManager.FLAG_SHOW_UI);
    }
    private void mediaVolumeUp(){
    	AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
    	am.adjustStreamVolume(
    			AudioManager.STREAM_MUSIC, 
    			AudioManager.ADJUST_RAISE, 
    			AudioManager.FLAG_SHOW_UI);
    }


    private int prevState = 0;
    public void requestKillProcess() {
    	int sdkVersion = Integer.parseInt(android.os.Build.VERSION.SDK);
	   	if (false && sdkVersion < 8) {
		    ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
		    am.restartPackage(getPackageName());
	    } else {
	    	new Thread(new Runnable() {
	    		@Override
	    		public void run() {
	    			ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
	    			String name = getApplicationInfo().processName;
	    			while (true) {
	    				java.util.List<RunningAppProcessInfo> list = am
	    				.getRunningAppProcesses();
	    				for (RunningAppProcessInfo i : list) {
	    					if (i.processName.equals(name) == true) {
	    						if( prevState != i.importance ) {
	    							STD.logout("process '" + name + "',s state is " + i.importance);
	    							prevState = i.importance;
	    						}
	    						if (i.importance >= RunningAppProcessInfo.IMPORTANCE_BACKGROUND) {
	    							clearApplicationCache(null);
	    							// kill process
	    							// am.killBackgroundProcesses(getPackageName());
	    							am.restartPackage(getPackageName());
	    						}
	    						break;
	    					}
    						Thread.yield();
	    				}
	    				STD.sleep(30);
	    			}
	    		}
	    	}, "Process Killer").start();
	    }
    }
	private void clearApplicationCache(java.io.File dir){
        if(dir==null)
            dir = getCacheDir();
        else;
        if(dir==null)
            return;
        else;
        java.io.File[] children = dir.listFiles();
        try{
            for(int i=0;i<children.length;i++)
                if(children[i].isDirectory())
                    clearApplicationCache(children[i]);
                else children[i].delete();
        }
        catch(Exception e){}
    }

	private final String[] BGM_TYPE_NAME = {"ＢＧＭ：タイプＡ", "ＢＧＭ：タイプＢ", "ＢＧＭ：タイプＣ", "ＢＧＭ：OFF"};
	private final String[] TIMER_TYPE_NAME = {
			"終了タイマー：OFF", 
			"終了タイマー：05分00秒", 
			"終了タイマー：10分00秒", 
			"終了タイマー：15分00秒", 
			"終了タイマー：30分00秒", 
			"終了タイマー：45分00秒", 
			"終了タイマー：60分00秒", 
			"終了タイマー：90分00秒", 
			};
	private final String[] SCREENOFF_TYPE_NAME = {
			"自動消灯無効：OFF", "自動消灯無効：ON"
	};
	private final String[] MSPEED_TYPE_NAME = {
			"メッセージ速度：はやい", "メッセージ速度：ふつう", "メッセージ速度：ゆっくり"
	};
    private String[] OPTION1_ITEMS = {"終了タイマー", "自動消灯無効：OFF", "ＢＧＭ：タイプＡ", "タイトルへ"};
    private String[] OPTION2_ITEMS = {"終了タイマー", "自動消灯無効：OFF", "サウンド：ON", "メッセージ速度：ふつう", "タイトルへ"};
    private String[] OPTION3_ITEMS = {"キャンペーン情報", "おすすめアプリ"/*, "通知設定：ON"*/};
    private String[] OPTION_ITEMS_SBTV = {"ＢＧＭ：タイプＡ", "タイトルへ"};//by Kwang 20121126

    //kjh start
    
    //kjh end
    
    @Override
	protected Dialog onCreateDialog(final int id) {
		AlertDialog dlg = null;
        switch (id) {
        case 100: // SKY:120615
        case 1:
        {
        	final String[] books = {"阿部一族", "学問のすすめ", "風の又三郎", "人間失格"};
        	final String[] booksLaw = {"憲法", "民法", "商法", "刑法", "民事訴訟法", "刑事訴訟法"};// SKY:120615

/*        	dlg = new AlertDialog.Builder(kaimin.this)
	            .setTitle("興味の無いタイトルを\r\n選んでください。")
	            .setItems(items, new DialogInterface.OnClickListener() {
	                public void onClick(DialogInterface dialog, int which) {
	
	                	Globals.m_nTextFileID = which;
	                }
	            })
	            .create();//*/

        	// SKY:120615:start
        	
        	Globals.m_nTextFileID = -1;			//kjh
        	
        	String strTitle = null;
        	ArrayAdapter<String> adapter = null;
        	if (id == 1) {
        		adapter = new ArrayAdapter<String>(this, R.layout.listview_item_layout_01, books);
        		strTitle = "興味の無いタイトルを\n選んでください。";
        	} else if (id == 100) {
        		adapter = new ArrayAdapter<String>(this, R.layout.listview_item_layout_01, booksLaw);
        		strTitle = "学びたくない法を\n選んでください。";
        	}
        	// SKY:end
        	
        	dlg = new AlertDialog.Builder(kaimin.this)
	            .setTitle(strTitle)
	            .setAdapter(adapter, new DialogInterface.OnClickListener() {
	                public void onClick(DialogInterface dialog, int which) {

                		Globals.m_nTextFileID = which;
	                }
	            })
                .setNegativeButton("閉じる", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                    	
                    	return;
                    }
                })
	            .create();//*/

        	break;
        }
        case 2:
        {
        	//kjh start
//         	ListView lvPrepare = m_dlg2.getListView();
//        	ArrayAdapter<String> adapterPrepare = (ArrayAdapter<String>) lvPrepare.getAdapter();
        	Globals.m_bShowYesNo = false;
        	Globals.m_bClickClose = false;
        	Globals.m_bOpenMenu = true;
        	if (Globals.GetTimerType() > 0) {
        		Globals.m_nTimerTick -= (System.currentTimeMillis() - Globals.suicideStartTick + 999) / 1000;
        	}
        	cancelAlarm();
        	OPTION1_ITEMS[0] = getEndTimerString();
        	if(Globals.m_bBGMDisable)	OPTION1_ITEMS[2] = BGM_TYPE_NAME[BGM_TYPE_NAME.length - 1];
        	else						OPTION1_ITEMS[2] = BGM_TYPE_NAME[Globals.GetBGMType()];
        	
        	if(Globals.GetScreenOffType() == 0) {
        		OPTION1_ITEMS[1] = SCREENOFF_TYPE_NAME[0];
        	}
        	else {
        		OPTION1_ITEMS[1] = SCREENOFF_TYPE_NAME[1];
        	}
        	if (Globals.m_bSoundTheatre) {
        		OPTION1_ITEMS[2] = "サウンド：ON";
        	}
//        	adapterPrepare.notifyDataSetChanged();
        	//kjh end
        	
        	ArrayAdapter<String> adapter;
        	if (!m_bSBTV) { //by Kwang 20121126
        		adapter = new ArrayAdapter<String>(this,
        				R.layout.listview_item_layout_01, OPTION1_ITEMS);
        	}
        	else { //by Kwang 20121126
        		OPTION_ITEMS_SBTV[0] = OPTION1_ITEMS[2];
        		adapter = new ArrayAdapter<String>(this,
        				R.layout.listview_item_layout_01, OPTION_ITEMS_SBTV);
        	}
        	dlg = new AlertDialog.Builder(kaimin.this)
	            .setTitle("メニュー")
	            .setAdapter(adapter, null)
                .setNegativeButton("閉じる", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                    	Globals.m_bClickClose = true;
                    	return;
                    }
                })
	            .create();

        	m_dlg2 = dlg;
        	ListView lv = dlg.getListView();
        	lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1,
						int arg2, long arg3) {
		        	ListView lv = m_dlg2.getListView();
		        	ArrayAdapter<String> adapter = (ArrayAdapter<String>) lv.getAdapter();
		        	if (m_bSBTV) //by Kwang 20121126
		        		arg2 += 2;
					switch(arg2) {
					case 0:
					{
						int nTimerType = getNextTimerType();
						Globals.SetTimerType(nTimerType);
						OPTION1_ITEMS[0] = TIMER_TYPE_NAME[nTimerType];
						adapter.notifyDataSetChanged();
						break;
					}
					case 1:
						int nType = Globals.GetScreenOffType();
						if (nType == 0) {
							Globals.SetScreenOffType(1);
							OPTION1_ITEMS[1] = SCREENOFF_TYPE_NAME[1];
						}
						else {
							Globals.SetScreenOffType(0);
							OPTION1_ITEMS[1] = SCREENOFF_TYPE_NAME[0];
						}
						adapter.notifyDataSetChanged();
						break;
					case 2:
						if(!Globals.m_bBGMDisable) {
							int nBGMType = Globals.GetBGMType();
							if(nBGMType < BGM_TYPE_NAME.length - 1) nBGMType ++;
							else									nBGMType = 0;
							Globals.SetBGMType(nBGMType);
							OPTION1_ITEMS[2] = BGM_TYPE_NAME[nBGMType];
							OPTION_ITEMS_SBTV[0] = OPTION1_ITEMS[2];//by Kwang 20121126
				        	adapter.notifyDataSetChanged();
				        	
				        	if(nBGMType != 0)
				        		Globals.stopBGM();
				        	if(nBGMType != BGM_TYPE_NAME.length - 1)
				        		Globals.playBGM(nBGMType);
						}
						break;
					case 3:
			        	Globals.m_bShowYesNo = true;
						m_dlg2.dismiss();
						break;
					}
				}
        	      });
        	break;
        }
        case 3:
        {
        	Globals.m_bSelYes = false;				//kjh
        	Globals.m_bOpenMenu = true;

            dlg = new AlertDialog.Builder(kaimin.this)
            	.setTitle("らくらく睡眠アプリ")
                .setMessage("タイトル画面へ戻りますか？")
            	.setPositiveButton("はい", new DialogInterface.OnClickListener() {
            		public void onClick(DialogInterface dialog, int whichButton) {
                    	Globals.m_bSelYes = true;
            		}
            	})
            	.setNegativeButton("いいえ", new DialogInterface.OnClickListener() {
            		public void onClick(DialogInterface dialog, int whichButton) {
                    	Globals.m_bSelYes = false;
                    	return;
            		}
            	})
            	.create();
        	break;
        }
        case 4:
        {
        	Globals.m_bSelYes = false;				//kjh
        	
            dlg = new AlertDialog.Builder(kaimin.this)
        	.setTitle("らくらく睡眠アプリ")
            .setMessage("ゲームオーバー")
        	.setPositiveButton("もう一度", new DialogInterface.OnClickListener() {
        		public void onClick(DialogInterface dialog, int whichButton) {
                	Globals.m_bSelYes = false;
        		}
        	})
        	.setNegativeButton("タイトルへ", new DialogInterface.OnClickListener() {
        		public void onClick(DialogInterface dialog, int whichButton) {
                	Globals.m_bSelYes = true;
        		}
        	})
        	.create();
        	break;
        }
        case 5:
        {
        	//kjh start
//         	ListView lvPrepare = m_dlg2.getListView();
//        	ArrayAdapter<String> adapterPrepare = (ArrayAdapter<String>) lvPrepare.getAdapter();
        	Globals.m_bShowYesNo = false;
        	Globals.m_bClickClose = false;
        	Globals.m_bOpenMenu = true;
        	if (Globals.GetTimerType() > 0) {
        		Globals.m_nTimerTick -= (System.currentTimeMillis() - Globals.suicideStartTick + 999) / 1000;
        	}
        	cancelAlarm();
        	OPTION2_ITEMS[0] = getEndTimerString();
        	
        	if(Globals.GetScreenOffType() == 0) {
        		OPTION2_ITEMS[1] = SCREENOFF_TYPE_NAME[0];
        	} else {
        		OPTION2_ITEMS[1] = SCREENOFF_TYPE_NAME[1];
        	}
        	
        	if (Globals.m_bSoundEnable) OPTION2_ITEMS[2] = "サウンド：ON";
        	else						 OPTION2_ITEMS[2] = "サウンド：OFF";

        	OPTION2_ITEMS[3] = MSPEED_TYPE_NAME[Globals.GetMSpeedType()];
        	
//        	adapterPrepare.notifyDataSetChanged();
        	//kjh end
        	
        	ArrayAdapter<String> adapter;
        	if (!m_bSBTV) { //by Kwang 20121126
        		adapter = new ArrayAdapter<String>(this,
        				R.layout.listview_item_layout_01, OPTION2_ITEMS);
        	}
        	else { //by Kwang 20121126
        		OPTION_ITEMS_SBTV[0] = OPTION2_ITEMS[2];
        		adapter = new ArrayAdapter<String>(this,
        				R.layout.listview_item_layout_01, OPTION_ITEMS_SBTV);
        	}
        	dlg = new AlertDialog.Builder(kaimin.this)
	            .setTitle("メニュー")
	            .setAdapter(adapter, null)
                .setNegativeButton("閉じる", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                    	Globals.m_bClickClose = true;
                    	return;
                    }
                })
	            .create();

        	m_dlg2 = dlg;
        	ListView lv = dlg.getListView();
        	lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1,
						int arg2, long arg3) {
					int nType;
		        	ListView lv = m_dlg2.getListView();
		        	ArrayAdapter<String> adapter = (ArrayAdapter<String>) lv.getAdapter();
		        	if (m_bSBTV) //by Kwang 20121126
		        		arg2 += 2;
					switch(arg2) {
					case 0:
					{
						int nTimerType = getNextTimerType();
						Globals.SetTimerType(nTimerType);
						OPTION2_ITEMS[0] = TIMER_TYPE_NAME[nTimerType];
						adapter.notifyDataSetChanged();
						break;
					}
					case 1:
						nType = Globals.GetScreenOffType();
						if (nType == 0) {
							Globals.SetScreenOffType(1);
							OPTION2_ITEMS[1] = SCREENOFF_TYPE_NAME[1];
						}
						else {
							Globals.SetScreenOffType(0);
							OPTION2_ITEMS[1] = SCREENOFF_TYPE_NAME[0];
						}
						adapter.notifyDataSetChanged();
						break;
					case 2:
						if(Globals.m_bSoundEnable) {
							Globals.m_bSoundEnable = false;
							OPTION2_ITEMS[2] = "サウンド：OFF";
							Globals.stopBGM();
						} else {
							Globals.m_bSoundEnable = true;
							OPTION2_ITEMS[2] = "サウンド：ON";
							int nBGMType = Globals.GetBGMType();
							Globals.playBGM(nBGMType);
						}
						adapter.notifyDataSetChanged();
						break;
					case 3:
						nType = Globals.GetMSpeedType();
						nType = (nType + 1) % 3;
						Globals.SetMSpeedType(nType);
						OPTION2_ITEMS[3] = MSPEED_TYPE_NAME[nType];
						adapter.notifyDataSetChanged();
						break;
					case 4:
			        	Globals.m_bShowYesNo = true;
						m_dlg2.dismiss();
						break;
					}
				}
        	      });
        	break;
        }
        case 6:
        {
//        	dlg = new AlertDialog.Builder(kaimin.this)
//        	.setTitle("プッシュ通知確認")
//            .setMessage("お得な情報を通知してよろしいですか？\n※設定はタイトル画面の「キャンペーン情報」→「通知設定」から変更できます。")
//        	.setPositiveButton("はい", new DialogInterface.OnClickListener() {
//        		public void onClick(DialogInterface dialog, int whichButton) {
//        			changePushStatus(true);
//        		}
//        	})
//        	.setNegativeButton("いいえ", new DialogInterface.OnClickListener() {
//        		public void onClick(DialogInterface dialog, int whichButton) {
//        			changePushStatus(false);
//                	return;
//        		}
//        	})
//        	.create();

        	break;
        }
        case 7:
        {
        	//kjh start
//         	ListView lvPrepare = m_dlg2.getListView();
//        	ArrayAdapter<String> adapterPrepare = (ArrayAdapter<String>) lvPrepare.getAdapter();
        	Globals.m_bShowYesNo = false;
        	Globals.m_bClickClose = false;
        	Globals.m_bOpenMenu = true;
        	if (Globals.GetTimerType() > 0) {
        		Globals.m_nTimerTick -= (System.currentTimeMillis() - Globals.suicideStartTick + 999) / 1000;
        	}
        	cancelAlarm();
       	
//        	if (getPushStatus()) OPTION3_ITEMS[2] = "通知設定：ON";
//        	else				 OPTION3_ITEMS[2] = "通知設定：OFF";

        	ArrayAdapter<String> adapter;
        	if (!m_bSBTV) { //by Kwang 20121126
        		adapter = new ArrayAdapter<String>(this,
        				R.layout.listview_item_layout_01, OPTION3_ITEMS);
        	}
        	else { //by Kwang 20121126
        		OPTION_ITEMS_SBTV[0] = OPTION2_ITEMS[2];
        		adapter = new ArrayAdapter<String>(this,
        				R.layout.listview_item_layout_01, OPTION_ITEMS_SBTV);
        	}
        	dlg = new AlertDialog.Builder(kaimin.this)
	            .setTitle("キャンペーン情報メニュー")
	            .setAdapter(adapter, null)
                .setNegativeButton("閉じる", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                    	Globals.m_bClickClose = true;
                    	return;
                    }
                })
	            .create();

        	m_dlg2 = dlg;
        	ListView lv = dlg.getListView();
        	lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1,
						int arg2, long arg3) {
					int nType;
		        	ListView lv = m_dlg2.getListView();
		        	ArrayAdapter<String> adapter = (ArrayAdapter<String>) lv.getAdapter();
		        	if (m_bSBTV) //by Kwang 20121126
		        		arg2 += 2;
					switch(arg2) {
					case 0:
						m_dlg2.dismiss();
						showHelp(true, true);
						break;
					case 1:
						m_dlg2.dismiss();
						showHelp(true, false);
						break;
//					case 2:
//						if (getPushStatus()) {
//							OPTION3_ITEMS[2] = "通知設定：OFF";
//							changePushStatus(false);
//						} else {
//							OPTION3_ITEMS[2] = "通知設定：ON";
//							changePushStatus(true);
//						}
//						adapter.notifyDataSetChanged();
//						break;
					}
				}
        	      });
        	break;
        }
        case 101:
        {
        	final String[] sounds = {"森林", "虫の音", "夕暮れの小川", "カエル", 
        			"雨", "荒れる水面", "波", "地鳴り", "メトロノーム"};

/*        	dlg = new AlertDialog.Builder(kaimin.this)
	            .setTitle("興味の無いタイトルを\r\n選んでください。")
	            .setItems(items, new DialogInterface.OnClickListener() {
	                public void onClick(DialogInterface dialog, int which) {
	
	                	Globals.m_nTextFileID = which;
	                }
	            })
	            .create();//*/

        	// SKY:120615:start
        	
        	Globals.m_nTextFileID = -1;			//kjh
        	
        	String strTitle = null;
        	ArrayAdapter<String> adapter = null;
    		adapter = new ArrayAdapter<String>(this, R.layout.listview_item_layout_01, sounds);
    		strTitle = "聴きたいサウンドを選んでください";
        	// SKY:end
        	
        	dlg = new AlertDialog.Builder(kaimin.this)
	            .setTitle(strTitle)
	            .setAdapter(adapter, new DialogInterface.OnClickListener() {
	                public void onClick(DialogInterface dialog, int which) {

                		Globals.m_nTextFileID = which;
	                }
	            })
                .setNegativeButton("閉じる", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                    	
                    	return;
                    }
                })
	            .create();//*/

        	break;
        }
        }
        if(dlg != null) {
	    	dlg.setOnDismissListener(new DialogInterface.OnDismissListener() {
				@Override
				public void onDismiss(DialogInterface dialog) {
					if(m_viewMain != null) {
						if (id == 2 || id == 5) {
	                    	Globals.m_bClickClose = true;
	                    	Globals.m_bOpenMenu = false;
						}
						else if (id == 3) {
				        	Globals.m_bOpenMenu = false;
						}
						m_viewMain.getWndMgr().GetCurWnd().MessageBoxClosed(id);
					}
				}
	    	});
        }
        
        
        dlg.show();				//kjh
        
		return dlg;
	}
    
    String getEndTimerString() {
    	String s = TIMER_TYPE_NAME[Globals.GetTimerType()]; 
    	if (Globals.GetTimerType() == 0 || Globals.m_nTimerTick < 0)
    		return s;
    	
    	int nMin = Globals.m_nTimerTick / 60;
    	int nSeconds = Globals.m_nTimerTick % 60;
    	
   		s = String.format("終了タイマー：%02d分%02d秒", nMin, nSeconds);
    	
    	return s;
    }
    
    int getNextTimerType() {
		int nTimerType = Globals.GetTimerType();
		if (nTimerType == 0)
			return nTimerType+1;
		
		int i;
		for (i = 1; i < TIMER_TYPE_NAME.length; i++) {
			int value = Globals.GetTimerValue(i);
			if (value > Globals.m_nTimerTick)
				break;
		}
		if (i < TIMER_TYPE_NAME.length)
			return i;
		else
			return 0;
    }

	@Override
	protected void onPrepareDialog(int id, Dialog dialog) {
		switch(id) {
		case 1:
		case 100: // SKY:120615
        	Globals.m_nTextFileID = -1;
			break;
		case 2:
        	ListView lv = m_dlg2.getListView();
        	ArrayAdapter<String> adapter = (ArrayAdapter<String>) lv.getAdapter();
        	Globals.m_bShowYesNo = false;
    		if(Globals.m_bBGMDisable)	OPTION1_ITEMS[2] = BGM_TYPE_NAME[BGM_TYPE_NAME.length - 1];
    		else						OPTION1_ITEMS[2] = BGM_TYPE_NAME[Globals.GetBGMType()];
    		OPTION_ITEMS_SBTV[0] = OPTION1_ITEMS[2];//by Kwang 20121126
        	adapter.notifyDataSetChanged();
			break;
		case 3:
        	Globals.m_bSelYes = false;
			break;
		case 4:
        	Globals.m_bSelYes = false;
			break;
		}
		super.onPrepareDialog(id, dialog);
	}
	///*
	Handler handlerTextView = new Handler() {

		@Override
		public void handleMessage(Message msg) {
	        switch(msg.what) {
	        case CBaseView.TEXTVIEW_SETPADDING:
	        {
	        	int[] padding = (int[])msg.obj;
	        	m_textView.setPadding(padding[0], padding[1], padding[2], padding[3]);
	        	break;
	        }
	        case CBaseView.TEXTVIEW_SETTEXT:
	        	m_textView.setText(m_viewMain.getTextViewString());
	        	break;
	        case CBaseView.TEXTVIEW_GETINFO:
	        	int nLineCount = m_textView.getLineCount();
	        	if(nLineCount == 0) {
	        		m_viewMain.setTextViewInfo(0, 0);
	        	}
	        	else {
		        	Rect bounds = new Rect();
		        	m_textView.getLineBounds(nLineCount - 1, bounds);
	        		m_viewMain.setTextViewInfo(nLineCount, bounds.bottom);
	        	}
	        	break;
	        case CBaseView.TEXTVIEW_SETSCROLL:
	        {
	        	int[] pos = (int[])msg.obj;
	        	m_textView.scrollTo(pos[0], pos[1]);
	        	break;
	        }
	        case CBaseView.TEXTVIEW_CLEAR:
	        {
	        	m_textView.setText("");
	        	break;
	        }
	        case CBaseView.DLG_SHOW:
	        {
	        	int[] pos = (int[])msg.obj;
	        	showDialog(pos[0]);
	        	break;
	        }
	        }
		}
	};
	
	//kjh start
	static public final int MSG_SHOW_MENU_DIALOG	=	400;
    static public final Handler m_handlerMenu = new Handler(){ 
	    @Override 
	    public void handleMessage(Message msg) { 
	    	switch ( msg.what ) {
			case MSG_SHOW_MENU_DIALOG:
//				OnOption();
				break;
			default:
				break;
			}
	    	
	    }
    };	
	//kjh end
	
	/// implementing 3d relations.
	private Object3dContainer m_modelCar;
	private void init3d() {
		WndDrive.set3dHandler(handler3d);
	}
    @Override 
	protected void glSurfaceViewConfig()
    {
		// !important
        _glSurfaceView.setEGLConfigChooser(8,8,8,8, 16, 0);
        _glSurfaceView.getHolder().setFormat(PixelFormat.TRANSLUCENT);
    }
	@Override
	public void initScene() {
		scene.backgroundColor().setAll(0x00000000);
		
		if( m_wndDrive != null ) {
			m_wndDrive.setScene(scene);
			//m_wndDrive.PostMessage(CWnd.WM_COMMAND, WndDrive.CMD_START_3D);
		}
	}
	@Override
	public void updateScene() {
		if( m_wndDrive != null )
			m_wndDrive.updateDrive();
	}
	private Object3dContainer loadModel( String strPath ) {
		IParser parser = Parser.createParser(Parser.Type.MAX_3DS,
				getResources(), "com.dlten.kaimin:raw/" + strPath, false);
		parser.parse();

		Object3dContainer model = parser.getParsedObject();
		model.scale().setAll(1.0f, 1.0f, 1.0f);

		return model;
	}
	
	private boolean m_b3dAdded = false;
	private WndDrive m_wndDrive = null;
	Handler handler3d = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch( msg.what ) {
			case WndDrive.WM_CREATED_3D:
				break;
			case WndDrive.WM_START_3D:
			{
				m_wndDrive = (WndDrive) msg.obj;
				FrameLayout frmLyt = (FrameLayout) findViewById(R.id.frmLyt);
				if( !m_b3dAdded ) {
					m_b3dAdded = true;
//					kjh start
					FrameLayout.LayoutParams param;
					if( kaimin.m_bSBTV ){
//						param = new FrameLayout.LayoutParams(
//								480, 676 );
//						param.leftMargin	=	400;
						param = new FrameLayout.LayoutParams(
								1080, 676 );
						param.leftMargin	=	100;
						
					}else{
						param	= new FrameLayout.LayoutParams(
								FrameLayout.LayoutParams.FILL_PARENT, msg.arg1+msg.arg2);
					}


//					kjh end
					// param.topMargin = msg.arg2;
					frmLyt.addView(_glSurfaceView, 0, param);
					_glSurfaceView.forceLayout();
				}
				else {
					_glSurfaceView.setVisibility(View.VISIBLE);
					scene.sceneController().initScene();
					// m_wndDrive.setScene(scene);
				}
				m_viewMain.setZOrderOnTop(false);
				_glSurfaceView.setZOrderOnTop(true);
				frmLyt.invalidate();
				break;
			}
			case WndDrive.WM_END_3D:
			{
				m_wndDrive = null;
				FrameLayout frmLyt = (FrameLayout) findViewById(R.id.frmLyt);
				_glSurfaceView.setVisibility(View.INVISIBLE);
				// frmLyt.removeView(_glSurfaceView);
				break;
			}
			case WndDrive.WM_SHOW_DLG:
				showDialog(msg.arg1);
				break;
			}
		}
	};
	///////////////////////////////*/
	
    /////////////////////////////////////////////////////////////////////////////////////////
	
	//kjh start
	
    static	public			Handler		m_handlerDialog;
    public void showAlertDialog( int nShow ){
    	
    	Message	msg	=	new Message();
    	msg.what	=	nShow;
    	m_handlerDialog.sendMessage( msg );
    }
	//kjh end


    PendingIntent currentAlarmReceiver;
    public void setSuicideAlarm(int nSeconds) {
        // When the alarm goes off, we want to broadcast an Intent to our
        // BroadcastReceiver.  Here we make an Intent with an explicit class
        // name to have our own receiver (which has been published in
        // AndroidManifest.xml) instantiated and called, and then create an
        // IntentSender to have the intent executed as a broadcast.
        Intent intent = new Intent(kaimin.this, OneShotAlarm.class);
        currentAlarmReceiver = PendingIntent.getBroadcast(kaimin.this,
                0, intent, 0);

        // We want the alarm to go off 30 seconds from now.
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.add(Calendar.SECOND, nSeconds);
        
        Globals.suicideStartTick = System.currentTimeMillis();

        // Schedule the alarm!
        AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
        am.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), currentAlarmReceiver);
        
//		  The below code was sent by SSJ. Thanks SSJ for sending me this code.
//        Intent intent = new Intent(this, BarReceiver.class);
//        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, 0);
//        AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
//        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, 
//                System.currentTimeMillis(), 30*1000, pendingIntent);
        
    }
    
    public void cancelAlarm() {
        AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
        if (currentAlarmReceiver != null) {
        	am.cancel(currentAlarmReceiver);
        	currentAlarmReceiver = null;
        	Globals.suicideStartTick = 0;
        }
    }
    
    public void setScreenOffType(int nType) {
    	if (nType == 0) {
    		runOnUiThread(new Runnable() {
    			public void run() {
    				getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    			}
    		});
    	}
    	else {
    		runOnUiThread(new Runnable() {
    			public void run() {
    				getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    			}
    		});
    	}
    }
    
    public static class BarReceiver extends BroadcastReceiver {
    	BarReceiver() {
    		
    	}
    	
    	static public Activity parent;
    	
        private static PowerManager.WakeLock wl;
        
        @Override
        public void onReceive(Context context, Intent arg1) {
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "BarReceiver");
            wl.acquire();
            
            Intent intent = new Intent(context, BazService.class);
            context.startService(intent);
//        	mainActivity.finish();
        }
        
        public static void releaseWakeLock() {
            if (wl != null) {
                wl.release();
            }
        }
    }
        
    public class BazService extends Service {
    	@Override
    	public void onCreate() {
    		new Thread(new BazProcess())
    		.start();
    	}

		@Override
		public IBinder onBind(Intent arg0) {
			// TODO Auto-generated method stub
			return null;
		}
		
    	private class BazProcess implements Runnable {

    		@Override
    		public void run() {
    			// ここでバックグラウンド処理を実行。
    			BarReceiver.releaseWakeLock();  // 最後に端末がスリープ状態に戻れるようにする。
    		}

    	}
    }

}

