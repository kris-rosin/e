package com.dlten.lib.graphics;

import android.graphics.Bitmap;

/**
 * <p>Title: CImage class</p>
 *
 * <p>Description: Image split & managing class</p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * @version 1.0
 */
public class CImage extends COrgImage {
    
    public CImage() {
    	super();
    }
/*    public void load( String strAsset ) {
    	super.load(strAsset);
    }
    public void load( int nResID ) {
    	super.load(nResID);
    }
    public void load( Bitmap img ) {
    	setImage( img );
    }*/

    public int getCWidth() {
        return getWidth();
    }
    public int getCHeight() {
        return getHeight();
    }
    
    public Bitmap getBmp() {
    	return getImage();
    }
}
