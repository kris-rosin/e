package com.dlten.kaimin.wnds;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.ImageView;

import min3d.Shared;
import min3d.Utils;
import min3d.core.Object3dContainer;
import min3d.core.Scene;
import min3d.objectPrimitives.Rectangle;
import min3d.parser.IParser;
import min3d.parser.Parser;
import min3d.vos.CameraVo;
import min3d.vos.Color4;
import min3d.vos.Light;
import min3d.vos.LightType;
import min3d.vos.Number3d;
import min3d.vos.TextureVo;

import com.dlten.kaimin.Globals;
import com.dlten.kaimin.frmWndMgr;
import com.dlten.kaimin_auOM.R;
import com.dlten.kaimin.kaimin;
import com.dlten.lib.STD;
import com.dlten.lib.file.CConFile;
import com.dlten.lib.frmWork.CButton;
import com.dlten.lib.frmWork.CWnd;
import com.dlten.lib.graphics.CDCView;
import com.dlten.lib.graphics.CImgObj;

public class WndDrive extends WndTimer {
	
	public static final int
	WM_CREATED_3D = 1,
	WM_START_3D = 2,
	WM_END_3D = 3,
	WM_SHOW_MAINVIEW = 4,
	WM_SHOW_DLG = 5;
    public static final int
	CMD_MENU_ASYNC      = 0,
	CMD_SELECT_CLOSE	= 1,
	CMD_QUIT = 2,
	CMD_START_3D = 3;

	

	private static Handler m_3dHandler = null;
	public static void set3dHandler( Handler handler ) {
		m_3dHandler = handler;
	}

	private kaimin m_activity;
	
	private int m_nStep;
	private	long	m_timeProc;
	private int m_nStepAlpha = 0;

	private static long OPEN_FRAME_COUNT = 20;
	private static long CLOSE_FRAME_COUNT = 20;

	private CImgObj m_imgMenuBg   		= new CImgObj();
	private CImgObj m_imgScoreBg   		= new CImgObj();
	private CImgObj[] m_imgScoreNum   	= new CImgObj[10];
	private CImgObj m_imgWarning 		= new CImgObj();
	private CImgObj m_imgMenuNor   		= new CImgObj();
	private CImgObj m_imgMenuFoc   		= new CImgObj();
	private CImgObj m_imgTimerSky  		= new CImgObj();

	private boolean m_bMustStart; // 3d game must to be started.
	private boolean m_bMustEnd; // 3d game must to be end.
	private boolean m_bPaused; // pause flag
	private boolean m_bStarted; // start flag

	public void OnLoadResource() {
		//setString("Sheet Wnd");
		
		m_activity = (kaimin) (getView().getActivity());

		Globals.playBGM(Globals.m_nBGMType_WndDrive);
		
		createImages();
		{
			Message msg = new Message();
			msg.what = WM_CREATED_3D;
			msg.obj = this;
		}

		super.OnLoadResource();
	}
	public void OnInitWindow() {
		m_nStep = 0;
		m_timeProc = 0;
		m_nStepAlpha = 0;

		Globals.m_bBGMDisable = false;
		Globals.m_bSEDisable = false;
		
		m_bMustStart = false;
		m_bMustEnd = false;
		m_bStarted = false;
		m_bPaused = false;
		
		start3dGame();
	}
	public void OnShowWindow() {
	}
	
	private void start3dGame() {
		m_nStep = 0;
		m_timeProc = 0;
		
		m_bMustStart = true;
		m_bMustEnd = false;
		
		
		Message msg = new Message();
		msg.what = WM_START_3D;
		
		//kjh start
//		msg.arg1 = (int)  CDCView.wnd2sc(901.5f-1);
//		msg.arg2 = (int) (CDCView.SC_HEIGHT-CDCView.wnd2sc(960))/2;
		
		//testCode
		if( kaimin.m_bSBTV ){
			msg.arg1 = (int) CDCView.wnd2sc(901.5f-1);
			msg.arg2 = (int) (CDCView.SC_HEIGHT-CDCView.wnd2sc(640))/2;
			
			msg.arg1	=	676;
			msg.arg2	=	0;
			
		}else{
			msg.arg1 = (int) CDCView.wnd2sc(901.5f-1);
			msg.arg2 = (int) (CDCView.SC_HEIGHT-CDCView.wnd2sc(960))/2;
		}
		
		//kjh end
		msg.obj = this;
		m_3dHandler.sendMessage(msg);
	}
	private void stop3dGame() {
		m_bStarted = false;
		m_bPaused = false;
		m_bMustStart = false;
		m_bMustEnd = false;
		
		// unload3dModels();
		
		Message msg = new Message();
		msg.what = WM_END_3D;
		m_3dHandler.sendMessage(msg);
	}

	private void createImages() {
		
		m_imgMenuBg.load( "COMN/COMN_menu_back.png",kaimin.m_bSBTV );
		m_imgScoreBg.load( "D1/D1_info.png",kaimin.m_bSBTV );
		m_imgWarning.load( "D1/D1_caution.png",kaimin.m_bSBTV );
		m_imgMenuNor.load( "COMN/COMN_btn_menu_1.png",kaimin.m_bSBTV );
		
		if( kaimin.m_bSBTV )
			m_imgMenuFoc.load( "COMN/COMN_btn_menu_2_sbtv.png",kaimin.m_bSBTV );
		else	
			m_imgMenuFoc.load( "COMN/COMN_btn_menu_2.png",kaimin.m_bSBTV );

		for(int i = 0; i < 10; i ++) {
			m_imgScoreNum[i] = new CImgObj("COMN/COMN_num_" + i + ".png", kaimin.m_bSBTV );
		}
		
		m_imgTimerSky.load( "TM/TM_sky.png",kaimin.m_bSBTV );

		if( kaimin.m_bSBTV ){
			
//			m_imgLeftSideBack	=	new CImgObj( "back_side.png", kaimin.m_bSBTV );
//			m_imgLeftSideBack.setSBTVScale( true );
//			m_imgRightSideBack	=	new CImgObj( "back_side.png", kaimin.m_bSBTV );
//			m_imgRightSideBack.setSBTVScale( true );
//			m_imgLeftSideBack.moveTo(-400, 0 );
//			m_imgRightSideBack.moveTo(640, 0 );
			
			m_imgMenuBg.setSBTVScale( true );
			m_imgScoreBg.setSBTVScale( true );
			m_imgWarning.setSBTVScale( true );
			m_imgMenuNor.setSBTVScale( true );
			m_imgMenuFoc.setSBTVScale( true );
			
			for( int i = 0; i < 10; i++ )
				m_imgScoreNum[ i ].setSBTVScale( true );
			
//			m_imgTimerSky.setSBTVScale( true );
			m_imgTimerSky.setScaleX( 1080.f / 640.f );
			m_imgTimerSky.setScaleY( 960.f / 640.f );
			m_imgTimerSky.moveTo( 0,0 );
			
		}
		m_imgMenuBg.moveTo(0, 899);
		m_imgScoreBg.moveTo(10, 906);
		m_imgMenuNor.moveTo(433, 901.5f);
		m_imgWarning.moveTo(10+24, 906+4);
	}
	
	public void createButtons() {
		CButton	btn = null;

		btn = createButton(
				m_imgMenuNor,
				m_imgMenuNor,
				null);
		btn.setPoint(433, 901.5f);
		btn.setAsyncFlag(true);
		btn.setCommand( CMD_MENU_ASYNC );
	}
	
	public void OnPaint() {
		// drawing dimmension is just Globals.RES_WIDTH * Globals.RES_HEIGHT
		getView().clear();

		drawBackGround();
		
		setViewAlpha(m_nStepAlpha);
		
		drawSideBackground();				//kjh
//		int nDist = 6010 - nAlpha * 6000 / 255;
//		m_scene.fogNear(nDist);
		
		m_imgTimerSky.draw();
		
		super.OnPaint();
	}
	
	//kjh start
//	private CImgObj m_imgLeftSideBack   	= new CImgObj();
//	private CImgObj m_imgRightSideBack   	= new CImgObj();
	public void drawSideBackground(){
		
		if( !kaimin.m_bSBTV )
			return;
//		m_imgLeftSideBack.draw();
//		m_imgRightSideBack.draw();
		
	}
	//kjh end
	
	//kjh start
	public void OnKeyUp( int keycode ){
		
		m_nHandling	=	-1;

	}
	//kjh end
	
	public void OnKeyDown( int keycode ) {
		switch (keycode) {
		case KEY_MENU:		OnMenu();						break;
		case KEY_BACK:		OnExit();						break;
		
		//kjh start
		case KEY_DPAD_LEFT:
			onLeftKey();
			break;
		
		case KEY_DPAD_RIGHT:
			onRightKey();
			break;
			
		case KEY_DPAD_CENTER:
			onDPADCenter();
			break;
			//kjh end
		default:			super.OnKeyDown(keycode);		break;
		}
	}

	//kjh start
	public void onLeftKey(){
		m_nHandling	=	0;
	}
	
	public void onRightKey(){
		m_nHandling	=	1;
	}
	
	public void onDPADCenter(){
		OnOption();
	}
	// kjh end
	
	
	public void OnCommand(int nCmd) {
		if(m_nStep != 1 && nCmd != CMD_START_3D)
			return;
    	switch (nCmd) {
    	case CMD_MENU_ASYNC:	OnOption();	break;
    	case CMD_SELECT_CLOSE:	Close();	break;
    	case CMD_QUIT:
    		Quit();
    		break;
    	case CMD_START_3D:
    		load3dModels();
    		initDrive();
    		
    		m_bStarted = true;
    		m_bPaused = false;
    		
    		System.gc();
    		break;
    	}
    }

	public void MessageBoxClosed(int dlgid) {
		switch(dlgid) {
		case 2:
			if(Globals.m_bShowYesNo) {
//		        getView().getActivity().showDialog(3);			//kjh
		        getView().getActivity().showAlertDialog( 3 );	//kjh

			}
			else {
				resume();
			}
			Globals.m_nBGMType_WndDrive = Globals.GetBGMType();
			if (Globals.m_bClickClose) { // if user clicks close button, ...
				OnClickMenuClose();
			}
			break;
		case 3:
			if(Globals.m_bSelYes) {
				PostMessage(WM_COMMAND, CMD_SELECT_CLOSE, 0);
				resume();
			}
			else {
				resume();
			}
			break;
		case 4:
			if(Globals.m_bSelYes) { // go to title
				Quit();
				// PostMessage(WM_COMMAND, CMD_QUIT, 0);
			}
			else { // restart new game.
				start3dGame();
			}
		}
	}

	public void OnOption() {
		pause();
		
		Globals.SetBGMType(Globals.m_nBGMType_WndDrive);
//        getView().getActivity().showDialog(2);			//kjh
        getView().getActivity().showAlertDialog( 2 );	//kjh

		
	}
	
	public void OnExit() {
		Close();
	}
	
	private void Close() {
		m_nStep = 2;
		m_timeProc = STD.GetTickCount();
		RemoveAllButtons();
	}
	private void Quit() {
		Globals.stopBGM();

		DestroyWindow( frmWndMgr.WND_TITLE );
	}

	public void OnMenu() {
	}

	private int GetStepAlpha() {
		if (m_timeProc == 0)
			return 0;

		int	nAlpha = 255;
		long timeElapse = STD.GetTickCount() - m_timeProc;

		if(m_nStep == 0) {
			if(timeElapse >= OPEN_FRAME_COUNT * Globals.MS_PER_FRAME) {
				m_nStep ++;
				createButtons();
				m_timeProc = STD.GetTickCount();
				timeElapse = 0;
			}
			else {
				float	fAlpha = 255.0f;

				fAlpha *= (float)timeElapse;
				fAlpha /= (float)(OPEN_FRAME_COUNT * Globals.MS_PER_FRAME);
				nAlpha = (int)fAlpha;
			}
		}
		if(m_nStep == 2) {
			if(timeElapse >= CLOSE_FRAME_COUNT * Globals.MS_PER_FRAME) {
				m_nStep = 3;
				if( !m_bMustEnd ) { // car is inside of course : user exit.
					Quit();
				}
				else {
					Message msg = new Message();
					msg.what = WM_SHOW_DLG;
					msg.arg1 = 4;
					m_3dHandler.sendMessage(msg);
				}
				stop3dGame();
			}
			else {
				float	fAlpha = 255.0f;

				fAlpha *= (float)timeElapse;
				fAlpha /= (float)(CLOSE_FRAME_COUNT * Globals.MS_PER_FRAME);
				nAlpha = (int)(255.0 - fAlpha);
			}
		}
		if( m_nStep == 3 )
			return 0;

		return nAlpha;
	}

	private void drawBackGround() {
		
		m_imgMenuBg.draw();
		m_imgScoreBg.draw();
		// draw warning icon
		
		if( m_Car!=null && m_Car.out != 1 && m_nCourseOutFrame >= 6 ) {
			m_imgWarning.draw();
		}
		// draw distance.
		String strTemp = STD.getnString(m_nDistance, 6);
		drawIntString(strTemp, 10+351-19*6, 906+13, m_imgScoreNum);
		
		if(m_nStep != 1 ) {
			m_imgMenuNor.draw();
		}
		else {
		}
	}
	
    public static void drawIntString( String str, float nPosX, float nPosY, CImgObj[] imgs ) {
    	if( imgs == null || imgs.length < 10 )
    		return;
    	int i;
    	char ch;
    	int nIndex = 0;
    	int nWidth = 19; // (int) imgs[0].getRect().width;
    	int nGap = nWidth;
    	for( i = 0 ; i < str.length(); i++ ) {
    		ch = str.charAt(i);
    		if ( ch >= '0' && ch <= '9' ) {
    			nIndex = ch - '0';
    			nGap = nWidth;
    		} else if( ch == ':' ) {
    			nIndex = 10;
    			nGap = nWidth;
    		} else if( ch == 'x' ) {
    			nIndex = 10;
    			nGap = nWidth;
    		} else if( ch == '+' ) {
    			nIndex = 11;
    			nGap = nWidth;
    		} else {
    			nIndex = -1;
    			nGap = 0;
    		}

    		if( nIndex != -1 ) {
    			// imgs[nIndex].setAnchor(CWnd.ANCHOR_LEFT | CWnd.ANCHOR_MIDDLE);
    			imgs[nIndex].draw(nPosX, nPosY );
    		}
    		nPosX += nGap;
    	}
    }
	
	private int m_nHandling = -1;
	public void OnTouchDown(int x, int y) {
		pointerPressed(x, y);
	}
	public void OnTouchMove(int x, int y) {
		pointerPressed(x, y);
	}
	public boolean OnTouchUp(int x, int y) {
		pointerReleased(x, y);
		return true;
	}
	private void pointerPressed( float x, float y ) {
		float limit_left = CDCView.RES_WIDTH * 2 / 5;
		float limit_right = CDCView.RES_WIDTH * 3 / 5;
		if( x <= limit_left )
			m_nHandling = 0;
		else if (x >= limit_right)
			m_nHandling = 1;
		else
			m_nHandling = -1;
	}
	private void pointerReleased( float x, float y ) {
		m_nHandling = -1;
	}

	private void pause() {
		m_bPaused = true;
	}

	private void resume() {
		m_bPaused = false;
	}

	public void OnSuspend() {
		if(Globals.m_nBGMType_WndDrive < Globals.m_nBGMIDs.length) {
			Globals.pauseBGM();
		}
		pause();
	}

	public void OnResume() {
		if(Globals.m_nBGMType_WndDrive < Globals.m_nBGMIDs.length) {
			Globals.resumeBGM();
		}
		resume();
	}
	
	
	
	
	
	// SKY:120605:start
	private final static int _DISTANCE_ = 5000;
	// SKY:end
	
	
	
	
	
	// implementation 3d car.
    private int m_nFrameCount = 0;
    private long m_lUpdateTimes = 0;
	private float m_fFPS = 0;
	private long m_lPrevTime = 0;
	// 3d resource relations.
	private Scene m_scene;
	private Object3dContainer m_modelCar;
	private Object3dContainer m_modelSky;
	private Object3dContainer[] m_modelGround = new Object3dContainer[MAP_COUNT];
	private Object3dContainer[][] m_modelRoad = new Object3dContainer[MAP_COUNT][MAP_COUNT];
	private Rectangle m_leftHandle, m_rightHandle;
	private TextureVo m_textureNorm, m_textureFocus;
	private CameraVo m_camera;
	private Light m_light;
	
	
	// driving members.
	private static final int FPOS = _DISTANCE_;	// フィールド配置位置
	private static final int MAP_COUNT = 3;
	private static final int MAP_DATA_LEN = 396;
	private int m_n3dFrame;
	private int m_nCourseOutFrame;
	private int m_nDistance;
	private float m_nCameraAngle;
	private int m_fieldno;		// フィールドNO
	private int m_fieldkind;		// フィールド種類
	private FIELD[] m_Field = new FIELD[MAP_COUNT];	// フィールド
	private CARMODEL m_Car;				// 車
	private byte[] m_byMapData;
	
	
	public void setScene( Scene scene ) {
		m_scene = scene;
		
		if( !m_bMustStart ) {
			load3dModels();
			return;
		}
		
		load3dModels();
		initDrive();
		
		m_bStarted = true;
		m_bPaused = false;
		m_bMustStart = false;

		m_nStep = 0;
		m_timeProc = STD.GetTickCount();
	}
	
	public void load3dModels() {
		int i, j;
		
		// 3d models
		if( m_scene.numChildren() == 0 ) {
			// setting light
			m_light = new Light();
			m_scene.lights().add(m_light);
			m_light.type(LightType.POSITIONAL);

			m_modelCar = loadModel("car");
			m_scene.addChild(m_modelCar);
			
			m_modelSky = loadModel("sky");
			m_scene.addChild(m_modelSky);
			
			for( i = 0 ; i < MAP_COUNT ; i++ ) {
				if( i == 0 )
					m_modelGround[i] = loadModel("ground");
				else
					m_modelGround[i] = m_modelGround[0].clone();
				m_scene.addChild(m_modelGround[i]);
				for( j = 0 ; j < MAP_COUNT ; j++ ) {
					if( i == 0 )
						m_modelRoad[i][j] = loadModel("road_" + (j+1));
					else
						m_modelRoad[i][j] = m_modelRoad[0][j].clone();
					m_scene.addChild(m_modelRoad[i][j]);
				}
			}
			
			// left/right buttons
			Bitmap bmpNorm = Utils.makeBitmapFromResourceId(m_activity, R.drawable.btn_handle_1 );
			Bitmap bmpFocus = Utils.makeBitmapFromResourceId(m_activity, R.drawable.btn_handle_2 );
			Bitmap bmpClock = Utils.makeBitmapFromResourceId(m_activity, R.drawable.clock_icon );
			Bitmap bmpNotify = Utils.makeBitmapFromResourceId(m_activity, R.drawable.notify_end );
			float w = 10.0f;
			float h = w * (float)bmpNorm.getHeight() / (float)bmpNorm.getWidth(); 

			Shared.textureManager().addTextureId(bmpNorm, "normal", false);
			Shared.textureManager().addTextureId(bmpFocus, "focus", false);
			Shared.textureManager().addTextureId(bmpClock, "clock", false);
			Shared.textureManager().addTextureId(bmpNotify, "notify", false);
			bmpNorm.recycle();
			bmpFocus.recycle();
			bmpClock.recycle();
			bmpNotify.recycle();
			
			m_leftHandle = new Rectangle(w, h, 1,1, new Color4());
			m_leftHandle.doubleSidedEnabled(true); // ... so that the back of the plane is visible
			m_leftHandle.normalsEnabled(false);
			m_scene.addChild(m_leftHandle);
			
			m_rightHandle = new Rectangle(w, h, 1,1, new Color4());
			m_rightHandle.doubleSidedEnabled(true); // ... so that the back of the plane is visible
			m_rightHandle.normalsEnabled(false);
			m_scene.addChild(m_rightHandle);
			
			m_camera = m_scene.camera();
			m_camera.frustum.zNear(1.0f);
			m_camera.frustum.zFar(_DISTANCE_);
		}
		else {
			m_light = m_scene.lights().get(0);

			int nCounter = 0;
			m_modelCar = (Object3dContainer) m_scene.getChildAt(nCounter); nCounter++;
			m_modelSky = (Object3dContainer) m_scene.getChildAt(nCounter); nCounter++;
			
			for( i = 0 ; i < MAP_COUNT ; i++ ) {
				m_modelGround[i] = (Object3dContainer) m_scene.getChildAt(nCounter);
				nCounter++;
				for( j = 0 ; j < MAP_COUNT ; j++ ) {
					m_modelRoad[i][j] = (Object3dContainer) m_scene.getChildAt(nCounter);
					nCounter++;
				}
			}
			
			m_leftHandle = (Rectangle) m_scene.getChildAt(nCounter);
			nCounter++;
			m_rightHandle = (Rectangle) m_scene.getChildAt(nCounter);
			nCounter++;

			m_camera = m_scene.camera();
		}

		// change button textures.
		m_textureNorm = new TextureVo("normal");
		m_textureFocus = new TextureVo("focus");
		
		m_leftHandle.textures().addReplace( m_textureNorm );
		m_rightHandle.textures().addReplace( m_textureNorm );
	}
	private void unload3dModels() {
		int i, j;
		m_scene.lights().remove(m_light);

		m_scene.removeChild(m_modelCar);
		m_modelCar.clear();		
		m_scene.removeChild(m_modelSky);
		m_modelSky.clear();
		
		for( i = 0 ; i < MAP_COUNT ; i++ ) {
			m_scene.removeChild(m_modelGround[i]);
			m_modelGround[i].clear();
			for( j = 0 ; j < MAP_COUNT ; j++ ) {
				m_scene.removeChild(m_modelRoad[i][j]);
				m_modelRoad[i][j].clear();
			}
		}
	}
	private Object3dContainer loadModel( String strPath ) {
		IParser parser = Parser.createParser(Parser.Type.MAX_3DS,
//				getView().getActivity().getResources(), "com.dlten.kaimin:raw/" + strPath, false);
				getView().getActivity().getResources(), "com.dlten.kaimin_auOM:raw/" + strPath, false);// SKY:120214
		parser.parse();

		Object3dContainer model = parser.getParsedObject();
		model.scale().setAll(1.0f, 1.0f, 1.0f);

		return model;
	}
	

	public void initDrive() {
	    m_nFrameCount = 0;
	    m_lUpdateTimes = 0;
		m_fFPS = 0;
		m_lPrevTime = System.currentTimeMillis();

		int i;
		// for driving datas
		for( i = 0 ; i < m_Field.length ; i++ )
			m_Field[i] = new FIELD();
		m_Car = new CARMODEL();
		m_byMapData = CConFile.loadBinaryAssets("course.txt");
		
		// ドライブの初期化
		m_fieldkind = 0;		// フィールドの初期化
		m_fieldno = 0;			// 
		FieldZSet();			// フィールドのセット

		// 車の配置
		m_Car.pos_x = 0;
		m_Car.pos_y = 8;
		m_Car.pos_z = 0;		// 車の座標
		m_Car.y_angle = 0;		// 車の角度
		m_nCameraAngle = 0;		// カメラの角度
		m_Car.bend = 0;
		m_Car.out = 1;

		m_nDistance = 0;		// 走行距離の初期化
		m_n3dFrame = 0;
		m_nCourseOutFrame = 0;

		MapCheck(m_Car);
		
		m_nHandling = -1;
	}
	public void updateDrive() {
		if( !m_bStarted )
			return;
		
		if( m_bPaused )
			return;
		
		if (Globals.m_bOpenMenu)
			return;
		
		calcFps();
		m_n3dFrame++;
		
		// マップを回転した際の車の座標位置
		MapRotatePos(m_Car);
		
		// マップ位置の読み込み
		if(m_Car.save_x != m_Car.rot_x || m_Car.save_z != m_Car.rot_z)
			LoadMap(m_Car);
		
		// update Model poses.
		KeyCheck();
		CameraPos();
		
		// light
		m_light.position.setAllFrom(m_camera.position);
		m_light.position.setY(4096);
		{
			m_nStepAlpha = GetStepAlpha();
			long nColor = (m_nStepAlpha & 0xFF);
			nColor = (nColor << 16) | (nColor << 8) | (nColor << 0);
			m_light.ambient.setAll(nColor);
			m_light.diffuse.setAll(nColor);
		}
		
		UpdateModelPoses();
		
		// 車がコースから外れた場合はタイマーをセットする
		if(m_Car.out != 1) {
			m_nCourseOutFrame++;
		}
		else{
			m_nCourseOutFrame = 0;
		}
		
		if( m_nCourseOutFrame >= 550) {//160//6*m_fFPS ) { // course out 6s //by LYM 2013/07/02
			// stop3dGame();
			if( !m_bMustEnd ) {
				m_bMustEnd = true;
				Close();
			}
		}
	}
	
	private void calcFps() {
		long lCur = System.currentTimeMillis();
		long lDiff = lCur - m_lPrevTime;
		if (lDiff > 100) { //100ms
			lDiff = 100;
			m_lPrevTime = lCur - lDiff;
		}
		
	    m_nFrameCount = 0;
	    m_lUpdateTimes = 0;
        if( m_lUpdateTimes>=10*1000 ) {
        	m_lUpdateTimes = 0;
        	m_nFrameCount = 0;
        }
        m_lUpdateTimes += (int) lDiff;
        m_nFrameCount++;
        m_fFPS = (float)1000*m_nFrameCount/m_lUpdateTimes;
        if( m_fFPS <= 0 )
        	m_fFPS = 1;
        
        m_lPrevTime = lCur;
	}
	
	//---------------------------------------------------------------
	// キーチェック
	//---------------------------------------------------------------
	void KeyCheck() {
		final float ANGLE_STEP = 28.0f/8; // 20do/sec
		final float BEND = 42.0f/8; // 30do/sec
		final float VELOCITY = 180.0f; // 150/sec
		
		if( m_nHandling == 0 ) { // 左キーを押したとき 
			m_Car.y_angle += ANGLE_STEP/m_fFPS;
			m_Car.bend = BEND/m_fFPS;
			
			if( m_leftHandle.textures().get(0) != m_textureFocus )
				m_leftHandle.textures().addReplace(m_textureFocus);
		}
		else {
			if( m_leftHandle.textures().get(0) != m_textureNorm )
				m_leftHandle.textures().addReplace(m_textureNorm);
		}
		if( m_nHandling == 1 ) { // 右キーを押したとき 
			m_Car.y_angle -= ANGLE_STEP/m_fFPS;
			m_Car.bend = -BEND/m_fFPS;
			
			if( m_rightHandle.textures().get(0) != m_textureFocus )
				m_rightHandle.textures().addReplace(m_textureFocus);
		}
		else {
			if( m_rightHandle.textures().get(0) != m_textureNorm )
				m_rightHandle.textures().addReplace(m_textureNorm);
		}

		// カメラの角度計算
		m_nCameraAngle += (m_Car.y_angle-m_nCameraAngle)/10;
		//m_nCameraAngle = m_Car.y_angle;

		// 車の移動
		float fV = VELOCITY / m_fFPS;
		float radian = STD.Angle2Radian(m_Car.y_angle+m_Car.bend);
		m_Car.pos_x -= fV*Math.sin(radian);
		m_Car.pos_z -= fV*Math.cos(radian);
	}

	/*===========================================================================
	  カメラの配置
	===========================================================================*/
	void CameraPos() {
		Number3d carPos = new Number3d();
		carPos.setAll(m_Car.pos_x, 8, m_Car.pos_z);
		float radian = STD.Angle2Radian(m_nCameraAngle);
		//視点位置の設定
		// m_camera.upAxis.setAll(0.0f, 0.0f, 4096.0f); // 視点の上方向

		m_camera.position.setAll(0.0f, 30.0f, 55.0f); //視点位置の設定
		
		m_camera.position.rotateY(radian);
		m_camera.position.add(carPos);

		m_camera.target.setAll(0.0f, -60.0f, -230.0f/*-400.0f*/); //視点の向き // SKY:120605
		m_camera.target.rotateY(radian);
		m_camera.target.add(carPos);
		
		//m_camera.position.setAll(0.0f, 30.0f, 60.0f);
		//m_camera.target.setAll(0.0f, -50.0f, -400.0f);
	}
	
	void UpdateModelPoses() {
		Number3d carPos = new Number3d();
		carPos.setAll(m_Car.pos_x, m_Car.pos_y, m_Car.pos_z);
		
		// sky
		m_modelSky.position().setAll(m_Car.pos_x, m_Car.pos_y, m_Car.pos_z);
		
		// ground & road
		int i, j;
		float angle, radian;
		for( i = 0 ; i < MAP_COUNT ; i++ ) {
			angle = m_Field[i].y_angle*90;
			m_modelGround[i].rotation().setAll(0.0f, angle, 0.0f);
			m_modelGround[i].position().setAll(m_Field[i].pos_x, 0, m_Field[i].pos_z);
			for( j = 0 ; j < MAP_COUNT ; j++ ) {
				if( (j+1) == m_Field[i].kind )
					m_modelRoad[i][j].isVisible(true);
				else
					m_modelRoad[i][j].isVisible(false);
				m_modelRoad[i][j].rotation().setAll(0.0f, angle, 0.0f);
				m_modelRoad[i][j].position().setAll(m_Field[i].pos_x, 2.0f, m_Field[i].pos_z);
			}
		}
		
		// car
		angle = m_Car.y_angle;
		radian = STD.Angle2Radian(angle);
		m_modelCar.rotation().setAll(0.0f, angle, 0.0f);
		m_modelCar.position().setAll(m_Car.pos_x, 8, m_Car.pos_z);
		
		// change button's poses.
		m_leftHandle.rotation().setAll(0.0f, 180+angle, 0.0f);
		m_leftHandle.position().setAll(-20, 25, -20);
		m_leftHandle.position().rotateY(radian);
		m_leftHandle.position().add(carPos);
		m_rightHandle.rotation().setAll(0.0f, angle, 0.0f);
		m_rightHandle.position().setAll(20, 25, -20);
		m_rightHandle.position().rotateY(radian);
		m_rightHandle.position().add(carPos);
	}
	

	/*===========================================================================
		マップのセット
	===========================================================================*/
	void FieldZSet()
	{
		// マップデータ [4][14]
		int[][] world = new int[][] {{1,1,3,1,3,1,1,1,2,1,1,1,2,1},				// 種類
							{0,0,0,0,2,0,0,0,0,1,1,1,2,0},				// 角度
							{0,0,0,0,0,0,0,0,0,FPOS,FPOS,FPOS,FPOS,0},	// 配置位置
							{FPOS,FPOS,FPOS,FPOS,FPOS,FPOS,FPOS,FPOS,FPOS,0,0,0,0,FPOS},};
		int i;
		int kind, no;
		int posx, posz;
	
		posz = FPOS;			// 
		posx = 0;				// フィールドの位置初期化
		kind = m_fieldkind;	// マップの種類初期化
		no = m_fieldno;	// フィールドNo初期化
	
		// フィールドの設定
		for(i=0;i<3;i++)
		{
			// 角度に応じてフィールドの位置を調整
			switch(world[1][kind])
			{
			case 0:
				m_Field[no].pos_x = posx;
				m_Field[no].pos_y = 0;
				m_Field[no].pos_z = posz;
				break;
			case 1:
				m_Field[no].pos_x = posx+(FPOS/2);
				m_Field[no].pos_y = 0;
				m_Field[no].pos_z = posz-(FPOS/2);
				break;
			case 2:
				m_Field[no].pos_x = posx;
				m_Field[no].pos_y = 0;
				m_Field[no].pos_z = posz-FPOS;
				break;			
			case 3:
				m_Field[no].pos_x = posx-(FPOS/2);
				m_Field[no].pos_y = 0;
				m_Field[no].pos_z = posz+(FPOS/2);
				break;			
			}
	
			m_Field[no].kind = world[0][kind];		// フィールドの種類設定
			m_Field[no].y_angle = world[1][kind];	// フィールドの角度設定
	
			kind = (kind+1)%14;					// フィールドの種類変更
			no = (no+1)%3;						// フィールドNo
			posz -= world[3][kind];				//
			posx += world[2][kind];				// 配置位置
		}
	
		m_fieldkind = (m_fieldkind+1)%14;		// フィールドの種類を変える
		m_fieldno = (m_fieldno+1)%3;			// フィールドNo
		m_Car.pos_z = 0;						// 車の位置を初期化
	
		// 走行距離の計算
		if(m_nDistance < 999999)
			m_nDistance++;	// 走行距離
	}
	
	/*===========================================================================
		マップのセット
	===========================================================================*/
	private void FieldXSet()
	{
		// マップデータ [4][14]
		int[][] world = new int[][] {{1,1,3,1,3,1,1,1,2,1,1,1,2,1},		// 種類
							{0,0,0,0,0,0,0,0,0,1,1,1,2,0},
							{0,0,0,0,0,0,0,0,0,FPOS,FPOS,FPOS,FPOS,0},
							{FPOS,FPOS,FPOS,FPOS,FPOS,FPOS,FPOS,FPOS,FPOS,0,0,0,0,FPOS},};	// 角度
		int i;
		int kind, no;
		int posx, posz;
	
		posz = 0;
		posx = -FPOS;
		kind = m_fieldkind;
		no = m_fieldno;
		for(i=0;i<3;i++)
		{
			// 角度に応じてフィールドの位置を調整
			switch(world[1][kind])
			{
			case 0:
				m_Field[no].pos_x = posx;
				m_Field[no].pos_y = 0;
				m_Field[no].pos_z = posz;
				break;
			case 1:
				m_Field[no].pos_x = posx+(FPOS/2);
				m_Field[no].pos_y = 0;
				m_Field[no].pos_z = posz-(FPOS/2);
				break;
			case 2:
				m_Field[no].pos_x = posx;
				m_Field[no].pos_y = 0;
				m_Field[no].pos_z = posz-FPOS;
				break;			
			case 3:
				m_Field[no].pos_x = posx-(FPOS/2);
				m_Field[no].pos_y = 0;
				m_Field[no].pos_z = posz+(FPOS/2);
				break;			
			}
			m_Field[no].kind = world[0][kind];
			m_Field[no].y_angle = world[1][kind];
			kind = (kind+1)%14;
			no = (no+1)%3;
			posz -= world[3][kind];
			posx += world[2][kind];
		}
	
		m_fieldkind = (m_fieldkind+1)%14;
		m_fieldno = (m_fieldno+1)%3;
		m_Car.pos_x = -2500;
	
		// 走行距離の計算
		if(m_nDistance < 999999)
			m_nDistance++;		// 走行距離
	}
	
	
	/*===========================================================================
	  マップの読み込み
	===========================================================================*/
	void LoadMap(CARMODEL car) {
		byte buf;
		int no = m_fieldno;
	
		MapChange();
		MapRotatePos(car);
		MapCheck(car);
	
		// データ読み込み
		byte[] byData = new byte[MAP_DATA_LEN];
		STD.MEMCPY(byData, 0, m_byMapData, 
				((m_Field[no].kind-1)*10000)+(car.save_z*100)+car.save_x, 
				MAP_DATA_LEN);
	
		// 読み込んだデータから数字を抜き出す(マップ)
		if(car.save_z < 100 && car.save_x < 100) {
			buf = byData[0];
			m_Car.out = buf - 0x30; // ascii number -> real number
		}else{
			m_Car.out = 0;
	
		}
	
	}
	
	/*===========================================================================
	  マップを回転した時の車の位置
	===========================================================================*/
	void MapRotatePos(CARMODEL car) {
		int no = m_fieldno;
	
		// 通常
		switch(m_Field[no].y_angle) {
		case 0:		// 通常角度
			car.rot_x = (int) (car.pos_x/50)+50;
			car.rot_z = (int) (car.pos_z/50)+99;
			break;
		case 1:		// 左に９０度回転
			car.rot_x = (int) (car.pos_z/65)+88;
			car.rot_z = (int) (99-((car.pos_x/50)+50));
			break;
		case 2:		// 反転
			car.rot_x = (int) (99-((car.pos_x/50)+49));
			car.rot_z = (int) (99-((car.pos_z/50)+99));
			break;
		case 3:		// 左に９０度回転
			car.rot_x = (int) (99+((car.pos_z/50)+99));
			car.rot_z = (int) (99-((car.pos_x/50)+50));
			break;
		}
	}
	
	/*===========================================================================
	  マップを回転した時のマップ配置設定
	===========================================================================*/
	void MapChange()
	{
		int no = m_fieldno;
		// 通常
		switch(m_Field[no].y_angle) {
		case 0:		// 通常角度
			if(m_Car.rot_z <= 0)		FieldZSet();				// フィールドのセット
			if(m_Car.rot_x >= 100)		FieldXSet();				// フィールドのセット
			break;
		case 1:		// 通常角度
		case 3:		// 通常角度
			if(m_Car.rot_z <= 0)		FieldXSet();				// フィールドのセット
			if(m_Car.rot_x >= 100)		FieldZSet();				// フィールドのセット
			break;
		case 2:		// 通常角度
			if(m_Car.rot_z >= 100)		FieldZSet();				// フィールドのセット
	//		if(m_Car.save_x >= 100)		FieldXSet();				// フィールドのセット
			break;
		}
	
	}
	/*===========================================================================
	  マップチェック
	===========================================================================*/
	void MapCheck(CARMODEL car)
	{
		// 通常
		car.save_x = car.rot_x;
		car.save_z = car.rot_z;
	}
	

	

}




//地面
class FIELD {
	float		pos_x;			// 配置位置
	float		pos_y;
	float		pos_z;
	int			y_angle;		// モデル用回転用変数
	int			kind;			// 種類
	int			no;				// ナンバー
};

//車
class CARMODEL {
	float		pos_x;		// 配置位置
	float		pos_y;
	float		pos_z;
	int			save_x;		// 記録用
	int			save_y;
	int			save_z;
	int			rot_x;		// 回転用
	int			rot_y;
	int			rot_z;
	float	y_angle;	// モデル用回転用変数

	int		x;	// モデル用回転用変数
	int		z;	// モデル用回転用変数
	float	bend;			// 

	int				out;		// 外へ
};
