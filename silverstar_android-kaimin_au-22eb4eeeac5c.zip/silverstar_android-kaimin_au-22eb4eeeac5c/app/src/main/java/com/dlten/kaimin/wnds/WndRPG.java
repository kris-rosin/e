package com.dlten.kaimin.wnds;

import java.util.Timer;
import java.util.TimerTask;

import android.widget.ToggleButton;

import com.dlten.kaimin.Globals;
import com.dlten.kaimin.frmWndMgr;
import com.dlten.kaimin.kaimin;
import com.dlten.kaimin_auOM.R;
import com.dlten.lib.STD;
import com.dlten.lib.file.CResFile;
import com.dlten.lib.frmWork.CButton;
import com.dlten.lib.frmWork.CWnd;
import com.dlten.lib.graphics.CDCView;
import com.dlten.lib.graphics.CImgObj;

public class WndRPG extends WndTimer {

	private int m_nStep;
	private	long	m_timeProc;

	private static long OPEN_FRAME_COUNT 	= 20;
	private static long CLOSE_FRAME_COUNT 	= 20;

	private CImgObj[] m_imgField   = new CImgObj[4];
	private CImgObj m_imgMenuBg   = new CImgObj();
	private CImgObj m_imgMenuNor   = new CImgObj();
	private CImgObj m_imgBtnMenuNor   = new CImgObj();
	private CImgObj m_imgBtnMenuFoc   = new CImgObj();
	private CImgObj[] m_imgBtn   = new CImgObj[10];

	private CImgObj[] m_imgNum   = new CImgObj[10];
	private CImgObj[] m_imgChar   = new CImgObj[8];

	private CImgObj m_imgTitle   = new CImgObj();
	private CImgObj m_imgBlack1   = new CImgObj();
	private CImgObj m_imgBlack2   = new CImgObj();
	private CImgObj m_imgInfo   = new CImgObj();
	private CImgObj m_imgLoading	= new CImgObj();
	private CImgObj m_imgCur   = new CImgObj();
	private CImgObj m_imgEnemy   = new CImgObj();
	
	private CImgObj m_imgMsgAttack1   = new CImgObj();
	private CImgObj m_imgMsgAttack2a   = new CImgObj();
	private CImgObj m_imgMsgAttack2b   = new CImgObj();
	private CImgObj m_imgMsgEnemy1   = new CImgObj();
	private CImgObj m_imgMsgEnemy2a   = new CImgObj();
	private CImgObj m_imgMsgEnemy2b   = new CImgObj();
	private CImgObj m_imgMsgEscape1   = new CImgObj();
	private CImgObj m_imgMsgEscape2   = new CImgObj();
	private CImgObj m_imgMsgItem   = new CImgObj();
	private CImgObj m_imgMsgLevelup1   = new CImgObj();
	private CImgObj m_imgMsgLevelup2   = new CImgObj();
	private CImgObj m_imgMsgMagic   = new CImgObj();
	private CImgObj m_imgMsgStart   = new CImgObj();
	private CImgObj m_imgMsgWin1   = new CImgObj();
	private CImgObj m_imgMsgWin2   = new CImgObj();
	
	private CImgObj m_imgWinCommand   = new CImgObj();
	private CImgObj m_imgWinPlayer   = new CImgObj();
	private CImgObj m_imgWinPlayer9   = new CImgObj();

	private CButton	m_btnMenu  = null;
//	private CButton	m_btnSelect  = null;
	
	private	long m_timePauseStart = 0;
	private	boolean m_bPauseFinished = false;
	private boolean m_bMenu = false;
	
	private int m_nExp;
	private int m_nEnemyHP;
	private int m_nGameStatus;
	private final int ST_TITLE = 0;
	private final int ST_FIELD = 1;
	private final int ST_BATTALE = 2;
	
	private int m_nCharIndex;
	private int m_nKeyStatus;
	private int m_nKeyFrame;
	private int m_nStepFrame;
	private int m_nStepKind;
	private int m_nStepCount;
	private int m_nToggleFrame;
	private int m_nToggleKind; //0:battle->field black_in, 1:field->battle, 2:loading 3:battle->filed black_out 4:title->field
	private int m_nAniFrame1;
	private int m_nBattleCur;
	private int m_nBattleStatus;
	private int m_nMsgFrame;
	private int m_nMsgAlpha;
	private int MSG_FRAME;
	private final int BS_START = -1;
	private final int BS_COMMAND = 0;
	private final int BS_ATTACK = 10;
	private final int BS_ATTACK_A = 11;
	private final int BS_ATTACK_B = 12;
	private final int BS_MAGIC = 20;
	private final int BS_ITEM = 30;
	private final int BS_ESCAPE = 40;
	private final int BS_ESCAPE_2 = 41;
	private final int BS_ENEMY = 50;
	private final int BS_ENEMY_A = 51;
	private final int BS_ENEMY_B = 52;
	private final int BS_WIN = 60;
	private final int BS_WIN_2 = 61;
	private final int BS_LEVELUP = 70;
	private final int BS_LEVELUP_2 = 71;
	
	private int FPS = 25;
	private int TITLE_FRAME = 14;
	private int F_B_FRAME = 40;
	private int B_F_FRAME = 28;
	private int LOADING_FRAME = 400;
	private int STEP_FRAME = 20;
	private int ODDS = 3;
	private int KEYBOARD_RECT[][] = {{50, 681}, {200, 681}, {145, 585}, {145, 738}, {433, 668}};
	private int KEY_RECT[][] = {{50, 681}, {240, 681}, {145, 585}, {145, 778}, {433, 668}};
	private final int DRAW_W = 640;
	private final int DRAW_H = 640;
	
	private float m_nBgX;
	private float m_nBgY;
	private boolean m_bDrawing;
	private int m_nFrame = 0;
	
	static int REPEAT_KEYBOARD = 10;
//	static long INTERVAL = 33;
//	Timer timer = new Timer();  
//	TimerTask task = new TimerTask(){  
//        public void run() {  
//        	OnTimer();  
//        }  
//    };
    
    public static final int 
    	SE_ATTACK  = 11,
    	SE_START = 12,
    	SE_ESCAPE = 13,
    	SE_LEVEL = 14,
    	SE_MISS = 15,
    	SE_SET = 16,
    	SE_WIN = 17;

    public static final int
    	CMD_SELECT 			= 0,
		CMD_MENU_ASYNC      = 1,
		CMD_SELECT_CLOSE	= 2;
    
    //kjh start
	private static final int	BTN_FOCUS_SELECT				=	100;
	private static final int	BTN_FOCUS_MENU					=	105;
	
	public int					m_nCurFoucus	=	-1;
	
	public void initFocusBtns(){
		
//		if( m_btnSelect != null )
//			m_btnSelect.setNormal();
		if( m_btnMenu != null )
			m_btnMenu.setNormal();
			
	}
	
	public void updateFocusBtns( int nFocusBtn ){
		
		if( !kaimin.m_bSBTV )
			return;
		
//		if( m_nCurFoucus == nFocusBtn )
//			return;
		try {
			
			initFocusBtns();
			
			switch ( nFocusBtn ) {
				case BTN_FOCUS_MENU:
					if( m_btnMenu != null )
						m_btnMenu.setFocus();
					break;
//				case BTN_FOCUS_SELECT:
//					if( m_btnSelect != null )
//						m_btnSelect.setFocus();
//					break;
			default:
				break;
			}	
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		m_nCurFoucus	=	nFocusBtn;
		
	}
	//kjh end
	
	public void OnLoadResource() {
		createImages();
		super.OnLoadResource();
	}
	public void OnInitWindow() {
		Globals.m_bBGMDisable = true;
		Globals.m_bSEDisable = false;
		Globals.m_bSoundEnable = true;
		
		m_nBgX = -DRAW_W;
		m_nBgY = -DRAW_H;
		m_nCharIndex = 6;
		m_nExp = 999999;
		m_nKeyStatus = -1;
		m_nKeyFrame = -1;
		m_nStepFrame = -1;
		m_nToggleFrame = -1;
		m_nToggleKind = -1;
		m_nMsgFrame = -1;
		m_nMsgAlpha = 0;
		m_nGameStatus = ST_TITLE;
		m_nStepCount = 0;
		m_nAniFrame1 = -1;
		MSG_FRAME = (Globals.GetMSpeedType() + 2) * 20;
		m_bDrawing = false;
		
		m_nStep = 0;
		m_timeProc = STD.GetTickCount();
		
		SetTimer(ID_TIMER_0, FPS);		
//		timer.scheduleAtFixedRate(task, 0, INTERVAL);//30fps
	}
	
	public void OnShowWindow() {
	}

	private void createImages() {
		int i;
		//kjh start
		for(i = 0; i < 4; i ++) {
			m_imgField[i] = new CImgObj("I1/I1_field.png", kaimin.m_bSBTV );
		}
		//kjh end
		
		m_imgMenuBg.load("COMN/COMN_menu_back.png", kaimin.m_bSBTV );
		m_imgMenuBg.moveTo(0, 899);
		m_imgMenuNor.load("COMN/COMN_btn_menu_1.png", kaimin.m_bSBTV );
		m_imgMenuNor.moveTo(433, 901.5f);

		m_imgBtnMenuNor.load("COMN/COMN_btn_menu_1.png", kaimin.m_bSBTV );
		
		if( kaimin.m_bSBTV ){
			m_imgBtnMenuFoc.load("COMN/COMN_btn_menu_2_sbtv.png", kaimin.m_bSBTV );
		}else{
			m_imgBtnMenuFoc.load("COMN/COMN_btn_menu_2.png", kaimin.m_bSBTV );
		}
		
		for(i = 0; i < 10; i ++) {
			m_imgNum[i] = new CImgObj("COMN/COMN_num_" + i + ".png", kaimin.m_bSBTV );
			m_imgBtn[i] = new CImgObj("I1/I1_btn_cur_" + i + ".png", kaimin.m_bSBTV );
			m_imgBtn[i].moveTo(KEYBOARD_RECT[i/2][0],KEYBOARD_RECT[i/2][1]);
			
			if (i < 8) {
				m_imgChar[i] = new CImgObj("I1/I1_player_" + i + ".png", kaimin.m_bSBTV );
				m_imgChar[i].moveTo(288, 253);
			}
		}
		
		m_imgTitle.load("I1/I1_title.png", kaimin.m_bSBTV );
		m_imgTitle.moveTo(0,0);
		m_imgBlack1.load("I1/I1_black1.png", kaimin.m_bSBTV );
		m_imgBlack1.moveTo(0,0);
		m_imgBlack2.load("I1/I1_black2.png", kaimin.m_bSBTV );
		m_imgInfo.load("I1/I1_info.png", kaimin.m_bSBTV );
		m_imgInfo.moveTo(9, 906);
		m_imgLoading.load("I1/I1_loading.png", kaimin.m_bSBTV );
		m_imgLoading.moveTo(36, 47);
		m_imgCur.load("I1/I1_cursor.png", kaimin.m_bSBTV );
		m_imgCur.moveTo(48.5f, 411.5f);
		m_imgEnemy.load("I1/I1_enemy.png", kaimin.m_bSBTV );
		m_imgEnemy.moveTo(212, 206);
		m_imgMsgAttack1.load("I1/I1_msg_attack_1.png", kaimin.m_bSBTV );
		m_imgMsgAttack1.moveTo(51, 399.5f);
		m_imgMsgAttack2a.load("I1/I1_msg_attack_2_a.png", kaimin.m_bSBTV );
		m_imgMsgAttack2a.moveTo(71, 453.5f);
		m_imgMsgAttack2b.load("I1/I1_msg_attack_2_b.png", kaimin.m_bSBTV );
		m_imgMsgAttack2b.moveTo(71, 453.5f);
		m_imgMsgEnemy1.load("I1/I1_msg_enemy_1.png", kaimin.m_bSBTV );
		m_imgMsgEnemy1.moveTo(51, 399.5f);
		m_imgMsgEnemy2a.load("I1/I1_msg_enemy_2_a.png", kaimin.m_bSBTV );
		m_imgMsgEnemy2a.moveTo(71, 453.5f);
		m_imgMsgEnemy2b.load("I1/I1_msg_enemy_2_b.png", kaimin.m_bSBTV );
		m_imgMsgEnemy2b.moveTo(71, 453.5f);
		m_imgMsgEscape1.load("I1/I1_msg_escape_1.png", kaimin.m_bSBTV );
		m_imgMsgEscape1.moveTo(51, 399.5f);
		m_imgMsgEscape2.load("I1/I1_msg_escape_2.png", kaimin.m_bSBTV );
		m_imgMsgEscape2.moveTo(71, 453);
		m_imgMsgItem.load("I1/I1_msg_item.png", kaimin.m_bSBTV );
		m_imgMsgItem.moveTo(51, 399.5f);
		m_imgMsgLevelup1.load("I1/I1_msg_levelup_1.png", kaimin.m_bSBTV );
		m_imgMsgLevelup1.moveTo(51, 399.5f);
		m_imgMsgLevelup2.load("I1/I1_msg_levelup_2.png", kaimin.m_bSBTV );
		m_imgMsgLevelup2.moveTo(71, 453);
		m_imgMsgMagic.load("I1/I1_msg_magic.png", kaimin.m_bSBTV );
		m_imgMsgMagic.moveTo(51, 399.5f);
		m_imgMsgStart.load("I1/I1_msg_start.png", kaimin.m_bSBTV );
		m_imgMsgStart.moveTo(51, 399.5f);
		m_imgMsgWin1.load("I1/I1_msg_win_1.png", kaimin.m_bSBTV );
		m_imgMsgWin1.moveTo(51, 399.5f);
		m_imgMsgWin2.load("I1/I1_msg_win_2.png", kaimin.m_bSBTV );
		m_imgMsgWin2.moveTo(71, 453.5f);
		m_imgWinCommand.load("I1/I1_win_command.png", kaimin.m_bSBTV );
		m_imgWinCommand.moveTo(26, 400);
		m_imgWinPlayer.load("I1/I1_win_player.png", kaimin.m_bSBTV );	
		m_imgWinPlayer.moveTo(35.5f, 45.5f);
		m_imgWinPlayer9.load("I1/I1_win_player9.png", kaimin.m_bSBTV );	
		m_imgWinPlayer9.moveTo(215.5f, 133.5f);
		
		//kjh start
		if( kaimin.m_bSBTV ){
			
			m_imgMenuBg.setSBTVScale( true );
			m_imgMenuNor.setSBTVScale( true );
			
			for(i = 0; i <= 10; i ++)
				m_imgNum[i].setSBTVScale( true );
			
			m_imgBtnMenuNor.setSBTVScale( true );
			m_imgBtnMenuFoc.setSBTVScale( true );
			
		}
		//kjh end
	}
	
	public void createButtons() {
		CButton	btn = null;

		btn = createButton(
				m_imgBtnMenuNor,
				m_imgBtnMenuFoc,
				null);
		btn.setPoint(433, 901.5f);
		btn.setCommand( CMD_MENU_ASYNC );
		btn.setAsyncFlag(true);
		m_btnMenu = btn;

//		btn = createButton(
//				m_imgBtnSelectNor,
//				m_imgBtnSelectFoc,
//				null);
//		btn.setPoint(449, 675);
//		btn.setCommand( CMD_SELECT );
//		m_btnSelect = btn;
		
		updateFocusBtns( BTN_FOCUS_SELECT );
		
	}
	
	public void OnPaint() {
		m_bDrawing = true;
		// drawing dimmension is just Globals.RES_WIDTH * Globals.RES_HEIGHT
		drawBackGround();
		
		int nAlpha = GetStepAlpha();
		setViewAlpha(nAlpha);
		
		m_bDrawing = false;
		
//		OnTimer();
		super.OnPaint();
	}
	
	public void OnKeyDown( int keycode ) {
		switch (keycode) {
		case KEY_MENU:		OnMenu();						break;
		case KEY_BACK:		OnExit();						break;
		
		//kjh start
		case KEY_DPAD_CENTER:
			onDPADCenter();
			break;
		case KEY_DPAD_UP:
			onUpKey();
			break;
		case KEY_DPAD_DOWN:
			onDownKey();
			break;
		case KEY_DPAD_LEFT:
			onLeftKey();
			break;
		case KEY_DPAD_RIGHT:
			onRightKey();
			break;
		//kjh end
		
		default:			super.OnKeyDown(keycode);		break;
		}
	}
	
	//kjh start
	
	public void onDPADCenter(){
		
		if( m_nCurFoucus == BTN_FOCUS_MENU )
			OnOption();
		else
			OnSelect();
		
	}
	
	public void onLeftKey(){
		if( m_nCurFoucus == BTN_FOCUS_MENU )
			updateFocusBtns( BTN_FOCUS_SELECT );
		OnLeft();
	}
	
	public void onRightKey(){
		if( m_nCurFoucus == BTN_FOCUS_MENU )
			updateFocusBtns( BTN_FOCUS_SELECT );
		OnRight();
	}
	
	public void onDownKey(){
		if( m_nCurFoucus == BTN_FOCUS_MENU )
			updateFocusBtns( BTN_FOCUS_SELECT );
		OnDown();
	}
	
	public void onUpKey(){
		if( m_nCurFoucus == BTN_FOCUS_MENU )
			updateFocusBtns( BTN_FOCUS_SELECT );
		OnUp();
	}
	//kjh end
	public void OnCommand(int nCmd) {
		if(m_nStep != 1)
			return;
    	switch (nCmd) {
    	case CMD_SELECT:		OnSelect();	break;
    	case CMD_MENU_ASYNC:	OnOption();	break;
    	case CMD_SELECT_CLOSE:	Close();	break;
    	}
    }
	
	public void OnExit() {
		Close();
	}

	public void OnUp() {
		if (m_nGameStatus == ST_FIELD) {
			m_nStepFrame = 0;
		} else if (m_nGameStatus == ST_BATTALE) {
			if (m_nBattleStatus == BS_COMMAND) {
				m_nBattleCur --;
				if (m_nBattleCur < 0)
					m_nBattleCur = 3;
			}
		}
	}

	public void OnDown() {
		if (m_nGameStatus == ST_FIELD) {
			m_nStepFrame = 0;
		} else if (m_nGameStatus == ST_BATTALE) {
			if (m_nBattleStatus == BS_COMMAND) {
				m_nBattleCur ++;
				if (m_nBattleCur >= 4)
					m_nBattleCur = 0;
			}
		}
	}
	
	public void OnLeft() {
		if (m_nGameStatus == ST_FIELD) {
			m_nStepFrame = 0;
		} else if (m_nGameStatus == ST_BATTALE) {
			
		}
	}
	
	public void OnRight() {
		if (m_nGameStatus == ST_FIELD) {
			m_nStepFrame = 0;
		} else if (m_nGameStatus == ST_BATTALE) {
			
		}
	}
	
	public void OnSelect() {
		if (m_nStepFrame >= 0 || m_nToggleFrame >= 0 || m_nMsgFrame >= 0)
			return;
		
		if (m_nGameStatus == ST_TITLE) {
			if (Globals.m_bSoundEnable) {
				Globals.playSE(SE_SET);
			}
			m_nToggleFrame = 0;
			m_nToggleKind = 4;
		} else if (m_nGameStatus == ST_BATTALE) {
			if (m_nBattleStatus == BS_COMMAND) {
				if (Globals.m_bSoundEnable) {
					if (m_nBattleCur == 3)
						Globals.playSE(SE_ESCAPE);
					else
						Globals.playSE(SE_SET);
				}
				switch (m_nBattleCur) {
				case 0: m_nBattleStatus = BS_ATTACK; break;
				case 1: m_nBattleStatus = BS_MAGIC; break;
				case 2: m_nBattleStatus = BS_ITEM; break;
				case 3: m_nBattleStatus = BS_ESCAPE; break;
				}
				m_nMsgFrame = 0;
				m_nMsgAlpha = 0;
			} else if (m_nBattleStatus == BS_LEVELUP_2) {
				OnExit();
			}
		}
	}
	
	public void OnKeyBoard() {
		if (m_nStepFrame >= 0 || m_nToggleFrame >= 0 || m_nMsgFrame >= 0)
			return;
		if (m_nKeyStatus < 0) {
			m_nKeyFrame = -1;
			return;
		}
		
		if (m_nGameStatus == ST_FIELD)
			m_nStepKind = m_nKeyStatus;
		
		switch (m_nKeyStatus) {
		case 0: OnLeft(); break;
		case 1: OnRight(); break;
		case 2: OnUp(); break;
		case 3: OnDown(); break;
		case 4: OnSelect(); break;
		}
	}

	public void MessageBoxClosed(int dlgid) {
		switch(dlgid) {
		case 5:
			if(Globals.m_bShowYesNo) {
		        getView().getActivity().showAlertDialog( 3 );	//kjh
			}
			else {
				MSG_FRAME = (Globals.GetMSpeedType() + 2) * 20;
				m_bMenu = false;
				resume();
			}
			if (Globals.m_bClickClose) { // if user clicks close button, ...
				OnClickMenuClose();
			}
			break;
		case 3:
			if(Globals.m_bSelYes) {
//				PostMessage(WM_COMMAND, CMD_SELECT_CLOSE, 0);
				Close();
			}
			else {
				m_bMenu = false;
				resume();
			}
			break;
		}
	}

	public void OnOption() {
		if (m_bMenu)
			return;
		m_bMenu = true;
		updateFocusBtns( BTN_FOCUS_MENU );				//kjh
		pause();
        getView().getActivity().showAlertDialog( 5 );	//kjh

	}
	
	private void Close() {
		RemoveAllButtons();

		m_nStep = 2;
		m_timeProc = STD.GetTickCount();
		
		KillTimer(ID_TIMER_0);
		m_bDrawing = true;
	}

	public void OnMenu() {
	}

	private int GetStepAlpha() {
		if (m_timeProc == 0)
			return 255;

		long curTime = STD.GetTickCount();
		int	nAlpha = 255;
		long timeElapse = curTime - m_timeProc;

		if(m_nStep == 0) {
			if(timeElapse >= OPEN_FRAME_COUNT * Globals.MS_PER_FRAME) {
				m_nStep ++;
				createButtons();
				m_timeProc = curTime;
				timeElapse = 0;
			}
			else {
				float	fAlpha = 255.0f;

				fAlpha *= (float)timeElapse;
				fAlpha /= (float)(OPEN_FRAME_COUNT * Globals.MS_PER_FRAME);
				nAlpha = (int)fAlpha;
			}
		}
		if(m_nStep == 2) {
			if(timeElapse >= CLOSE_FRAME_COUNT * Globals.MS_PER_FRAME) {
				nAlpha = 0;
				DestroyWindow( frmWndMgr.WND_TITLE );
			}
			else {
				float	fAlpha = 255.0f;

				fAlpha *= (float)timeElapse;
				fAlpha /= (float)(CLOSE_FRAME_COUNT * Globals.MS_PER_FRAME);
				nAlpha = (int)(255.0 - fAlpha);
			}
		}

		return nAlpha;
	}

	private void drawBackGround() {
		int i, nAlpha;
		if (m_nGameStatus == ST_TITLE) {
			m_imgField[3].moveTo(0, 0);
			m_imgField[3].draw();
			m_imgChar[m_nCharIndex].draw();
			if (m_nToggleFrame >= 0 && m_nToggleKind == 4) {
				nAlpha = 255 * (TITLE_FRAME - m_nToggleFrame) / TITLE_FRAME;
				m_imgTitle.setAlpha(nAlpha);
			}
			m_imgTitle.draw();
			
		} else if (m_nGameStatus == ST_FIELD) {

			for (i = 0; i < 4; i ++) {
				m_imgField[i].moveTo(m_nBgX + (i % 2) * DRAW_W, m_nBgY + (i / 2) * DRAW_H);
				m_imgField[i].draw();
			}
			m_imgChar[m_nCharIndex].draw();
			
			if (m_nToggleFrame >= 0 && m_nToggleKind == 1) {
				for (i = 0; i < 4; i ++) {
					if ((i % 2) == 0) {
						m_imgBlack2.moveTo(-DRAW_W + DRAW_W * m_nToggleFrame / F_B_FRAME, 300 * (i / 2));
					} else {
						m_imgBlack2.moveTo(DRAW_W - DRAW_W * m_nToggleFrame / F_B_FRAME, 150 + 300 * (i / 2));
					}
					
					m_imgBlack2.draw();
				}
			}		
			
		} else {
			
			if (m_nToggleFrame >= 0 && m_nToggleKind == 2) {
				m_imgBlack1.draw();
				if (m_nToggleFrame <= (LOADING_FRAME / 25))
					nAlpha = 255 * m_nToggleFrame / (LOADING_FRAME / 25);
				else if (m_nToggleFrame <= (LOADING_FRAME * 24 / 25))
					nAlpha = 255;
				else
					nAlpha = 255 * (LOADING_FRAME - m_nToggleFrame) / (LOADING_FRAME / 25);
				m_imgLoading.setAlpha(nAlpha);
				m_imgLoading.draw();
				int nT = m_nToggleFrame / (LOADING_FRAME / 4);
				m_imgBlack2.moveTo(311 + 22 * nT, 0);
				m_imgBlack2.draw();
			} else {
				
				if (m_nToggleFrame >= 0 && m_nToggleKind == 3) {
					m_imgField[3].moveTo(0, 0);
					m_imgField[3].draw();
					m_imgChar[m_nCharIndex].draw();
					
					nAlpha = 255 - (255 * m_nToggleFrame * 4) / B_F_FRAME;
					if (nAlpha < 0)
						nAlpha = 0;
					m_imgWinPlayer.setAlpha(nAlpha);
					m_imgMsgWin1.setAlpha(nAlpha);	
					m_imgMsgWin2.setAlpha(nAlpha);
					nAlpha = 255 - (255 * m_nToggleFrame) / B_F_FRAME;
					if (nAlpha < 0)
						nAlpha = 0;
					m_imgBlack1.setAlpha(nAlpha);
				} else {
					m_imgWinPlayer.setAlpha(255);
				}
				
				m_imgBlack1.draw();
				
				m_imgWinPlayer.draw();
				if (m_nBattleStatus < BS_WIN)
					m_imgEnemy.draw();
				if (m_nBattleStatus == BS_COMMAND) {
					m_imgWinCommand.draw();
					m_imgCur.moveTo(48.5f, 411.5f + 38 * m_nBattleCur);
					m_imgCur.draw();
				}
				
				switch (m_nBattleStatus) {
				case BS_START:	
					m_imgMsgStart.setAlpha(m_nMsgAlpha);	
					m_imgMsgStart.draw(); 
					break;
				case BS_ATTACK:	
					m_imgMsgAttack1.setAlpha(m_nMsgAlpha); 
					m_imgMsgAttack1.draw();	
					break;
				case BS_ATTACK_A:	
//					m_imgMsgAttack1.setAlpha(m_nMsgAlpha);
					m_imgMsgAttack1.draw();	
					m_imgMsgAttack2a.setAlpha(m_nMsgAlpha);
					m_imgMsgAttack2a.draw();
					break;
				case BS_ATTACK_B:	
//					m_imgMsgAttack1.setAlpha(m_nMsgAlpha);
					m_imgMsgAttack1.draw();
					m_imgMsgAttack2b.setAlpha(m_nMsgAlpha);
					m_imgMsgAttack2b.draw();
					break;
				case BS_MAGIC:	
					m_imgMsgMagic.setAlpha(m_nMsgAlpha);
					m_imgMsgMagic.draw();
					break;
				case BS_ITEM:	
					m_imgMsgItem.setAlpha(m_nMsgAlpha);
					m_imgMsgItem.draw();
					break;
				case BS_ESCAPE:	
					m_imgMsgEscape1.setAlpha(m_nMsgAlpha);
					m_imgMsgEscape1.draw();
					break;
				case BS_ESCAPE_2:	
//					m_imgMsgEscape1.setAlpha(m_nMsgAlpha);
					m_imgMsgEscape1.draw();	
					m_imgMsgEscape2.setAlpha(m_nMsgAlpha);
					m_imgMsgEscape2.draw(); 
					break;
				case BS_ENEMY:	
					m_imgMsgEnemy1.setAlpha(m_nMsgAlpha);
					m_imgMsgEnemy1.draw(); 
					break;
				case BS_ENEMY_A:	
//					m_imgMsgEnemy1.setAlpha(m_nMsgAlpha);
					m_imgMsgEnemy1.draw();	
					m_imgMsgEnemy2a.setAlpha(m_nMsgAlpha);
					m_imgMsgEnemy2a.draw(); 
					break;
				case BS_ENEMY_B:	
//					m_imgMsgEnemy1.setAlpha(m_nMsgAlpha);
					m_imgMsgEnemy1.draw();	
					m_imgMsgEnemy2b.setAlpha(m_nMsgAlpha);
					m_imgMsgEnemy2b.draw(); 
					break;
				case BS_WIN:	
					m_imgMsgWin1.setAlpha(m_nMsgAlpha);
					m_imgMsgWin1.draw(); 
					break;
				case BS_WIN_2:	
//					m_imgMsgWin1.setAlpha(m_nMsgAlpha);
					m_imgMsgWin1.draw();	
					if (m_nToggleFrame < 0)
						m_imgMsgWin2.setAlpha(m_nMsgAlpha);
					m_imgMsgWin2.draw(); 
					break;
				case BS_LEVELUP:	
					m_imgMsgLevelup1.setAlpha(m_nMsgAlpha);
					m_imgMsgLevelup1.draw(); 
					m_imgWinPlayer9.draw();
					break;
				case BS_LEVELUP_2:	
//					m_imgMsgLevelup1.setAlpha(m_nMsgAlpha);
					m_imgMsgLevelup1.draw();	
					m_imgMsgLevelup2.setAlpha(m_nMsgAlpha);
					m_imgMsgLevelup2.draw(); 
					m_imgWinPlayer9.draw();
					break;
				}
			}
		}

		drawKeyboard();
		drawInfo();
	}
	
	private void drawKeyboard() {
		
		for (int i = 0; i < 3; i ++) {
			m_imgBlack2.moveTo(0, 572 + 149 * i);
			m_imgBlack2.draw();
		}
		
		if (m_nKeyStatus == 0)
			m_imgBtn[1].draw();
		else
			m_imgBtn[0].draw();
		
		if (m_nKeyStatus == 1)
			m_imgBtn[3].draw();
		else
			m_imgBtn[2].draw();
		
		if (m_nKeyStatus == 2)
			m_imgBtn[5].draw();
		else
			m_imgBtn[4].draw();
		
		if (m_nKeyStatus == 3)
			m_imgBtn[7].draw();
		else
			m_imgBtn[6].draw();
		
		if (m_nKeyStatus == 4)
			m_imgBtn[9].draw();
		else
			m_imgBtn[8].draw();
	}
	
	private void drawInfo() {
		
		m_imgMenuBg.draw();
		
		if(m_nStep != 1) {
			m_imgMenuNor.draw();
		}
		
		m_imgInfo.draw();
		int nDiv = 1;
		for (int i = 0; i < 6; i ++) {
			int nDigit = ((m_nExp / nDiv) % 10);
			
			m_imgNum[nDigit].draw(273.5f + 20 * (5 - i), 919);
			
			nDiv *= 10;
		}
	}
		
	private void pause() {
		m_timePauseStart = STD.GetTickCount();
		m_bPauseFinished = false;
		KillTimer(ID_TIMER_0);
	}

	private void resume() {
		m_bPauseFinished = true;
		SetTimer(ID_TIMER_0, FPS);
	}

	public void OnSuspend() {
		Globals.pauseBGM();
		if (m_bMenu == false)
			pause();
	}

	public void OnResume() {
		Globals.resumeBGM();
		if (m_bMenu == false)
			resume();
	}
	
	@Override
	public void OnMultiTouchDown(int x1, int y1, int x2, int y2) {
		if (m_nToggleFrame >= 0)
			return;
		
		if (x1 < 100 && x2 < 100 && ((y1 > 860 && y2 < 100) || (y1 < 100 && y2 > 860))) {//TEST_LYM
			m_nExp = 1;
		}
			
		super.OnMultiTouchDown(x1, y1, x2, y2);
	}
	
	@Override
	public void OnTouchDown(int x, int y) {
		if (m_nToggleFrame >= 0)
			return;
		
		int nW;
		for (int i = 0; i < 5; i ++) {
			if (i < 4)
				nW = 104;
			else
				nW = 129;
			
			if (x > KEY_RECT[i][0] && x < KEY_RECT[i][0] + nW && 
					y > KEY_RECT[i][1] && y < KEY_RECT[i][1] + nW) {
				m_nKeyStatus = i;
				m_nKeyFrame = 0;
				return;
			}
		}
		super.OnTouchDown(x, y);
	}

	@Override
	public void OnTouchMove(int x, int y) {
		int i, nW;
		for (i = 0; i < 5; i ++) {
			if (i < 4)
				nW = 104;
			else
				nW = 129;
			
			if (x > KEY_RECT[i][0] && x < KEY_RECT[i][0] + nW && 
					y > KEY_RECT[i][1] && y < KEY_RECT[i][1] + nW) {
				break;
			}
		}
		if (i == 5) {
			m_nKeyStatus = -1;
			m_nKeyFrame = -1;
		} else {
			if (i != m_nKeyStatus) {
				m_nKeyStatus = i;
				m_nKeyFrame = 0;
			}
		}
		super.OnTouchMove(x, y);
	}

	@Override
	public boolean OnTouchUp(int x, int y) {
		if (m_nKeyStatus >= 0) {
			m_nKeyStatus = -1;
			m_nKeyFrame = -1;
		}
		return super.OnTouchUp(x, y);
	}
	
	public void OnTimer(int nTimerID) {
//		m_nFrame ++;
//		if (m_nFrame > 400) {
//			ClearMessageQueue();
//			m_nFrame = 0;
//		}
//	public void OnTimer() {
		if (m_bDrawing) {
			return;
		}
		
		int nRand;
		
		if (m_nAniFrame1 >= 0) {
			if (m_nAniFrame1 <= 5)
				m_imgEnemy.moveTo(212 + m_nAniFrame1, 206);
			else if (m_nAniFrame1 <= 15)
				m_imgEnemy.moveTo(217 - (m_nAniFrame1 - 5), 206);
			else if (m_nAniFrame1 <= 20)
				m_imgEnemy.moveTo(207 + (m_nAniFrame1 - 15), 206);
			
			m_nAniFrame1 ++;
			if (m_nAniFrame1 > 20)
				m_nAniFrame1 = -1;
		}
		
		if (m_nToggleFrame >= 0) {
			
			m_nToggleFrame ++;
			switch (m_nToggleKind) {
			case 1:
				if (m_nToggleFrame >= F_B_FRAME) {
					m_nToggleFrame = -1;
					m_nGameStatus = ST_BATTALE;
					m_nToggleFrame = 0;
					m_nToggleKind = 2;
					m_imgBlack1.setAlpha(255);
//					Globals.SetBGMType(Globals.m_nBGMType_WndRPG2);
//					if (Globals.m_bSoundEnable)
//						Globals.playBGM(Globals.m_nBGMType_WndRPG2);
				}
				break;
			case 2:
				if (m_nToggleFrame == 40) {
					Globals.SetBGMType(Globals.m_nBGMType_WndRPG2);
					if (Globals.m_bSoundEnable)
						Globals.playBGM(Globals.m_nBGMType_WndRPG2);
				}
				if (m_nToggleFrame >= LOADING_FRAME) {
					m_nToggleFrame = -1;
					m_nBattleStatus = BS_START;
					m_nMsgFrame = 0;
					m_nMsgAlpha = 0;
				}
				break;
			case 3:
				if (m_nToggleFrame >= B_F_FRAME) {
					m_nToggleFrame = -1;
					m_nGameStatus = ST_FIELD;
					m_nStepCount = 0;
					Globals.SetBGMType(Globals.m_nBGMType_WndRPG1);
					if (Globals.m_bSoundEnable)
						Globals.playBGM(Globals.m_nBGMType_WndRPG1);
				}
				break;
			case 4:
				if (m_nToggleFrame >= TITLE_FRAME) {
					m_nToggleFrame = -1;
					m_nGameStatus = ST_FIELD;
					m_nStepCount = 0;
					Globals.SetBGMType(Globals.m_nBGMType_WndRPG1);
					if (Globals.m_bSoundEnable)
						Globals.playBGM(Globals.m_nBGMType_WndRPG1);
				}
				break;
			}
		}
		
		if (m_nMsgFrame >= 0) {
			
			m_nMsgFrame ++;
			
			if (m_nMsgFrame >= MSG_FRAME) {
				m_nMsgFrame = -1;
				
				switch (m_nBattleStatus) {
				case BS_START:	m_nBattleStatus = BS_COMMAND; break;
				case BS_ATTACK:	 {
					if ((STD.rand(10)%2) == 0)
						m_nBattleStatus = BS_ATTACK_A;
					else
						m_nBattleStatus = BS_ATTACK_B;
					m_nMsgFrame = 0;
					m_nMsgAlpha = 0;
					m_nAniFrame1 = 0;
					if (Globals.m_bSoundEnable)
						Globals.playSE(SE_ATTACK);
					break;
				}				
				case BS_ATTACK_A:	{
					m_nEnemyHP -= 2;
					
					if (m_nEnemyHP <= 0) {
						m_nBattleStatus = BS_WIN;
						if (Globals.m_bSoundEnable) {
							Globals.stopBGM();
							Globals.playSE(SE_WIN);
						}
					} else {
						m_nBattleStatus = BS_ENEMY;
					}
					m_nMsgFrame = 0;
					m_nMsgAlpha = 0;
					break;
				}
				case BS_ATTACK_B:	{
					m_nEnemyHP -= 3;
					
					if (m_nEnemyHP <= 0) {
						m_nBattleStatus = BS_WIN;
						if (Globals.m_bSoundEnable) {
							Globals.stopBGM();
							Globals.playSE(SE_WIN);
						}
					} else {
						m_nBattleStatus = BS_ENEMY;
					}
					m_nMsgFrame = 0;
					m_nMsgAlpha = 0;
					break;
				}
				case BS_MAGIC:	m_nBattleStatus = BS_COMMAND; break;
				case BS_ITEM:	m_nBattleStatus = BS_COMMAND; break;
				case BS_ESCAPE:	{
					m_nBattleStatus = BS_ESCAPE_2; 
					m_nMsgFrame = 0; 
					m_nMsgAlpha = 0; 
					break;
				}
				case BS_ESCAPE_2:	m_nBattleStatus = BS_COMMAND; break;
				case BS_ENEMY:	{
					if ((STD.rand(10)%2) == 0)
						m_nBattleStatus = BS_ENEMY_A;
					else
						m_nBattleStatus = BS_ENEMY_B;
					m_nMsgFrame = 0;
					m_nMsgAlpha = 0;
					if (Globals.m_bSoundEnable)
						Globals.playSE(SE_MISS);
					break;
				}
				case BS_ENEMY_A:	m_nBattleStatus = BS_COMMAND; break;
				case BS_ENEMY_B:	m_nBattleStatus = BS_COMMAND; break;
				case BS_WIN:	{
					m_nBattleStatus = BS_WIN_2; 
					m_nMsgFrame = 0; 
					m_nMsgAlpha = 0;
					break;
				}
				case BS_WIN_2:	{
					m_nExp --;
					if (m_nExp <= 0) {
						m_nBattleStatus = BS_LEVELUP;
						m_nMsgFrame = 0;
						m_nMsgAlpha = 0;
						if (Globals.m_bSoundEnable)
							Globals.playSE(SE_LEVEL);
					} else{
						m_nBgX = -DRAW_W;
						m_nBgY = -DRAW_H;
						m_nToggleFrame = 0;
						m_nToggleKind = 3;
					}
					break;
				}
				case BS_LEVELUP:	{
					m_nBattleStatus = BS_LEVELUP_2; 
					m_nMsgFrame = 0; 
					m_nMsgAlpha = 0;
					break;
				}
				case BS_LEVELUP_2:	break;
				}
			}
			
			m_nMsgAlpha = 255 * m_nMsgFrame * 10 / MSG_FRAME;
			if (m_nMsgAlpha > 255 || m_nMsgAlpha < 0)
				m_nMsgAlpha = 255;

		}
		
		if (m_nStepFrame >= 0) {
			switch (m_nStepKind) {
			case 0:
				m_nBgX = m_nBgX + 3;//(64.0f / STEP_FRAME));
				if (m_nBgX >= 0)
					m_nBgX = -DRAW_W + m_nBgX;
				
				break;
			case 1:
				m_nBgX = m_nBgX - 3;//(64.0f / STEP_FRAME));
				if (m_nBgX < -DRAW_W)
					m_nBgX = DRAW_W + m_nBgX;
				
				break;
			case 2:
				m_nBgY = m_nBgY + 3;//(64.0f / STEP_FRAME));
				if (m_nBgY >= 0)
					m_nBgY = -DRAW_H + m_nBgY;
				
				break;
			case 3:
				m_nBgY = m_nBgY - 3;//(64.0f / STEP_FRAME));
				if (m_nBgY < - DRAW_H)
					m_nBgY = DRAW_H + m_nBgY;
				
				break;
			}
			
			if (m_nStepFrame < (STEP_FRAME / 2))
				m_nCharIndex = m_nStepKind * 2 + 1;
			else
				m_nCharIndex = m_nStepKind * 2;
			
			m_nStepFrame ++;
			if (m_nStepFrame >= STEP_FRAME) {
				m_nStepFrame = -1;
				m_nStepCount ++;
				if (m_nStepCount > 10) {
					nRand = STD.rand(100);
					if (nRand < ODDS) {
						m_nKeyFrame = -1;
						m_nToggleFrame = 0;
						m_nToggleKind = 1;
						m_nEnemyHP = STD.rand(6) + 5;
						if (Globals.m_bSoundEnable) {
							Globals.stopBGM();
							Globals.playSE(SE_START);
						}
					}
				}
			}
		}
		
		if (m_nKeyFrame >= 0) {
			if (m_nKeyFrame == 0) {
				OnKeyBoard();
			}
			m_nKeyFrame = (m_nKeyFrame + 1) % REPEAT_KEYBOARD;
		}
	}

}
