
package com.dlten.lib.frmWork;

import com.dlten.lib.CBaseView;
import com.dlten.lib.STD;

public abstract class CWndMgr implements Runnable {
    private static CWndMgr _instance = null;
    public static CWndMgr getInstance() {
        if( _instance == null ) {
            STD.ASSERT(false);
        }
        return _instance;
    }

    private Thread m_thread;
    private CBaseView m_DCView;

    private CWnd m_pCurShowWnd;
    private CEventWnd m_pOldModaless;
    private CEventWnd m_pOldFore;

    public CWndMgr( CBaseView view ) {
        _instance = this;

        m_thread = null;
        m_DCView = view;
        CEventWnd.setView(m_DCView);

        m_pCurShowWnd = null;
        m_pOldModaless = null;
        m_pOldFore = null;
    }
    
    public final void start() {

    		System.gc();
    	STD.logout("Staring");
    	m_thread = new Thread(this);
    	if( m_thread == null )
    		return;
    	m_thread.start();
    	STD.logout("EndStarting");
    	
    }
    public final void stop() {
    	if( m_thread == null )
    		return;
    	m_DCView.m_bReqThreadStop = true;
        boolean retry = true;
        while (retry) {
            try {
            	m_thread.join();
            	STD.logout("stopping");
                retry = false;
            } catch (InterruptedException e) {
            }
        }
    	m_thread = null;
    }
    public final void suspend() {
    	//stop();
    	
    		System.gc();
    	STD.logout("suspending");
    	if( m_thread == null )
    		return;
    	if( m_pCurShowWnd != null )
    		m_pCurShowWnd.OnSuspend();
    	STD.logout("endSuspending");
    }
    public final void resume() {
    	
    		System.gc();
    	STD.logout("resumestart");
    	if( m_thread == null )
    		return;
    	if( m_pCurShowWnd != null )
    		m_pCurShowWnd.OnResume();
    	STD.logout("resumeend");
    }
    public final void run() {
    	STD.logout("Running");
    	
    	Initialize();
    	if (m_DCView.m_bReqThreadStop) {
    		return;
    	}
    	runProc();
    	Finalize();
    	STD.logout("ENdRunning");
    }
    public final void SendMessage(int message, int wParam, int lParam) {
    	if( m_pCurShowWnd == null )
    		return;
    	m_pCurShowWnd.SendMessage(message, wParam, lParam);
    }

    public final CWnd GetCurWnd() {
        return m_pCurShowWnd;
    }
    public int SwitchWindow(int index) {
        return 0;
    }
    public int SwitchWindow(int index, int nParam) {
        return 0;
    }

    protected void Initialize() {
    	STD.logout("prepareDC");
    	m_DCView.prepareDC();
    	if (m_DCView.m_bReqThreadStop) {
    		return;
    	}
    	CEventWnd.prepareDC();
    	STD.logout("prepareDCEnd");
    }
    protected abstract void runProc();
    protected void Finalize() {
    	m_DCView.releaseDC();
    }
    protected abstract CWnd createWindow( int nWndID, int nParam );



    ///////////////////////////////////////////
    //
    // Common Window Event Process
    //
    ///////////////////////////////////////////
    protected final int NewWindow(int nWndID) {
        return NewWindow(nWndID, 0);
    }
    protected final int NewWindow(int nWndID, int nParam) {
        STD.logout("NewWindow");
    	m_pCurShowWnd = createWindow(nWndID, nParam);
        if( m_pCurShowWnd == null )
            return -1;
        int nRet = WndEventLoop(m_pCurShowWnd);
        m_pCurShowWnd = null;

System.gc();
STD.logout("NewWindowEND");        
return nRet;
        
    }
    private final int WndEventLoop(CWnd pWnd) {
    	STD.logout("EventLoop");
    	m_DCView.GLThread_run_initWindow(pWnd);

    	m_pCurShowWnd = pWnd;
        pWnd.SetActiveWnd(pWnd);

    	pWnd.OnLoadResource();
    	pWnd.OnInitWindow();
    	pWnd.OnShowWindow();
    	if (m_DCView.m_bSuspended)
    		pWnd.OnSuspend();
        int nRet = pWnd.RunProc();
        pWnd.OnDestroy();
        STD.logout("EventLoopEnd");
        return nRet;
    }
    
    public void onMultiTouchDown(int nPosX1, int nPosY1, int nPosX2, int nPosY2) {
    	if(m_pCurShowWnd != null)
    		m_pCurShowWnd.onMultiTouchDown(nPosX1, nPosY1, nPosX2, nPosY2);
    }
    
    public void onTouchDown(int nPosX, int nPosY) {
    	if(m_pCurShowWnd != null)
    		m_pCurShowWnd.onTouchDown(nPosX, nPosY);
    }
    
    public void onTouchMove(int nPosX, int nPosY) {
    	if(m_pCurShowWnd != null)
    		m_pCurShowWnd.onTouchMove(nPosX, nPosY);
    }
    
    public boolean onTouchUp(int nPosX, int nPosY) {
    	if(m_pCurShowWnd != null)
    		return m_pCurShowWnd.onTouchUp(nPosX, nPosY);
    	else
    		return false;
    }
    
    public void onFling(float velocityX, float velocityY) {
    	if(m_pCurShowWnd != null)
    		m_pCurShowWnd.onFling(velocityX, velocityY);
    }


    ///////////////////////////////////////////
    //
    // Switch Window Process
    //
    ///////////////////////////////////////////
    protected final int SwitchingWnd(int nWndID) {
        return SwitchingWnd(nWndID, 0);
    }
    protected final int SwitchingWnd(int nWndID, int nParam)
    {
        CWnd pNewWnd = createWindow(nWndID, nParam);
        int nRet = SwitchWindow_Proc(pNewWnd, m_pCurShowWnd);

        return nRet;
    }

    protected final void SwitchWinodw_Prepare() {
        m_pCurShowWnd.OnDestroy();
    }
    private final int SwitchWindow_Proc(CWnd pNewWnd, CWnd pBeforeWnd) {
        STD.logout("SwithWindow_Proc");
    	pNewWnd.SetParent(pBeforeWnd);
        int nRet = WndEventLoop(pNewWnd); // in here "m_pCurShowWnd = pNewWnd" is act.;
        m_pCurShowWnd = pBeforeWnd;
        STD.logout("SwithWindow_ProcEnd");
        return nRet;
    }
    protected final void SwitchWinodw_Finish() {
        m_pCurShowWnd.OnShowWindow();
    }


    ///////////////////////////////////////////
    //
    // Dialog Process
    //
    ///////////////////////////////////////////
    public final int DialogDoModal(CDialog pDialogWnd, CEventWnd pParent) {
        pDialogWnd.SetParent(pParent);
        boolean bEnable = pDialogWnd.GetParent().EnableWindow(false);

        CEventWnd pOldActive = pParent.SetActiveWnd(pDialogWnd);
        CEventWnd pOldFore = pParent.SetForegroundWnd(pDialogWnd);
        pDialogWnd.OnLoadResource();
        pDialogWnd.OnInitWindow();
        pDialogWnd.OnShowWindow();
        int nRet = pDialogWnd.RunProc();
        pDialogWnd.OnDestroy();

        pParent.SetForegroundWnd(pOldFore);
        pParent.SetActiveWnd(pOldActive);
        pDialogWnd.GetParent().EnableWindow(bEnable);

        return nRet;
    }
    public final void DialogModaless(CDialog pDialogWnd, CEventWnd pParent) {
        pDialogWnd.SetParent(pParent);
        m_pOldModaless = pParent.SetModalessWnd(pDialogWnd);
        m_pOldFore = pParent.SetForegroundWnd(pDialogWnd);
        pDialogWnd.OnLoadResource();
        pDialogWnd.OnInitWindow();
        pDialogWnd.OnShowWindow();
    }
    public final void DialogDestroy(CDialog pDialogWnd, CEventWnd pParent) {
        pParent.SetForegroundWnd(m_pOldFore);
        pParent.SetModalessWnd(m_pOldModaless);
        pDialogWnd.OnDestroy();
        pDialogWnd.GetParent().UpdateWindow();
    }
}
