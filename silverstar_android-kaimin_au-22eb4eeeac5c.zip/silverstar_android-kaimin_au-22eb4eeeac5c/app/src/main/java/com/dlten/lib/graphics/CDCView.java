package com.dlten.lib.graphics;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.graphics.Paint;
import android.view.Display;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.os.Handler;
import android.os.Message;
import android.text.TextPaint;
import android.util.AttributeSet;

import com.dlten.kaimin.kaimin;
import com.dlten.lib.STD;
import com.dlten.lib.frmWork.CEventWnd;
import com.dlten.lib.frmWork.CWnd;

public abstract class CDCView extends SurfaceView {

    // graphics relation
    private SurfaceHolder m_holder;
    private Canvas m_canvasUpdate = null;
    private Canvas m_canvas;
    private Bitmap m_bmpDblBuffer;

    private static Paint m_paintColor = new Paint();

	//public static int RES_WIDTH;
	//public static int RES_HEIGHT;

    public static int RES_WIDTH;
    public static int RES_HEIGHT;
	public static int SC_WIDTH;
	public static int SC_HEIGHT;
	public static int SC_VIEW_WIDTH;
	public static int SC_VIEW_HEIGHT;

	public static float m_fScale;
    public static int m_nDblOffsetX;
    public static int m_nDblOffsetY;
    public static float m_fPosScaleXFrom640;
    public static float m_fPosScaleYFrom960;

    public static float m_fOriginalScale;
    private static Paint m_paintBigSize = null;
    public static int m_nOriginalDblOffsetX;
    public static int m_nOriginalDblOffsetY;
    
    private float m_fAlpha;

    // font relation
    private Typeface m_fontStyle;
    private Paint m_font;
    private int m_nFontSize = 36;
    private int FONT_H;
    private int FONT_BASELINE;

	public static int[][] RES_SIZE_DATA 		= new int[][] {{640, 960}};
	public static int[][] RES_SIZE_DATA_SBTV 	= new int[][] {{960, 640}};			//kjh
	public static int m_nResSizeIndex;

    public static void setResSize(Handler context, TextPaint textPaint, int width, int height) {
    	
    	m_handlerTextView = context;
    	m_textPaint = textPaint;
		SC_WIDTH = width;
		SC_HEIGHT = height;
		
		if( kaimin.m_bSBTV ){
			
			float fCurScale = 0;
	    	int nOffsetSum = 0;
	    	for(int i = 0; i < RES_SIZE_DATA_SBTV.length; i ++) {
	    		RES_WIDTH = RES_SIZE_DATA_SBTV[i][0];
	    		RES_HEIGHT = RES_SIZE_DATA_SBTV[i][1];
	    		recalcScaleOffset();

	    		if(i == 0) {
	    			m_nResSizeIndex = i;
	    			fCurScale = m_fScale;
	    			nOffsetSum = m_nDblOffsetX + m_nDblOffsetY;
	    		}
	    		else {
	    			if(STD.ABS(1 - fCurScale) < STD.ABS(1 - m_fScale))
	    				continue;
	    			if(STD.ABS(1 - fCurScale) == STD.ABS(1 - m_fScale)) {
	    				if(nOffsetSum <= m_nDblOffsetX + m_nDblOffsetY)
	    					continue;
	    			}
	    			m_nResSizeIndex = i;
	    			fCurScale = m_fScale;
	    			nOffsetSum = m_nDblOffsetX + m_nDblOffsetY;
	    		}
	    	}

			RES_WIDTH = RES_SIZE_DATA_SBTV[m_nResSizeIndex][0];
			RES_HEIGHT = RES_SIZE_DATA_SBTV[m_nResSizeIndex][1];
			recalcScaleOffset();

	m_fOriginalScale = m_fScale;
	m_nOriginalDblOffsetX = m_nDblOffsetX;
	m_nOriginalDblOffsetY = m_nDblOffsetY;
	/*if ((m_nResSizeIndex == 0) && (m_fScale > 1)) {
		m_paintBigSize = new Paint();
		m_paintBigSize.setFilterBitmap(true);

		m_fScale = 1;
		m_nDblOffsetX = (SC_WIDTH - RES_WIDTH) / 2;
		m_nDblOffsetY = (SC_HEIGHT - RES_HEIGHT) / 2;
	}//*/

			SC_VIEW_WIDTH = SC_WIDTH - 2 * m_nDblOffsetX;
			SC_VIEW_HEIGHT = SC_HEIGHT - 2 * m_nDblOffsetY;

			CImgObj.setResSizeIndex(m_nResSizeIndex);
			COrgImage.setResScale((float)SC_VIEW_WIDTH / RES_WIDTH, (float)SC_VIEW_HEIGHT / RES_HEIGHT);

	        m_fPosScaleXFrom640 = RES_HEIGHT / 640.0f;
			m_fPosScaleYFrom960 = RES_WIDTH / 960.0f;

	        float size;// = m_textPaint.getTextSize();
	        size = 36 * m_fPosScaleXFrom640;
	        m_textPaint.setTextSize(size);
		}
		else{
			float fCurScale = 0;
	    	int nOffsetSum = 0;
	    	for(int i = 0; i < RES_SIZE_DATA.length; i ++) {
	    		RES_WIDTH = RES_SIZE_DATA[i][0];
	    		RES_HEIGHT = RES_SIZE_DATA[i][1];
	    		recalcScaleOffset();

	    		if(i == 0) {
	    			m_nResSizeIndex = i;
	    			fCurScale = m_fScale;
	    			nOffsetSum = m_nDblOffsetX + m_nDblOffsetY;
	    		}
	    		else {
	    			if(STD.ABS(1 - fCurScale) < STD.ABS(1 - m_fScale))
	    				continue;
	    			if(STD.ABS(1 - fCurScale) == STD.ABS(1 - m_fScale)) {
	    				if(nOffsetSum <= m_nDblOffsetX + m_nDblOffsetY)
	    					continue;
	    			}
	    			m_nResSizeIndex = i;
	    			fCurScale = m_fScale;
	    			nOffsetSum = m_nDblOffsetX + m_nDblOffsetY;
	    		}
	    	}

			RES_WIDTH = RES_SIZE_DATA[m_nResSizeIndex][0];
			RES_HEIGHT = RES_SIZE_DATA[m_nResSizeIndex][1];
			recalcScaleOffset();

	m_fOriginalScale = m_fScale;
	m_nOriginalDblOffsetX = m_nDblOffsetX;
	m_nOriginalDblOffsetY = m_nDblOffsetY;
	/*if ((m_nResSizeIndex == 0) && (m_fScale > 1)) {
		m_paintBigSize = new Paint();
		m_paintBigSize.setFilterBitmap(true);

		m_fScale = 1;
		m_nDblOffsetX = (SC_WIDTH - RES_WIDTH) / 2;
		m_nDblOffsetY = (SC_HEIGHT - RES_HEIGHT) / 2;
	}//*/

			SC_VIEW_WIDTH = SC_WIDTH - 2 * m_nDblOffsetX;
			SC_VIEW_HEIGHT = SC_HEIGHT - 2 * m_nDblOffsetY;

			CImgObj.setResSizeIndex(m_nResSizeIndex);
			COrgImage.setResScale((float)SC_VIEW_WIDTH / RES_WIDTH, (float)SC_VIEW_HEIGHT / RES_HEIGHT);

	        m_fPosScaleXFrom640 = RES_WIDTH / 640.0f;
			m_fPosScaleYFrom960 = RES_HEIGHT / 960.0f;

	        float size;// = m_textPaint.getTextSize();
	        size = 36 * m_fPosScaleXFrom640;
	        m_textPaint.setTextSize(size);
		}
    	
		
    }

    private static void recalcScaleOffset() {
    	float fScaleWidth = (float)SC_WIDTH / RES_WIDTH;
		float fScaleHeight = (float)SC_HEIGHT / RES_HEIGHT;
		if(fScaleWidth < fScaleHeight) {
			m_fScale = fScaleWidth;
        	m_nDblOffsetX = 0;
        	m_nDblOffsetY = (SC_HEIGHT - RES_HEIGHT * SC_WIDTH / RES_WIDTH) / 2;
		}
		else {
			m_fScale = fScaleHeight;
        	m_nDblOffsetX = (SC_WIDTH - RES_WIDTH * SC_HEIGHT / RES_HEIGHT) / 2;
        	m_nDblOffsetY = 0;
		}
    }
    
    public static float wnd2sc( float wndPixel ) {
    	float fRet = wndPixel;
    	
    	fRet *= m_fPosScaleYFrom960;
    	fRet *= m_fScale;
    	
    	return fRet;
    }
    
    public CDCView(Context context) {
        super(context);

        initCBaseView();
    }
/*    public CDCView( Context context, AttributeSet attrs )
	{
		super( context, attrs );

		initCBaseView();
	}*/
    private void initCBaseView() {
		m_holder = getHolder();
        m_holder.setType(SurfaceHolder.SURFACE_TYPE_GPU);

        // make font
        m_fontStyle = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL);
        m_font = new Paint();
        m_font.setTypeface(m_fontStyle);

        //kjh start
        if( kaimin.m_bSBTV ){
        	m_font.setTextSize( m_nFontSize );
        }else
        	m_font.setTextSize(m_nFontSize * m_fScale * RES_WIDTH / 640f);
        //kjh end
        
        FONT_BASELINE = (int) m_font.getFontMetrics().descent;
        FONT_H = (int) (m_font.getFontMetrics().top - m_font.getFontMetrics().bottom);
        setFont(m_font);
    }
    public void prepareDC() {
        // make double buffer
        m_bmpDblBuffer = Bitmap.createBitmap(SC_VIEW_WIDTH, SC_VIEW_HEIGHT, Bitmap.Config.RGB_565);
        m_canvas = new Canvas(m_bmpDblBuffer);
//        kjh start
//        m_paintColor.setARGB(200, 50, 50, 50);
        m_paintColor.setARGB(0, 0, 0, 255);
//        kjh end
        fillRect(0, 0, SC_VIEW_WIDTH, SC_VIEW_HEIGHT);
        m_paintColor.setAntiAlias(true);
        // m_paintColor.setDither(true);
    }
    
    //////////////////////////////////////////////////////////////////
    // All of UI callback functions
    ////////////////////////////////////////////////////////////////// 

	// implementing update.
    synchronized public final void update( CEventWnd pWnd ) {
    	
    	
    	if( pWnd == null )
    		return;
    	Canvas canvasTemp;
    	canvasTemp = m_holder.lockCanvas();
        if( canvasTemp == null ) {
        	STD.ASSERT(false);
        	return;
        }

        m_canvasUpdate = canvasTemp;
        
        try {
        	clear();
        	pWnd.DrawPrevProc();
        	pWnd.DrawProcess();
        } catch (Exception e) {
        	STD.printStackTrace(e);
        }
        
        pWnd.onDrawText();
        
        pWnd.onLastDraw();
        
        updateGraphics();
        
    	m_holder.unlockCanvasAndPost(m_canvasUpdate);
        m_canvasUpdate = null;
    }
///*
    private Rect m_rtTSrc = new Rect();
    private Rect m_rtTDst = new Rect();
    protected final void updateGraphics() {
    	m_rtTSrc.left   = 0;
    	m_rtTSrc.top    = 0;
    	m_rtTSrc.right  = SC_VIEW_WIDTH;
    	m_rtTSrc.bottom = SC_VIEW_HEIGHT;

    	if (m_paintBigSize == null) {
	    	m_rtTDst.left   = m_nDblOffsetX;
	    	m_rtTDst.top    = m_nDblOffsetY;
	    	m_rtTDst.right  = SC_WIDTH - m_nDblOffsetX;
	    	m_rtTDst.bottom = SC_HEIGHT - m_nDblOffsetY;
    	}
    	else {
    		m_rtTDst.left   = m_nOriginalDblOffsetX;
	    	m_rtTDst.top    = m_nOriginalDblOffsetY;
	    	m_rtTDst.right  = SC_WIDTH - m_nOriginalDblOffsetX;
	    	m_rtTDst.bottom = SC_HEIGHT - m_nOriginalDblOffsetY;
    	}

    	if(m_fAlpha != 1) {
    		int nOldARGB = m_paintColor.getColor();
    		m_paintColor.setColor(0);
    		m_paintColor.setAlpha((int)((1 - m_fAlpha) * 255));
    		fillRect(0, 0, SC_VIEW_WIDTH, SC_VIEW_HEIGHT);
    		m_paintColor.setColor(nOldARGB);
    	}
        m_canvasUpdate.drawBitmap(m_bmpDblBuffer, m_rtTSrc, m_rtTDst, m_paintBigSize);
    	
        
    }//*/
/*
    private Rect m_rtTSrc = new Rect();
    private Rect m_rtTDst = new Rect();
    protected final void updateGraphics() {

    	Matrix matrix = new Matrix();
    	float fScaleX = (float)(SC_WIDTH - 2 * m_nDblOffsetX) / RES_WIDTH;
    	float fScaleY = (float)(SC_HEIGHT - 2 * m_nDblOffsetY) / RES_HEIGHT;
        matrix.postScale(fScaleX, fScaleY);
        Bitmap bmp = Bitmap.createBitmap(m_bmpDblBuffer, 0, 0, RES_WIDTH, RES_HEIGHT, matrix, true);

        m_rtTSrc.left   = 0;
    	m_rtTSrc.top    = 0;
    	m_rtTSrc.right  = SC_WIDTH - 2 * m_nDblOffsetX;
    	m_rtTSrc.bottom = SC_HEIGHT - 2 * m_nDblOffsetY;
        
    	m_rtTDst.left   = m_nDblOffsetX;
    	m_rtTDst.top    = m_nDblOffsetY;
    	m_rtTDst.right  = SC_WIDTH - m_nDblOffsetX;
    	m_rtTDst.bottom = SC_HEIGHT - m_nDblOffsetY;

    	if(m_fAlpha != 1) {
    		int nOldARGB = m_paintColor.getColor();
    		m_paintColor.setColor(0);
    		m_paintColor.setAlpha((int)((1 - m_fAlpha) * 255));
    		fillRect(0, 0, SC_VIEW_WIDTH, SC_VIEW_HEIGHT);
    		m_paintColor.setColor(nOldARGB);
    	}

    	m_canvasUpdate.drawBitmap(m_bmpDblBuffer, m_rtTSrc, m_rtTDst, null);
    }
//*/
    // Drawing to Graphics relation
/*    public final int[] getRGBData( int x, int y, int w, int h ) {
    	try {
	    	Bitmap imgTarget = m_bmpDblBuffer; // this.getDrawingCache();
	    	return CBmpManager.getRGBData(imgTarget, x, y, w, h);
    	} catch (Exception e) {
    		e.printStackTrace();
    		return null;
    	}
    }*/
/*    private Bitmap bmpBackup = null;
    public final void captureDisp() {
    	bmpBackup = Bitmap.createBitmap(m_bmpDblBuffer); //this.getDrawingCache();
    }
    public final void restoreDisp() {
    	if( bmpBackup != null )
    		m_canvas.drawBitmap(bmpBackup, 0, 0, null);
    }*/

    public final void clear() {
        clear(0x303030);
        setAlpha(1.0f);
    }
    public final void clear( int nColor ) {
        setColor(nColor);
        fillRect(0, 0, SC_VIEW_WIDTH, SC_VIEW_HEIGHT);
    }
    
    // Original Image Drawing.
    public final void drawImage( Bitmap img, float fPosX, float fPosY ) {
        if ( img == null )
            return;
        m_canvas.drawBitmap(img, fPosX * m_fScale, fPosY * m_fScale, m_paintColor);
    }
/*    public final void drawImage( Bitmap img, Rect rtSrc, RectF rtDest ) {
        if ( img == null )
            return;
        m_canvas.drawBitmap(img, rtSrc, rtDest, m_paintColor);
    }*/
    public final void drawImage( Bitmap img, Matrix matrix ) {
    	m_canvas.drawBitmap(img, matrix, m_paintColor);
    }
/*    private Rect m_rtSrc = new Rect();
    private RectF m_rtDst = new RectF();
    public final void drawImage( Bitmap img, CRect rtSrc, CRect rtDest ) {
        if ( img == null )
            return;
        if( rtSrc == null || rtDest == null )
        	return;
        
        m_rtSrc.set((int)rtSrc.left, (int)rtSrc.top, 
        		(int)(rtSrc.left+rtSrc.width), (int)(rtSrc.top+rtSrc.height));
        m_rtDst.set(rtDest.left, rtDest.top, 
        		rtDest.left+rtDest.width, rtDest.top+rtDest.height);
        m_canvas.drawBitmap(img, m_rtSrc, m_rtDst, m_paintColor);
    }*/

/*    protected final void setClip(int[] rect ) {
        setClip(rect[0], rect[1], rect[2], rect[3]);
    }
    protected final void setClip(int x, int y, int width, int height) {
        m_canvas.clipRect(x + m_nWndOffsetX, y + m_nWndOffsetY, 
        		x + m_nWndOffsetX + width, y + m_nWndOffsetY + height, Region.Op.REPLACE);
    }
    protected final void clearClip() {
    	m_canvas.clipRect(m_nWndOffsetX, m_nWndOffsetY, 
    			m_nWndOffsetX+ REAL_WIDTH, m_nWndOffsetY + REAL_HEIGHT, Region.Op.REPLACE);
    }*/
/*    protected final void copyArea(int x, int y, int width, int height, 
    		int dx, int dy) {
    	copyArea(x, y, width, height, dx, dy, ANCHOR_LEFT | ANCHOR_TOP );
    }
    protected final void copyArea(int x, int y, int width, int height, 
    		int dx, int dy, int nAnchor) {
    	x += m_nWndOffsetX;
    	y += m_nWndOffsetY;
    	dx += m_nWndOffsetX;
    	dy += m_nWndOffsetY;
    	
    	int[] imgData = getRGBData(x, y, width, height);
    	float[] offset = CBmpManager.getLeftTopPos(width, height, nAnchor);
    	m_canvas.drawBitmap(imgData, 0, width, 
    			dx+offset[0], dy+offset[1], 
    			width, height, true, null);
    }*/
/*    public final void setLineWidth( float nWidth ) {
    	m_paintColor.setStrokeWidth(nWidth);
    }
    public final void drawLine( float nLeft, float nTop, float nRight, float nBottom ) {
        m_canvas.drawLine( nLeft + m_nWndOffsetX, nTop + m_nWndOffsetY,
                nRight + m_nWndOffsetX, nBottom + m_nWndOffsetY, m_paintColor );
    }*/
/*    protected final void drawRect( int[] rect ) {
    	drawRect( rect[0], rect[1], rect[2], rect[3] );
    }
    protected final void drawRect( int nLeft, int nTop, int nWidth, int nHeight ) {
    	m_paintColor.setStyle(Paint.Style.STROKE);
    	m_paintColor.setStrokeWidth(1);
        m_canvas.drawRect( nLeft + m_nWndOffsetX, nTop + m_nWndOffsetY,
        		nLeft + m_nWndOffsetX + nWidth, nTop + m_nWndOffsetY + nHeight, m_paintColor );
    }*/
/*    protected final void fillRect( int[] rect ) {
    	fillRect( rect[0], rect[1], rect[2], rect[3] );
    }*/
    protected final void fillRect( int nLeft, int nTop, int nWidth, int nHeight ) {
//    	m_paintColor.setStyle(Paint.Style.FILL);
        m_canvas.drawRect( nLeft, nTop, nLeft + nWidth, nTop + nHeight, m_paintColor );
    }
    public final void setColor( int nColor ) {
        int nR = (nColor >>> 16) & 0xFF;
        int nG = (nColor >>> 8) & 0xFF;
        int nB = nColor & 0xFF;

        setColor( nR, nG, nB );
    }
    public final void setColor( int nR, int nG, int nB ) {
    	setARGB(0xFF, nR, nG, nB);
    }
    public final void setARGB( int nAlpha, int nR, int nG, int nB ) {
    	m_paintColor.setARGB(nAlpha, nR, nG, nB);
    }
    public final void setAlpha( int nAlpha ) {
    	m_paintColor.setAlpha(nAlpha);
    }
/*    public final void setRotate( float fDegress ) {
    	setRotate( fDegress, 0, 0 );
    }
    public final void setRotate( float fDegress, int x, int y ) {
    	m_canvas.rotate(fDegress, x, y);
    }*/

    

    // ===== Old Text =====
    /*public final int setFontSize(int nSize) {
    	int	nOldSize = m_nFontSize;
    	
    	if (m_nFontSize != nSize) {
        	m_nFontSize = nSize;
    		setFont();
    	}
    	return nOldSize;
    }
    public final int getFontSize() {
    	return m_nFontSize;
    }*/
    protected final void setFont( Paint font ) {
        m_font = font;
    	if( m_font == null )
    		return;
        FONT_H =  (int) m_font.getTextSize();
        FONT_BASELINE = (int) m_font.ascent();
    }
    /*protected final void setFont() {
    	m_font.setTextSize(m_nFontSize);
        setFont(m_font);
    }*/
    public final Paint getFont() {
        return m_font;
    }
    /*protected final int getFontWidth( Paint font ) {
    	float[] fWidth = new float[1];
    	font.getTextWidths("W", fWidth);
        return (int) (fWidth[0]);
    }*/
    /*protected final int getStrWidth( String str ) {
    	if( m_font == null || str == null || str.length() <= 0 )
    		return 0;

    	float fRet = 0;
    	float[] fWidth = new float[str.length()];
    	m_font.getTextWidths(str, fWidth);
    	for( int i = 0 ; i < fWidth.length ; i++ )
    		fRet += fWidth[i];
    	
    	return (int) fRet;
    }*/

/*    public int splitString( String strBook, String[] strLine, int width ) {
    	if( m_font == null || strBook == null || strLine == null || strBook.length() <= 0 )
    		return 0;

    	int nLineCount = 0;
    	while(strBook.length() > 0) {
    		int nChar = m_font.breakText (strBook, true, width * m_fScale, null);
    		String strL = strBook.substring(0, nChar);
    		int nRet = strL.indexOf("\n");
    		if(nRet >= 0) {
    			strLine[nLineCount] = strBook.substring(0, nRet);
    			strBook = strBook.substring(nRet + 1);
    		}
    		else {
    			strLine[nLineCount] = strBook.substring(0, nChar);
    			strBook = strBook.substring(nChar);
    		}
    		nLineCount ++;
    	}
		STD.logout("LineCount=" + nLineCount);
    	return nLineCount;
    }*/

    public void splitString( String strBook, ArrayList<String> strLine, int width ) {
    	if( m_font == null || strBook == null || strLine == null || strBook.length() <= 0 )
    		return;
    	
    	// SKY:120626:start
    	strBook = strBook.replaceAll("\r\n", "\n");
    	// SKY:end
    	
    	String str = "自分はすすぐことの出来ぬ汚れを身に受けたそれほどの辱を人に加えることはあの外記でなくては出来まい";
    	int nStrChar = m_font.breakText (str, true, width * m_fScale, null);
    	
//    	int nCount = 0;
    	
    	while(strBook.length() > 0 /*&& nCount < 30*/) {
//    		int nChar = m_font.breakText (strBook, true, width * m_fScale, null);
    		int nStrLen = strBook.length();
    		int nChar;
    		if (nStrLen > nStrChar)
    			nChar = nStrChar;
    		else
    			nChar = nStrLen;
    		// SKY:120624:start
    		if ( nStrLen > (nChar+1) ) {
        		String nextChar = strBook.substring(nChar, nChar+1);
        		boolean bSym = false; 
        		if ( ! bSym )
        			bSym = nextChar.equalsIgnoreCase("。");
        		if ( ! bSym )
        			bSym = nextChar.equalsIgnoreCase("、");
        		if ( ! bSym )
        			bSym = nextChar.equalsIgnoreCase("）");
        		// SKY:120626:start
        		if ( ! bSym )
        			bSym = nextChar.equalsIgnoreCase("」");
        		if ( ! bSym )
        			bSym = nextChar.equalsIgnoreCase("】");
        		if ( ! bSym )
        			bSym = nextChar.equalsIgnoreCase("』");
        		// SKY:end
        		if ( bSym ) {
        			nChar ++;
        		}
    		}
    		// SKY:end
    		
    		String strL = strBook.substring(0, nChar);
    		int nRet = strL.indexOf("\n");
    		if(nRet >= 0) {
    			strLine.add(strBook.substring(0, nRet));
    			strBook = strBook.substring(nRet + 1);
    		}
    		else {
    			
    			strLine.add(strBook.substring(0, nChar));
    			
    			// SKY:120625:start
    			if ( nStrLen > (nChar+1) ) {
            		String nextStr = strBook.substring(nChar, nChar + 1);
            		if ( nextStr.equalsIgnoreCase("\n") )
            			nChar ++;
    			}
    			// SKY:end
    			strBook = strBook.substring(nChar);
    		}
    		
//    		nCount ++;
    	}
    	
    }

/*    public int breakText(String strText, int start, int end, int width) {
    	if( m_font == null || strText == null || strText.length() <= 0 )
    		return 0;
   		return m_font.breakText (strText, start, end, true, width * m_fScale, null);
    }*/
    
    // String drawing
    public final void drawString( String str, int nPosX, int nPosY ) {
    	drawString(str, nPosX, nPosY, ANCHOR_LEFT | ANCHOR_TOP );
    }
    public final void drawString( String str, float nPosX, float nPosY, int nAnchor ) {
        if( str == null )
            return;
        
        int nGap = 0;
        int nHAnchor = nAnchor & ANCHOR_H_FILTER;
        Paint.Align newAlign;
        if( nHAnchor == ANCHOR_RIGHT )
        	newAlign = Paint.Align.RIGHT;
        else if (nHAnchor == ANCHOR_HCENTER )
        	newAlign = Paint.Align.CENTER;
        else
        	newAlign = Paint.Align.LEFT;
        m_font.setTextAlign(newAlign);

        if( (nAnchor & ANCHOR_VCENTER) != 0 ) {
            nAnchor = nAnchor & (~ANCHOR_VCENTER) | ANCHOR_BOTTOM;
            nGap = -FONT_BASELINE-FONT_H/2;
        }
        else if( (nAnchor & ANCHOR_BOTTOM) != 0 ) {
            nAnchor = nAnchor & (~ANCHOR_BOTTOM) | ANCHOR_BOTTOM;
            nGap = -FONT_BASELINE-FONT_H;
        }
        else { // if( (nAnchor & ANCHOR_TOP) != 0 ) {
            nAnchor = nAnchor & (~ANCHOR_TOP) | ANCHOR_BOTTOM;
            nGap = -FONT_BASELINE;
        }
//        nPosY = nPosY + nGap;

        m_font.setColor(m_paintColor.getColor());
        m_font.setAntiAlias(true);

//        m_canvas.drawText(str, nPosX + m_nWndOffsetX, nPosY + m_nWndOffsetY, m_font);
//        m_canvasUpdate.drawText(str, nPosX * m_fScale + m_nDblOffsetX, nPosY * m_fScale + m_nDblOffsetY + nGap, m_font);
        m_canvas.drawText(str, nPosX + m_nDblOffsetX, nPosY + m_nDblOffsetY + nGap, m_font);
    }
    ///////////////////////////////////////////////////////
    
    // ===== New Text =====
	public final static int
		TEXTVIEW_SETPADDING = 0,
		TEXTVIEW_SETTEXT = 1,
		TEXTVIEW_GETINFO = 2,
		TEXTVIEW_SETSCROLL = 3,
		TEXTVIEW_CLEAR = 4,
		DLG_SHOW = 5;
    private static Handler m_handlerTextView = null;
    private static TextPaint m_textPaint = null;
    private String m_TextViewStr;
    public int m_nTextViewLineCount;
    public float m_fTextTotalHeight;
    public void setTextViewPosition(int left, int top, int width, int height) {
    	left = (int)(left * m_fScale + m_nDblOffsetX);
    	top = (int)(top * m_fScale + m_nDblOffsetY);
    	width = (int)(width * m_fScale);
    	height = (int)(height * m_fScale);
    	int[] pos = new int[] {left, top, SC_WIDTH-left-width, SC_HEIGHT-top-height};
    	m_handlerTextView.sendMessage(Message.obtain(m_handlerTextView, TEXTVIEW_SETPADDING, pos));
    }
    public void setTextViewString(String text) {
    	m_TextViewStr = text;
    	setTextViewInfo(0, 0);
    	m_handlerTextView.sendMessage(Message.obtain(m_handlerTextView, TEXTVIEW_SETTEXT));
    }
    public void clearTextView() {
    	m_handlerTextView.sendMessage(Message.obtain(m_handlerTextView, TEXTVIEW_CLEAR));
    }
    public String getTextViewString() {
    	return m_TextViewStr;
    }
    public void setTextViewInfo(int nTextViewLineCount, float fTextTotalHeight) {
    	m_nTextViewLineCount = nTextViewLineCount;
    	m_fTextTotalHeight = fTextTotalHeight;
    }
    public int getTextViewLineCount() {
    	if(m_nTextViewLineCount == 0) {
        	m_handlerTextView.sendMessage(Message.obtain(m_handlerTextView, TEXTVIEW_GETINFO));
    	}
    	return m_nTextViewLineCount;
    }
    public float getTextViewTotalHeight() {
    	return m_fTextTotalHeight;
    }
    public void setTextViewScroll(int nX, int nY) {
    	int[] pos = new int[] {nX, nY};
    	m_handlerTextView.sendMessage(Message.obtain(m_handlerTextView, TEXTVIEW_SETSCROLL, pos));
    }
	
	public void showDialog(int nDlgID) {
		int[] pos = new int[] {nDlgID};
		m_handlerTextView.sendMessage(Message.obtain(m_handlerTextView, DLG_SHOW, pos));
	}
    ///////////////////////////////////////////////////////*/

    
    
    // drawing relation
    public static final int ANCHOR_TOP = CBmpManager.ANCHOR_TOP;
    public static final int ANCHOR_MIDDLE = CBmpManager.ANCHOR_MIDDLE;
    public static final int ANCHOR_VCENTER = CBmpManager.ANCHOR_MIDDLE;
    public static final int ANCHOR_BOTTOM = CBmpManager.ANCHOR_BOTTOM;
    public static final int ANCHOR_LEFT = CBmpManager.ANCHOR_LEFT;
    public static final int ANCHOR_HCENTER = CBmpManager.ANCHOR_CENTER;
    public static final int ANCHOR_CENTER = CBmpManager.ANCHOR_CENTER;
    public static final int ANCHOR_RIGHT = CBmpManager.ANCHOR_RIGHT;

    public static final int ANCHOR_V_FILTER = CBmpManager.ANCHOR_V_FILTER;
    public static final int ANCHOR_H_FILTER = CBmpManager.ANCHOR_H_FILTER;

    public void releaseDC() {};
    public void GLThread_run_initWindow(CWnd pWnd) {};
    public void initializeTexture(int nTextureCount) {};
    public int createTexture(int nTextureIndex, int width, int height) { return 0; };
    public void finalizeTexture() {};
    public void deleteTexture() {};
	public void setAlpha(float fAlpha) { m_fAlpha = fAlpha; };
	public void GLThread_onWindowResize(int w, int h) {};
	public void GLThread_surfaceCreated() {};
	public void GLThread_surfaceDestroyed() {};
	public void GLThread_onWindowFocusChanged(boolean hasFocus) {};
	public void copyBitmap(Bitmap bmp, int nTextureIndex, int xpos, int ypos, CRect rectTexture) {};
	public final void drawImage( int nTextureIndex, float x, float y, float w, float h, float scaleX, float scaleY, CRect rectTexture ) {};
}
