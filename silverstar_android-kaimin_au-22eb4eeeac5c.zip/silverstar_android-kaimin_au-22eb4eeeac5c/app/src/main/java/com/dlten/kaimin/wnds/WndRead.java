package com.dlten.kaimin.wnds;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import android.graphics.Paint;
import android.util.Log;

import com.dlten.kaimin.Globals;
import com.dlten.kaimin.frmWndMgr;
import com.dlten.kaimin.kaimin;
import com.dlten.lib.CBaseView;
import com.dlten.lib.STD;
import com.dlten.lib.file.CResFile;
import com.dlten.lib.frmWork.CButton;
import com.dlten.lib.frmWork.CWnd;
import com.dlten.lib.graphics.CDCView;
import com.dlten.lib.graphics.CImgObj;

public class WndRead extends WndTimer {

	private int m_nStep;
	private	long	m_timeProc;

	private	long m_timePauseStart = 0;
	private	boolean m_bPauseFinished = false;

	private int m_nAuto = 1;
	private int m_nSpeed = 2;

	private static long OPEN_FRAME_COUNT = 20;
	private static long CLOSE_FRAME_COUNT = 20;

	private CImgObj m_imgBg   			= new CImgObj();
	private CImgObj m_imgMenuBg   		= new CImgObj();
	private CImgObj m_imgScrollbar   	= new CImgObj();
	private CImgObj m_imgMenuNor   		= new CImgObj();
	private CImgObj m_imgMenuFoc   		= new CImgObj();

	private CImgObj[] m_imgAutoNor   	= new CImgObj[2];
	private CImgObj[] m_imgAutoFoc   	= new CImgObj[2];
	private CImgObj[] m_imgSpeedNor   	= new CImgObj[5];
	private CImgObj[] m_imgSpeedFoc   	= new CImgObj[5];

	private boolean m_bScrolled = false;
	private int m_nScrollStatus = 0;
	private CImgObj[] m_imgScrollBtn   = new CImgObj[2];
	private int m_nScrollBtnY = 50;
	private int m_nTouchOldPosYForScrollButton;
	private int m_nScrollOldPosY;
	
	private boolean m_bTouched = false;
	private int m_nPrevTouchEventPosY;
	private int m_nScrollPtByTouchMove = 0;

	private float m_fFlingVelocity = 0;
	private long m_timeFlingPrev;
	private float m_fFlingStartLine;
	private float m_fFlingEndLine;

	private int m_nLineCount;
	private ArrayList<String> m_strLineArray;
	private float m_fCurLine;
	private long m_timePrev;
	private boolean m_bIsStarting = true;

	private static float LINE_HEIGHT;
	private static int LINE_HEIGHT_PIXEL;
	private static int LINE_PER_PAGE = 20; // = VIEW_HEIGHT / LINE_HEIGHT
	private static int VIEW_WIDTH = 540;
	private static int VIEW_HEIGHT = 800;
	private static int VIEW_POS_X = 30;
	private static int VIEW_POS_Y = 40;

	private CButton	m_btnAuto = null;
	private CButton	m_btnSpeed  = null;
	private CButton	m_btnMenu  = null;
	
	//by LYM 2013/01/12_start_<
//	String m_strBook = "";
//	
//    Timer timer = new Timer();
//    TimerTask task = new TimerTask(){  
//        public void run() {  
//        	OnTimer();  
//        }  
//    };
    //LYM_end_>
	
	private static final int
		CMD_AUTO = 0,
		CMD_SPEED  = 1,
		CMD_MENU_ASYNC      = 2,
		CMD_SELECT_CLOSE = 3;

    private static final String[] BOOK_FILENAME = new String[]
                                                             {"abe_ichizoku.txt", "gakumonno_susume.txt", "kazeno_matasaburo.txt", "ningen_shikkaku.txt"};

    private static final float[] LINE_PER_SECOND = new float[]
          {0.2f, 0.35f, 0.5f, 0.65f, 0.8f};

    // SKY:120615:start
    private static final String[] BOOK_FILENAME_LAW = new String[]
          {"law1.txt", "law2.txt", "law3.txt", "law4.txt", "law5.txt", "law6.txt"};
    private boolean m_bLaw = false;
    
	   //kjh start
	private static final int	BTN_FOCUS_AUTO				=	100;
	private static final int	BTN_FOCUS_MENU				=	101;
	private static final int	BTN_FOCUS_SPEED				=	102;
	
	public int					m_nCurFoucus	=	-1;
	
	public void initFocusBtns(){
			if( m_btnMenu != null )
				m_btnMenu.setNormal();
			if( m_btnSpeed != null )
				m_btnSpeed.setNormal();
			if( m_btnAuto != null )
				m_btnAuto.setNormal();
	}
	
	public void updateFocusBtns( int nFocusBtn ){

		if( !kaimin.m_bSBTV )
			return;
		
//		if( m_nCurFoucus == nFocusBtn )
//			return;
		try {
			
			initFocusBtns();
			
			switch ( nFocusBtn ) {
				case BTN_FOCUS_MENU:
					if( m_btnMenu != null )
						m_btnMenu.setFocus();
	//				m_Btns.setFocusState( true );
					break;
				case BTN_FOCUS_SPEED:
	//				m_btnOption.setFocusState( true );
					if( m_btnSpeed != null ){
						if( m_btnSpeed.getVisible() )
							m_btnSpeed.setFocus();
					}
					break;
				case BTN_FOCUS_AUTO:
					//m_btnOption.setFocusState( true );
					if( m_btnAuto != null ){
						if( m_btnAuto.getVisible() )
							m_btnAuto.setFocus();
					}
					break;
			default:
				break;
			}	
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		m_nCurFoucus	=	nFocusBtn;
	}
	//kjh end
    public WndRead( boolean bLaw ) {
    	super();
    	
    	m_bLaw = bLaw;
    }
    // SKY:end
    
	public void OnLoadResource() {
		//setString("Text Wnd");
		Globals.m_bBGMDisable = false;
		Globals.m_bSEDisable = true;
		if (m_bLaw)
			Globals.playBGM(Globals.m_nBGMType_WndLaw);
		else
			Globals.playBGM(Globals.m_nBGMType_WndRead);
		
		createImages();
		
		super.OnLoadResource();
	}
	
	public void OnInitWindow() {
		int real_width = CDCView.RES_WIDTH;
		int real_height = CDCView.RES_HEIGHT;
		
		//kjh start
		if( kaimin.m_bSBTV ){
			
//			VIEW_POS_X = (int) (25f/*30*/ * 1080f / 640f);// SKY:120624
			VIEW_POS_X = (int) 0;// KJH:120624
			VIEW_POS_Y = (int) (40f * 720f / 960f);
			VIEW_WIDTH = ( int )( 1080.f - VIEW_POS_X  - 250.f );			//KJH:121122
			VIEW_HEIGHT = ( int )( 500 );
			LINE_HEIGHT = 40.0f;
			LINE_HEIGHT_PIXEL = (int)(LINE_HEIGHT * CDCView.m_fScale + 0.5f);
			LINE_HEIGHT = LINE_HEIGHT_PIXEL / CDCView.m_fScale;
			LINE_PER_PAGE = (int) (VIEW_HEIGHT / LINE_HEIGHT);			
			
		}else{
			VIEW_POS_X = 25/*30*/ * real_width / 640;// SKY:120624
			VIEW_POS_Y = 0 * real_height / 960;
			VIEW_WIDTH = 540 * real_width / 640;
			VIEW_HEIGHT = 800 * real_height / 960;
			LINE_HEIGHT = 40.0f * real_height / 960.0f;
			LINE_HEIGHT_PIXEL = (int)(LINE_HEIGHT * CDCView.m_fScale + 0.5f);
			LINE_HEIGHT = LINE_HEIGHT_PIXEL / CDCView.m_fScale;
			LINE_PER_PAGE = (int) (VIEW_HEIGHT / LINE_HEIGHT);			
		}
		//kjh end

		readBook();
		m_nStep = 0;
		m_timeProc = STD.GetTickCount();

		m_fCurLine = 0;
		m_bIsStarting = true;
	}
	public void OnShowWindow() {
	}
	
	private void createImages() {
		if( kaimin.m_bSBTV ){
			m_imgBg.load("COMN/COMN_background_sbtv_landscape.png");
		}else{
			m_imgBg.load("COMN/COMN_background.png");	
		}
		
		m_imgMenuBg.load("COMN/COMN_menu_back.png", kaimin.m_bSBTV );
		m_imgScrollbar.load("B1/B1_scroll_bar.png", kaimin.m_bSBTV );

		m_imgMenuNor.load("COMN/COMN_btn_menu_1.png", kaimin.m_bSBTV );
//		m_imgMenuFoc.load("COMN/COMN_btn_menu_2.png");

		m_imgAutoNor[0] = new CImgObj("B1/B1_btn_auto_off_1.png", kaimin.m_bSBTV);
//		m_imgAutoFoc[0] = new CImgObj("B1/B1_btn_auto_off_2.png");

		m_imgAutoNor[1] = new CImgObj("B1/B1_btn_auto_on_1.png", kaimin.m_bSBTV);
//		m_imgAutoFoc[1] = new CImgObj("B1/B1_btn_auto_on_2.png");

		m_imgSpeedNor[0] = new CImgObj("B1/B1_btn_speed_1_1.png", kaimin.m_bSBTV);
//		m_imgSpeedFoc[0] = new CImgObj("B1/B1_btn_speed_1_2.png");

		m_imgSpeedNor[1] = new CImgObj("B1/B1_btn_speed_2_1.png", kaimin.m_bSBTV);
//		m_imgSpeedFoc[1] = new CImgObj("B1/B1_btn_speed_2_2.png");

		m_imgSpeedNor[2] = new CImgObj("B1/B1_btn_speed_3_1.png", kaimin.m_bSBTV);
//		m_imgSpeedFoc[2] = new CImgObj("B1/B1_btn_speed_3_2.png");

		m_imgSpeedNor[3] = new CImgObj("B1/B1_btn_speed_4_1.png", kaimin.m_bSBTV);
//		m_imgSpeedFoc[3] = new CImgObj("B1/B1_btn_speed_4_2.png");

		m_imgSpeedNor[4] = new CImgObj("B1/B1_btn_speed_5_1.png", kaimin.m_bSBTV);
//		m_imgSpeedFoc[4] = new CImgObj("B1/B1_btn_speed_5_2.png");

		m_imgScrollBtn[0] = new CImgObj("B1/B1_btn_scroll_bar_1.png", kaimin.m_bSBTV);
		m_imgScrollBtn[1] = new CImgObj("B1/B1_btn_scroll_bar_2.png", kaimin.m_bSBTV);

		if( kaimin.m_bSBTV ){
			
			m_imgMenuFoc.load("COMN/COMN_btn_menu_2_sbtv.png", kaimin.m_bSBTV );
			m_imgAutoFoc[0] = new CImgObj("B1/B1_btn_auto_off_2_sbtv.png", kaimin.m_bSBTV );
			m_imgAutoFoc[1] = new CImgObj("B1/B1_btn_auto_on_2_sbtv.png", kaimin.m_bSBTV );
			m_imgSpeedFoc[0] = new CImgObj("B1/B1_btn_speed_1_2_sbtv.png", kaimin.m_bSBTV );
			m_imgSpeedFoc[1] = new CImgObj("B1/B1_btn_speed_2_2_sbtv.png", kaimin.m_bSBTV );
			m_imgSpeedFoc[2] = new CImgObj("B1/B1_btn_speed_3_2_sbtv.png", kaimin.m_bSBTV );
			m_imgSpeedFoc[3] = new CImgObj("B1/B1_btn_speed_4_2_sbtv.png", kaimin.m_bSBTV );
			m_imgSpeedFoc[4] = new CImgObj("B1/B1_btn_speed_5_2_sbtv.png", kaimin.m_bSBTV );
				
		}
		else{
			
			m_imgMenuFoc.load("COMN/COMN_btn_menu_2.png", kaimin.m_bSBTV );
			m_imgAutoFoc[0] = new CImgObj("B1/B1_btn_auto_off_2.png", kaimin.m_bSBTV );
			m_imgAutoFoc[1] = new CImgObj("B1/B1_btn_auto_on_2.png", kaimin.m_bSBTV );
			m_imgSpeedFoc[0] = new CImgObj("B1/B1_btn_speed_1_2.png", kaimin.m_bSBTV );
			m_imgSpeedFoc[1] = new CImgObj("B1/B1_btn_speed_2_2.png", kaimin.m_bSBTV );
			m_imgSpeedFoc[2] = new CImgObj("B1/B1_btn_speed_3_2.png", kaimin.m_bSBTV );
			m_imgSpeedFoc[3] = new CImgObj("B1/B1_btn_speed_4_2.png", kaimin.m_bSBTV );
			m_imgSpeedFoc[4] = new CImgObj("B1/B1_btn_speed_5_2.png", kaimin.m_bSBTV );
			
		}
		
		if( kaimin.m_bSBTV ){
			m_imgMenuBg.setSBTVScale( true );
			m_imgScrollbar.setSBTVScale( true );
			m_imgScrollBtn[ 0 ].setSBTVScale( true );
			m_imgScrollBtn[ 1 ].setSBTVScale( true );
			m_imgMenuNor.setSBTVScale( true );
			m_imgMenuFoc.setSBTVScale( true );
			m_imgAutoNor[0].setSBTVScale( true );
			m_imgAutoFoc[ 0 ].setSBTVScale( true );
			m_imgAutoNor[1].setSBTVScale( true );
			m_imgAutoFoc[1].setSBTVScale( true );
			
			for( int i = 0; i < 5; i++ ){
				
				m_imgSpeedNor[ i ].setSBTVScale( true );
				m_imgSpeedFoc[ i ].setSBTVScale( true );
				
			}
		}
		
		m_imgBg.moveTo(0, 0);
		m_imgMenuBg.moveTo(0, 899);
	
		//kjh start
		if( kaimin.m_bSBTV )
			m_imgScrollbar.moveTo(603 + 400, 50);
		else
			m_imgScrollbar.moveTo(603, 50);
//		kjh end
		
		m_imgMenuNor.moveTo(433, 901.5f);

		m_imgAutoNor[0].moveTo(218, 901.5f);
		m_imgAutoNor[1].moveTo(218, 901.5f);

		m_imgSpeedNor[0].moveTo(3, 901.5f);
		m_imgSpeedNor[1].moveTo(3, 901.5f);
		m_imgSpeedNor[2].moveTo(3, 901.5f);
		m_imgSpeedNor[3].moveTo(3, 901.5f);
		m_imgSpeedNor[4].moveTo(3, 901.5f);
	}
	
	public void createButtons() {
		CButton	btn = null;

		btn = createButton(
				m_imgAutoNor[1],
				m_imgAutoFoc[1],
				null);
		btn.setPoint(218, 901.5f);
		btn.setCommand( CMD_AUTO );
		m_btnAuto = btn;

		btn = createButton(
				m_imgSpeedNor[2],
				m_imgSpeedFoc[2],
				null);
		btn.setPoint(3, 901.5f);
		btn.setCommand( CMD_SPEED );
		m_btnSpeed = btn;

		btn = createButton(
				m_imgMenuNor,
				m_imgMenuFoc,
				null);
		btn.setPoint(433, 901.5f);
		btn.setAsyncFlag(true);
		btn.setCommand( CMD_MENU_ASYNC );
		m_btnMenu = btn;
		
		updateFocusBtns( BTN_FOCUS_MENU );				//kjh
	}

	private void readBook() {
		// SKY:120615:start
		String strFileName = null;
		if (m_bLaw)
			strFileName = BOOK_FILENAME_LAW[Globals.m_nTextFileID];
		else 
			strFileName = BOOK_FILENAME[Globals.m_nTextFileID];
			
		// SKY:end
		byte[] byText = CResFile.load(strFileName);
		String m_strBook = "";
		try {
			m_strBook = new String(byText, "Shift_JIS");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		CBaseView view = getView();
		m_strLineArray = new ArrayList<String>();
		view.splitString(m_strBook, m_strLineArray, VIEW_WIDTH);
		m_nLineCount = m_strLineArray.size();
		
//		timer.scheduleAtFixedRate(task, 0, 1000); //by LYM 2013/01/12
	}
	
	//by LYM 2013/01/12_start_<
	public void OnTimer() {
//		CBaseView view = getView();
//		m_strBook = view.splitString(m_strBook, m_strLineArray, VIEW_WIDTH);
//		m_nLineCount = m_strLineArray.size();
//		if (m_strBook.length() <= 0) {
//			timer.cancel();
//			timer = null;
//			return;
//		}
	}
    //LYM_end_>
/*//===
	private void readBook() {
		byte[] byText = CResFile.load(BOOK_FILENAME[Globals.m_nTextFileID]);
		String strBook = "";
		try {
			strBook = new String(byText, "Shift_JIS");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		CBaseView view = getView();
		view.setTextViewPosition(VIEW_POS_X, VIEW_POS_Y, VIEW_WIDTH, VIEW_HEIGHT);
		view.setTextViewString(strBook);
		m_nLineCount = 0;
	}*/

	public void OnPaint() {
		drawBackGround();

		setScroll();

		drawScrollBtn();
		//drawText();

		int nAlpha = GetStepAlpha();
		setViewAlpha(nAlpha);
		
		super.OnPaint();
	}

	public void OnKeyDown( int keycode ) {
		switch (keycode) {
		case KEY_MENU:		OnMenu();						break;
		case KEY_BACK:		OnExit();						break;
		
		//kjh start
		case KEY_DPAD_CENTER:
			onDPADCenter();
			break;
		case KEY_DPAD_DOWN:
			onDownKey();
			break;
		case KEY_DPAD_UP:
			onUpKey();
			break;
		case KEY_DPAD_LEFT:
			onLeftKey();
			break;
		case KEY_DPAD_RIGHT:
			onRightKey();
			break;
		//kjh end
		default:			super.OnKeyDown(keycode);		break;
		}
	}
	
	//kjh start
	public void onDPADCenter(){
		switch (m_nCurFoucus ) {
		case BTN_FOCUS_AUTO:
			OnAuto();
			break;
		case BTN_FOCUS_MENU:
			OnOption();
			break;
		case BTN_FOCUS_SPEED:
			OnSpeed();
			break;
			
		default:
			break;
		}
	}
	
	public void onLeftKey(){
		if( m_nCurFoucus == BTN_FOCUS_MENU )
			updateFocusBtns( BTN_FOCUS_AUTO );
		else if( m_nCurFoucus == BTN_FOCUS_AUTO )
			updateFocusBtns( BTN_FOCUS_SPEED );
	}
	
	public void onRightKey(){
		if( m_nCurFoucus == BTN_FOCUS_SPEED )
			updateFocusBtns( BTN_FOCUS_AUTO );
		else if( m_nCurFoucus == BTN_FOCUS_AUTO )
			updateFocusBtns( BTN_FOCUS_MENU );
	}
	
	public void onUpKey(){
		
		m_fCurLine	-=	50;
		if( m_fCurLine <= 0 )
			m_fCurLine	=	0;
		MoveScrollBtnByPos();

	}
	
	public void onDownKey(){
		m_fCurLine	+=	50;
		if( m_fCurLine >= m_nLineCount )
			m_fCurLine	=	m_nLineCount;
//		m_nScrollBtnY = (int)(m_fCurLine / m_nLineCount * 768.0f + 50);
		MoveScrollBtnByPos();
	}
	//kjh end
	
	public void OnCommand(int nCmd) {
		if(m_nStep != 1)
			return;
    	switch (nCmd) {
    	case CMD_AUTO:	OnAuto();	break;
    	case CMD_SPEED:	OnSpeed();	break;
    	case CMD_MENU_ASYNC:	OnOption();	break;
    	case CMD_SELECT_CLOSE:	OnExit();	break;
    	}
    }

	public void MessageBoxClosed(int dlgid) {
		switch(dlgid) {
		case 2:
			if(Globals.m_bShowYesNo) {
//		        getView().getActivity().showDialog(3);			//kjh
		        getView().getActivity().showAlertDialog( 3 );	//kjh

			}
			else {
				resume();
			}
			if (m_bLaw)
				Globals.m_nBGMType_WndLaw = Globals.GetBGMType();
			else
				Globals.m_nBGMType_WndRead = Globals.GetBGMType();
			
			if (Globals.m_bClickClose) { // if user clicks close button, ...
				OnClickMenuClose();
			}
			break;
		case 3:
			if(Globals.m_bSelYes) {
				PostMessage(WM_COMMAND, CMD_SELECT_CLOSE, 0);
			}
			else {
				resume();
			}
			break;
		}
	}

	public void OnOption() {
		
		updateFocusBtns( BTN_FOCUS_MENU );				//kjh
		
		pause();

		if (m_bLaw)
			Globals.SetBGMType(Globals.m_nBGMType_WndLaw);
		else
			Globals.SetBGMType(Globals.m_nBGMType_WndRead);
//        getView().getActivity().showDialog(2);			//kjh
        getView().getActivity().showAlertDialog( 2 );	//kjh

	}
	
	public void OnExit() {
//===		getView().clearTextView();

		Close();
	}
	
	private void Close() {
		RemoveAllButtons();
		
		m_nStep = 2;
		m_timeProc = STD.GetTickCount();
	}

	public void OnMenu() {
	}

	public void OnAuto() {
		updateFocusBtns( BTN_FOCUS_AUTO );				//kjh
		m_nAuto = 1 - m_nAuto;
		m_btnAuto.setImage_Normal(m_imgAutoNor[m_nAuto]);
		m_btnAuto.setImage_Focus(m_imgAutoFoc[m_nAuto]);

		m_timePrev = STD.GetTickCount();
	}

	public void OnSpeed() {
		updateFocusBtns( BTN_FOCUS_SPEED );				//kjh
		m_nSpeed ++;
		if(m_nSpeed >= 5)
			m_nSpeed = 0;
		m_btnSpeed.setImage_Normal(m_imgSpeedNor[m_nSpeed]);
		m_btnSpeed.setImage_Focus(m_imgSpeedFoc[m_nSpeed]);
	}

	private int GetStepAlpha() {
		if (m_timeProc == 0)
			return 255;

		int	nAlpha = 255;
		long timeElapse = STD.GetTickCount() - m_timeProc;

		if(m_nStep == 0) {
			if(timeElapse >= OPEN_FRAME_COUNT * Globals.MS_PER_FRAME) {
				m_nStep ++;
				createButtons();
				m_timeProc = STD.GetTickCount();
				timeElapse = 0;
			}
			else {
				float	fAlpha = 255.0f;

				fAlpha *= (float)timeElapse;
				fAlpha /= (float)(OPEN_FRAME_COUNT * Globals.MS_PER_FRAME);
				nAlpha = (int)fAlpha;
			}
		}
		if(m_nStep == 2) {
			if(timeElapse >= CLOSE_FRAME_COUNT * Globals.MS_PER_FRAME) {
				Globals.stopBGM();

				nAlpha = 0;
				DestroyWindow( frmWndMgr.WND_TITLE );
			}
			else {
				float	fAlpha = 255.0f;

				fAlpha *= (float)timeElapse;
				fAlpha /= (float)(CLOSE_FRAME_COUNT * Globals.MS_PER_FRAME);
				nAlpha = (int)(255.0 - fAlpha);
			}
		}

		return nAlpha;
	}

	private void drawBackGround() {
		m_imgBg.draw();
		m_imgMenuBg.draw();
		m_imgScrollbar.draw();
		
		if(m_nStep != 1) {
			m_imgAutoNor[m_nAuto].draw();
			m_imgSpeedNor[m_nSpeed].draw();
			m_imgMenuNor.draw();
		}
	}
	
	private void drawScrollBtn() {
		//kjh start
		if( kaimin.m_bSBTV )
			m_imgScrollBtn[m_nScrollStatus].draw(594 + 400, m_nScrollBtnY);
		else
			m_imgScrollBtn[m_nScrollStatus].draw(594, m_nScrollBtnY);
		
		//kjh end
	}

	private void MoveScrollByBtn(int x, int y) {
		m_nScrollBtnY = m_nScrollOldPosY + (y - m_nTouchOldPosYForScrollButton);
		if(m_nScrollBtnY < 50) m_nScrollBtnY = 50;
		else if(m_nScrollBtnY > 818) m_nScrollBtnY = 818;
		
		m_bScrolled = true;
	}

	private void MoveScrollBtnByPos() {
		m_nScrollBtnY = (int)(m_fCurLine / m_nLineCount * 768.0f + 50);
	}
	
	public void OnTouchDown(int x, int y) {
		if(m_nLineCount == 0)
			return;
		
		m_bTouched = true;
		m_nPrevTouchEventPosY = y;
		m_nScrollPtByTouchMove = 0;
		
		if(m_nScrollStatus == 0) {
			if(isInScrollButton(x, y)) {
				m_nScrollStatus = 1;
				m_nTouchOldPosYForScrollButton = y;
				m_nScrollOldPosY = m_nScrollBtnY;
				
				m_fFlingVelocity = 0; // Stop Fling
			}
		}
		
		m_fFlingVelocity = 0; // Stop Fling
		setScroll();
	}

	public boolean OnTouchUp(int x, int y) {
		if(m_nLineCount == 0)
			return false;
		
		m_bTouched = false;

		if(m_nScrollStatus == 1) {
			MoveScrollByBtn(x, y);
			m_nScrollStatus = 0;
			return true;
		}
		
		setScroll();
		return false;
	}
	
	public void OnTouchMove(int x, int y) {
		if(m_nLineCount == 0)
			return;
		
		if(m_nScrollStatus == 1) {
			MoveScrollByBtn(x, y);
		}
		else {
			m_nScrollPtByTouchMove += (y - m_nPrevTouchEventPosY);
			m_nPrevTouchEventPosY = y;
		}
		setScroll();
	}

	private boolean isInScrollButton(int x, int y) {

		float fPosX = x;// / CDCView.m_fPosScaleXFrom640;
		float fPosY = y;// / CDCView.m_fPosScaleYFrom960;

	    if((fPosX >= 594 - 32) && (fPosX < 594 + 32 + 32) && (fPosY >= m_nScrollBtnY - 32) && (fPosY <= m_nScrollBtnY + 32 + 32))
			return true;
		return false;
    }

	private void setScroll() {
		if(m_nStep != 1)
    		return;

		CBaseView view = getView();
		if(m_nLineCount == 0) {
			m_nLineCount = view.getTextViewLineCount();
			if(m_nLineCount == 0)
				return;
			LINE_HEIGHT = view.getTextViewTotalHeight() / m_nLineCount;
		}
		
    	if(m_bScrolled) { // scrolling
    		m_fCurLine = (m_nScrollBtnY - 50.0f) / 768.0f * m_nLineCount;
    		m_bScrolled = false;
    	}
    	else {
    		long timeCur = STD.GetTickCount();

    		if(m_timePauseStart != 0) {
    			if(m_bPauseFinished) {
    				m_timeProc += (timeCur - m_timePauseStart);
    				m_timePrev += (timeCur - m_timePauseStart);
    				m_timePauseStart = 0;
    			}
    			else
    				timeCur = m_timePauseStart;
    		}

    		if(m_bIsStarting) {
    			if(timeCur - m_timeProc > 0) { // 10000 -> 0
    				m_bIsStarting = false;
    				m_timePrev = timeCur;
    			}
    		}
    		else if(m_fFlingVelocity != 0) {
    			if(m_fFlingStartLine < 0) { // Fling Started
    				m_fFlingStartLine = m_fCurLine;

    				if(m_fFlingVelocity > 0) {
    					m_fFlingEndLine = m_fFlingStartLine + LINE_PER_PAGE;
    					if(m_fFlingEndLine > m_nLineCount)
    						m_fFlingEndLine = m_nLineCount;
    				}
    				else {
    					m_fFlingEndLine = m_fFlingStartLine - LINE_PER_PAGE;
    					if(m_fFlingEndLine < 0)
    						m_fFlingEndLine = 0;
    				}
    			}

    			// Recalc Velocity
    			float fVelocity = m_fFlingVelocity;
    			float fDistance = m_fFlingEndLine - m_fCurLine;
    			if(m_fFlingVelocity < 0) {
    				fVelocity = -fVelocity;
    				fDistance = -fDistance;
    			}
    			if((fVelocity > 4) && (fVelocity > fDistance * 4)) {
					fVelocity = fVelocity / 2;
					if(fVelocity < 4)
						fVelocity = 4;
				}

    			long timeElapse = timeCur - m_timeFlingPrev;
    			m_timeFlingPrev = timeCur;
    			m_timePrev += timeElapse; // AutoScroll 처리

    			if(m_fFlingVelocity > 0) {
    				m_fCurLine += (timeElapse * fVelocity / 1000);
        			if(m_fCurLine >= m_fFlingEndLine) {
        				m_fCurLine = m_fFlingEndLine;
        				m_fFlingVelocity = 0; // Stop Fling
        			}
        			else {
        				m_fFlingVelocity = fVelocity;
        			}
    			}
    			else {
    				m_fCurLine -= (timeElapse * fVelocity / 1000);
        			if(m_fCurLine <= m_fFlingEndLine) {
        				m_fCurLine = m_fFlingEndLine;
        				m_fFlingVelocity = 0; // Stop Fling
        			}
        			else {
        				m_fFlingVelocity = -fVelocity;
        			}
    			}

    			MoveScrollBtnByPos();
    		}
    		else if(m_nScrollPtByTouchMove != 0) {
//    			m_fCurLine -= (m_nScrollPtByTouchMove * CDCView.RES_HEIGHT / 960.0f * CDCView.m_fScale / (float)LINE_HEIGHT);
    			m_fCurLine -= (m_nScrollPtByTouchMove * CDCView.RES_HEIGHT / 960.0f / (float)LINE_HEIGHT);
    			if(m_fCurLine < 0)
    				m_fCurLine = 0;
    			else if(m_fCurLine > m_nLineCount)
    				m_fCurLine = m_nLineCount;
    			m_nScrollPtByTouchMove = 0;

    			MoveScrollBtnByPos();
    		}
    		else if(m_bTouched) {
    			m_timePrev = timeCur;
    		}
    		else if(m_nAuto == 1) {
    			long timeElapse = timeCur - m_timePrev;
    			m_timePrev = timeCur;

    			m_fCurLine += (timeElapse * LINE_PER_SECOND[m_nSpeed] / 1000);
    			if(m_fCurLine > m_nLineCount)
    				m_fCurLine = m_nLineCount;

    			MoveScrollBtnByPos();
    		}
    	}

//===    	view.setTextViewScroll(0, (int)(m_fCurLine * LINE_HEIGHT));
	}

    public void onDrawText() {
    	drawText(); //===
    }

	private void drawText() {
    	if(m_nStep != 1)
    		return;
		if(m_nLineCount == 0)
			return;
    	
		CBaseView view = getView();
		view.setARGB(255, 200, 200, 200);

		int nCurLine = (int)m_fCurLine;
    	int nCurY = (int)((nCurLine - m_fCurLine) * LINE_HEIGHT_PIXEL);
    	if(nCurY < 0) {
    		nCurLine ++;
    		nCurY += LINE_HEIGHT_PIXEL;
    	}
    	
    	for(; nCurLine < m_nLineCount; nCurLine ++, nCurY += LINE_HEIGHT_PIXEL) {
    		if(nCurY >= (VIEW_HEIGHT * CDCView.m_fScale - LINE_HEIGHT_PIXEL))
    			break;
    		view.drawString(m_strLineArray.get(nCurLine), VIEW_POS_X, nCurY + VIEW_POS_Y);
    	}
    }

	private void pause() {
		m_fFlingVelocity = 0; // Stop Fling
		
		m_timePauseStart = STD.GetTickCount();
		m_bPauseFinished = false;
	}

	private void resume() {
		m_bPauseFinished = true;
	}

	public void OnSuspend() {
		int nBGMType = 0;
		if (m_bLaw)
			nBGMType = Globals.m_nBGMType_WndLaw;
		else
			nBGMType = Globals.m_nBGMType_WndRead;
		if(nBGMType < Globals.m_nBGMIDs.length) {
			Globals.pauseBGM();
		}
		pause();
	}

	public void OnResume() {
		int nBGMType = 0;
		if (m_bLaw)
			nBGMType = Globals.m_nBGMType_WndLaw;
		else
			nBGMType = Globals.m_nBGMType_WndRead;
		if(nBGMType < Globals.m_nBGMIDs.length) {
			Globals.resumeBGM();
		}
		resume();
	}

	public void OnFling(float velocityX, float velocityY) {
		if(m_nLineCount == 0)
			return;
		
		if(m_nScrollStatus == 0) {
			if((velocityY < -100) || (velocityY > 100)) {
				m_fFlingVelocity = STD.ABS(velocityY);
				m_fFlingVelocity -= 500;
				if(m_fFlingVelocity < 0)
					m_fFlingVelocity = 0;
				if(m_fFlingVelocity > 1300)
					m_fFlingVelocity = 1300;
				m_fFlingVelocity = m_fFlingVelocity / 1300 * 25 + 15;
				if(velocityY > 0) {
					m_fFlingVelocity = -m_fFlingVelocity;
				}

//				m_fFlingVelocity = m_fFlingVelocity * CDCView.RES_HEIGHT / 960;
				
				m_fFlingStartLine = -1;
				m_timeFlingPrev = STD.GetTickCount();
			}
		}
	}
}
