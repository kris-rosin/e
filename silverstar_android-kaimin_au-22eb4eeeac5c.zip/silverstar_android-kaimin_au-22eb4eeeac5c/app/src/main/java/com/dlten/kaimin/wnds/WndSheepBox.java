package com.dlten.kaimin.wnds;


import android.graphics.Rect;

import com.dlten.kaimin.Globals;
import com.dlten.kaimin.frmWndMgr;
import com.dlten.kaimin.kaimin;
import com.dlten.lib.STD;
import com.dlten.lib.frmWork.CButton;
import com.dlten.lib.graphics.CDCView;
import com.dlten.lib.graphics.CImgObj;

public class WndSheepBox extends WndTimer {

    private static final int nCountBeltImg = 3;

    private CImgObj imgBk = new CImgObj();
    private CImgObj imgLamp = new CImgObj();
    private CImgObj imgBox = new CImgObj();

    private CImgObj[] imgBelt = new CImgObj[nCountBeltImg];
    private CImgObj imgRoller = new CImgObj();

    private float rV = 0.7f;
    private float rChangeX = -648;
    private float rResetBoxX = 800;

    private Rect recBox = new Rect();
    private boolean bTouchedBox = false;

    private CImgObj imgMenuBg   	= new CImgObj();
    private CImgObj imgScoreBg   	= new CImgObj();
    private CImgObj[] imgScoreNum   = new CImgObj[10];

    private CImgObj imgMenuNor   	= new CImgObj();
    private CImgObj imgMenuFoc   	= new CImgObj();

    private int nWinScore = 0;
    private int nFailScore = 0;

    private static final int
            CMD_MENU_ASYNC      = 2,
            CMD_SELECT_CLOSE = 3;

    private static long OPEN_FRAME_COUNT = 20;
    private static long CLOSE_FRAME_COUNT = 20;

    private CButton	btnMenu  = null;

    private int m_nStep;
    private	long	m_timeProc;


    private	long m_timePauseStart = 0;
    private	boolean m_bPauseFinished = false;

    private float rCurBoxPosX = 0;
    private float rPreBoxPosX = 0;

    private boolean bStart = false;
    private float rPreV = 0;
    private int nInitT = 0;
    private boolean bInit = true;
    private boolean bFirstFrame = true;

    @Override
    public void OnLoadResource() {
        Globals.playBGM(Globals.m_nBGMType_WndSheet);
        onCreateImages();
        super.OnLoadResource();
    }

    @Override
    public void OnInitWindow() {

        bStart = true;
        m_nStep = 0;
        m_timeProc = STD.GetTickCount();

        Globals.m_bBGMDisable = false;
        Globals.m_bSEDisable = false;


        super.OnInitWindow();
    }

    @Override
    public void OnShowWindow() {
        super.OnShowWindow();
    }

    @Override
    public void OnPaint() {

        drawCreatedImgs();
        int nAlpha = GetStepAlpha();
        setViewAlpha(nAlpha);

        super.OnPaint();
    }

    @Override
    public void OnKeyDown(int keycode) {
        switch (keycode) {
            case KEY_BACK:		OnExit();						break;
            case KEY_DPAD_DOWN:
            case KEY_DPAD_UP:
            case KEY_DPAD_LEFT:
            case KEY_DPAD_RIGHT:
                OnTouchDown( 0, 0 );
                return;
            //kjh end

            default:			super.OnKeyDown(keycode);		break;
        }
        super.OnKeyDown(keycode);
    }

    @Override
    public void OnCommand(int nCmd) {
        if(m_nStep != 1)
            return;
        switch (nCmd) {
            case CMD_MENU_ASYNC:	OnOption();	break;
            case CMD_SELECT_CLOSE:	OnExit();	break;
        }
        super.OnCommand(nCmd);
    }

    @Override
    public void MessageBoxClosed(int dlgid) {
        switch(dlgid) {
            case 2:
                if(Globals.m_bShowYesNo) {
                    getView().getActivity().showAlertDialog( 3 );
                }

                Globals.m_nBGMType_WndSheet = Globals.GetBGMType();

                if (Globals.m_bClickClose) { // if user clicks close button, ...
                    OnClickMenuClose();
                }
                break;
            case 3:
                if(Globals.m_bSelYes) {
                    PostMessage(WM_COMMAND, CMD_SELECT_CLOSE, 0);
                }
                break;
        }
        super.MessageBoxClosed(dlgid);
    }

    @Override
    public boolean onTouchUp(int wParam, int lParam) {
        return super.onTouchUp(wParam, lParam);
    }

    @Override
    public void onTouchDown(int wParam, int lParam) {
        if (wParam > recBox.left
                && wParam < recBox.right
                && lParam > recBox.top
                && lParam < recBox.bottom)
        {
            if (bTouchedBox == false)
            {
                nWinScore += 1;
                bTouchedBox = true;
                imgBox.resetImage("G1/sheep_box_closed.png", false);
                playSound();
            }
        }
        super.onTouchDown(wParam, lParam);
    }

    @Override
    public void OnSuspend() {
        if(Globals.m_nBGMType_WndSheet < Globals.m_nBGMIDs.length) {
            Globals.pauseBGM();
        }
        super.OnSuspend();
    }

    @Override
    public void OnResume() {
        if(Globals.m_nBGMType_WndSheet < Globals.m_nBGMIDs.length) {
            Globals.resumeBGM();
        }
        super.OnResume();
    }


    private void onCreateImages()
    {
        if( kaimin.m_bSBTV ){
            imgBk.load( "G1/sheep_box_bk.png" );
        }
        else{
            if (CDCView.m_fScale <= 1) {
                imgBk.load("G1/sheep_box_bk.png", true);
                imgBk.moveTo(320 * (1 - 1 / CDCView.m_fScale), 300 * (1 - 1 / CDCView.m_fScale));
            }
            else
                imgBk.load("G1/sheep_box_bk.png");
        }

        imgRoller.load("G1/sheep_box_roller.png", kaimin.m_bSBTV);

        rPreBoxPosX = 0;
        rCurBoxPosX = 0;
        for(int i = 0; i < nCountBeltImg; i ++) {
            imgBelt[i] = new CImgObj("G1/sheep_box_belt.png", kaimin.m_bSBTV );
            imgBelt[i].moveTo(640*i, 500);
            if (i == 2)
            {
                imgBelt[i].moveTo(640*i, 500);
            }
        }
        imgBox.load("G1/sheep_box_opend.png", kaimin.m_bSBTV);
        imgLamp.load("G1/sheep_box_lamp.png", kaimin.m_bSBTV );

        imgMenuBg.load("COMN/COMN_menu_back.png", kaimin.m_bSBTV );
        imgScoreBg.load("G1/sheep_box_calculate.png", kaimin.m_bSBTV );

        imgMenuNor.load("COMN/COMN_btn_menu_1.png", kaimin.m_bSBTV );
        if( kaimin.m_bSBTV ){
            imgMenuFoc.load("COMN/COMN_btn_menu_2_sbtv.png", kaimin.m_bSBTV );
        }else{
            imgMenuFoc.load("COMN/COMN_btn_menu_2.png");
        }


        for(int i = 0; i < 10; i ++) {
            imgScoreNum[i] = new CImgObj("COMN/COMN_num_" + i + ".png", kaimin.m_bSBTV );
        }

        if( kaimin.m_bSBTV )
        {
            imgRoller.setSBTVScale( true );
            imgBox.setSBTVScale( true );

            imgLamp.setSBTVScale( true );

            for(int i = 0; i < nCountBeltImg; i ++) {
                imgBelt[i].setSBTVScale( true );
            }
        }

        imgRoller.moveTo(-160, 600);
        imgBox.moveTo(700, 330);
        imgLamp.moveTo(179, 0);

        recBox = new Rect(700, 330, 700 + 242, 330 + 310);

        if( kaimin.m_bSBTV )
        {
            imgMenuBg.setSBTVScale( true );
            imgScoreBg.setSBTVScale( true );

            imgMenuNor.setSBTVScale( true );
            imgMenuFoc.setSBTVScale( true );

            for(int i = 0; i < 10; i ++) {
                imgScoreNum[i].setSBTVScale( true );
            }
        }

        imgMenuBg.moveTo(0, 899);
        imgScoreBg.moveTo(10, 906);
        imgMenuNor.moveTo(433, 901.5f);
    }

    private void drawCreatedImgs()
    {
        if (bStart == false)
        {
            return;
        }
        imgBk.draw();
        imgRoller.draw();
        long curTime;
        curTime = STD.GetTickCount();

        if(m_timePauseStart != 0) {
            if(m_bPauseFinished) {
                m_timeProc += (curTime - m_timePauseStart);
                m_timePauseStart = 0;
            }
            else
                curTime = m_timePauseStart;
        }

        long timeElapse = curTime - m_timeProc;
        float fFrame = (float)timeElapse / Globals.MS_PER_FRAME;

        float fSheetX = 0;

        if(fFrame > 1200) {
            m_timeProc = curTime;

            if (bTouchedBox == false)
            {
                nFailScore += 1;
            }
            bTouchedBox = false;
            imgBox.resetImage("G1/sheep_box_opend.png", false);
            imgBox.moveTo(rResetBoxX, imgBox.getPos().y);

            nInitT = 0;
            bInit = true;
        }
        else {

            float a = (fFrame - 400) / 600;
            fSheetX = -81.5f * (1 - a) + 642.5f * a;
        }

        rCurBoxPosX = 640 - fSheetX;
        rV = rPreBoxPosX - rCurBoxPosX;

        if (bInit)
        {
            if (bFirstFrame == false)
            {
                rCurBoxPosX = 640 - fSheetX;
                rPreBoxPosX = rCurBoxPosX;
                nInitT ++;
                if (nInitT < 3)
                {
                    rV = rPreV;
                }
                else
                {
                    bInit = false;
                }
            }
        }

        if (bFirstFrame)
        {
            bInit = false;
            nInitT ++;
            if (nInitT < 18)
            {
                rV = 0;
            }
            else
            {
                nInitT = 0;
                bFirstFrame = false;
            }

        }

        for (int i = 0; i < nCountBeltImg; i++)
        {
            imgBelt[i].moveTo(imgBelt[i].getPos().x - (rV), imgBelt[i].getPos().y);
            if (imgBelt[i].getPos().x < rChangeX)
            {
                imgBelt[i].moveTo(imgBelt[i].getPos().x + 1280.f, imgBelt[i].getPos().y);
            }

            imgBelt[i].draw();
        }
        rPreV = rV;

        imgBox.moveTo(rCurBoxPosX, imgBox.getPos().y);
        rPreBoxPosX = rCurBoxPosX;


        recBox = new Rect((int)(imgBox.getPos().x),
                (int) imgBox.getPos().y,
                (int) imgBox.getPos().x + 242,
                (int) imgBox.getPos().y + 310);
        imgBox.draw();
        imgLamp.draw();

        imgMenuBg.draw();
        imgScoreBg.draw();
        imgMenuNor.draw();

        drawScore();
    }

    private void drawScore1(int nScore, float x)
    {
        int nOOO = 100000;
        for(int i = 0; i < 6; i ++) {
            int nOne = nScore / nOOO;
            nScore -= nOne * nOOO;
            nOOO /= 10;

            imgScoreNum[nOne].draw(x + 19 * i, 919.5f);
        }
    }

    private void drawScore()
    {
        drawScore1(nWinScore, 75.5f);
        drawScore1(nFailScore, 299.5f);
    }

    private int GetStepAlpha() {
        if (m_timeProc == 0)
            return 255;

        int	nAlpha = 255;
        long timeElapse = STD.GetTickCount() - m_timeProc;

        if(m_nStep == 0) {
            if(timeElapse >= OPEN_FRAME_COUNT * Globals.MS_PER_FRAME) {
                m_nStep ++;
                createButtons();
                m_timeProc = STD.GetTickCount();
                timeElapse = 0;
            }
            else {
                float	fAlpha = 255.0f;

                fAlpha *= (float)timeElapse;
                fAlpha /= (float)(OPEN_FRAME_COUNT * Globals.MS_PER_FRAME);
                nAlpha = (int)fAlpha;
            }
        }
        if(m_nStep == 2) {
            if(timeElapse >= CLOSE_FRAME_COUNT * Globals.MS_PER_FRAME) {
                Globals.stopBGM();

                nAlpha = 0;
                DestroyWindow( frmWndMgr.WND_TITLE );
            }
            else {
                float	fAlpha = 255.0f;

                fAlpha *= (float)timeElapse;
                fAlpha /= (float)(CLOSE_FRAME_COUNT * Globals.MS_PER_FRAME);
                nAlpha = (int)(255.0 - fAlpha);
            }
        }

        return nAlpha;
    }

    public void OnExit() {
        Close();
    }


    private void Close() {
        RemoveAllButtons();

        m_nStep = 2;
        m_timeProc = STD.GetTickCount();

    }

    public void createButtons() {
        CButton btn = null;
        btn = createButton(
                imgMenuNor,
                imgMenuFoc,
                null);
        btn.setPoint(433, 901.5f);
        btn.setAsyncFlag(true);
        btn.setCommand( CMD_MENU_ASYNC );
        btnMenu = btn;

        if( kaimin.m_bSBTV ){
            if( btnMenu != null )
                btnMenu.setFocus();
        }
    }

    public void OnOption() {

        Globals.SetBGMType(Globals.m_nBGMType_WndSheet);

        getView().getActivity().showAlertDialog( 2 );


    }

    private void playSound()
    {
        Globals.playSoundForSheepBox();
    }

    private void pause() {
        m_timePauseStart = STD.GetTickCount();
        m_bPauseFinished = false;
    }

    private void resume() {
        m_bPauseFinished = true;
    }

}
