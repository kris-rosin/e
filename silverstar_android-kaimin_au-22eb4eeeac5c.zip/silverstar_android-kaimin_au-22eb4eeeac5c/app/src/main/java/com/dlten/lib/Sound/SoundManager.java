package com.dlten.lib.Sound;

import com.dlten.kaimin.Globals;
import com.dlten.kaimin_auOM.R;
import com.dlten.lib.STD;

import android.app.Activity;
import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;

/**
 * <p>Title: Android Fugou</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2011</p>
 *
 * <p>Company: dl</p>
 *
 * @author hrh
 * @version 1.0
 */
public class SoundManager {
	
	private static Activity	m_activity = null;
	
    private static final int BGM_PLAYER = 0;
    private static final int SE_PLAYER = 1;
    private static SoundManager _instance = null;
    private MediaPlayer m_players[] = new MediaPlayer[2];

    private int m_nBgmNum = STOP_SOUND;
    private int m_nEffNum = STOP_SOUND;
    private boolean m_bBgmLoop = true;

    private int m_nResStartIndex;

    public SoundManager() {
        _instance = this;
    }
    public static SoundManager getInstance() {
        if (_instance == null)
        	return new SoundManager();
        else
        	return _instance;
    }
    public void changeContext( Activity activity ) {
    	m_activity = activity;
    	
    	soundpool_Init();
    }
    private MediaPlayer createPlayer(int nSndID) {
        try {
        	MediaPlayer player = MediaPlayer.create(m_activity, nSndID);
        	// player.prepare();
            return player;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void destroySnd() {
        playBGM(STOP_SOUND);
//        mainPlayer.disposeAudioTrack( auph_tr );
//        mainPlayer.disposeTrack( track[BGM] );
//        mainPlayer.disposeTrack( track[SE] );
//        mainPlayer.disposePlayer();
    }

    public void blockWhileSe() {
        if( m_nEffNum < 0 || m_nEffNum >= m_players.length )
            return;
        while( m_players[SE_PLAYER].isPlaying()) {
        	STD.sleep(30);
        }
    }
    public void stopBGM() {
//        if( m_nBgmNum < 0 || m_nBgmNum >= m_players.length )
//            return;
        if( m_nBgmNum < 0 )
            return;

        try{
            m_players[BGM_PLAYER].stop();
        } catch( Exception e ) {}
        m_nBgmNum = STOP_SOUND;
        m_bBgmLoop = true;
    }
    public void pauseBGM() {
        m_players[BGM_PLAYER].pause();
    }
    public void resumeBGM() {
        m_players[BGM_PLAYER].start();
    }
    public void playBGM(int nBgmIndex) {
        playBGM(nBgmIndex, true);
    }

    public void playBGM(int nBgmIndex, boolean bLoop) {
    	if (!m_bEnable)
    		return;
    	
//        if( nBgmIndex < 0 || nBgmIndex >= m_players.length )
//            return;
        if( nBgmIndex < 0 )
            return;

        if( m_nBgmNum != nBgmIndex )
        {
            int nIndex = m_nResStartIndex + nBgmIndex;
            try {
                stopBGM();
                stopSE();
                if( m_players[BGM_PLAYER] != null ) {
                    m_players[BGM_PLAYER].release();
                    m_players[BGM_PLAYER] = null;
                }
                m_players[BGM_PLAYER] = createPlayer(nBgmIndex);

            } catch (Exception e) {
                // System.out.println("BGM err:" + e);
            }
            playBGM_force( nBgmIndex, bLoop );
        }
    }
    private void playBGM_force( int nBgmIndex, boolean bLoop ) {
    	if (!m_bEnable)
    		return;
    	
        if(nBgmIndex < 0)
            return;

        try {
              m_players[BGM_PLAYER].setLooping(bLoop);
              m_players[BGM_PLAYER].start();

              m_nBgmNum = nBgmIndex;
              m_bBgmLoop = bLoop;
        } catch (Exception e) {
            // System.out.println("BGM err:" + e);
        }
    }

    public void playSE(int nSeIndex) {
    	if (!m_bEnable)
    		return;
    	
        if (nSeIndex < 0)
            return;

        stopSE();
        try {
            resetPlayer(nSeIndex);
            // m_players[SE_PLAYER].setLooping(false);
            m_players[SE_PLAYER].start();

            m_nEffNum = nSeIndex;
        } catch (Exception e) {
            // System.out.println("SE err:" + e);
        }
    }
    public void stopSE() {
    	
    	// SKY:120321:Start
    	if ( m_players[SE_PLAYER] == null )
    		return;
    	// SKY:end

    	try {
//        	if (m_players[SE_PLAYER].isPlaying())
//        		m_players[SE_PLAYER].stop();
        	while (m_players[SE_PLAYER].isPlaying())	{}
        } catch (Exception e) {
            // System.out.println("SE err:" + e);
        }
    }

    void setVolume(MediaPlayer player, int nVol) {
    	player.setVolume(nVol, nVol);
    }
    
    private void resetPlayer( int nIndex ) {
        if( m_players[SE_PLAYER] != null ) {
            m_players[SE_PLAYER].release();
            m_players[SE_PLAYER] = null;
        }
        m_players[SE_PLAYER] = createPlayer(nIndex);
    }

    public static final int STOP_SOUND = -1;
    public static final int PAUSE_SOUND = -2;
    
    private boolean m_bEnable;
    public void setEnable( boolean nIndex ) {
    	m_bEnable = nIndex;
    }

    //================ SoundPool =====================
//    private  AudioManager  mAudioManager;
	public static final int[] m_nSENumIDs = {
		R.raw.number_0, 
		R.raw.number_1, 
		R.raw.number_2, 
		R.raw.number_3, 
		R.raw.number_4, 
		R.raw.number_5,
		R.raw.number_6,
		R.raw.number_7,
		R.raw.number_8,
		R.raw.number_9,
		R.raw.hitsuji,
		R.raw.rpg_attack,
		R.raw.rpg_battle_start,
		R.raw.rpg_escape,
		R.raw.rpg_levelup,
		R.raw.rpg_miss,
		R.raw.rpg_set,
		R.raw.rpg_win
		};
	static final int m_nSECount = 18;
    SoundPool m_soundpool;
    int[] m_soundpool_soundISs = new int[m_nSECount];
    private void soundpool_Init() {
    	
    	// SKY:120321:start
//    	m_soundpool = new  SoundPool(2, AudioManager.STREAM_MUSIC, 0);
//    	for(int i = 0; i < 11; i ++)
//    		m_soundpool_soundISs[i] = m_soundpool.load(m_activity, m_nSENumIDs[i], 1);
    	
    	m_soundpool = new  SoundPool(10, AudioManager.STREAM_MUSIC, 10);
    	for(int i = 0; i < m_nSECount; i ++)
    		m_soundpool_soundISs[i] = m_soundpool.load(m_activity, m_nSENumIDs[i], 1);
    	// SKY:end
    	
//    	mAudioManager = (AudioManager)m_activity.getSystemService(Context.AUDIO_SERVICE);
    }
    public void soundpool_PlaySE(int nNum) {
//    	float streamVolume = mAudioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
//    	streamVolume = streamVolume / mAudioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
//    	m_soundpool.play(m_soundpool_soundISs[nNum], streamVolume, streamVolume, 1, 0, 1.0f);
    	m_soundpool.play(m_soundpool_soundISs[nNum], 1.0f, 1.0f, 1, 0, 1.0f);
    }
}
