package com.dlten.kaimin.wnds;

//by Kwang 20121015

import android.media.AudioManager;
import android.media.SoundPool;
import android.util.Log;

import com.dlten.kaimin_auOM.R;

import com.dlten.kaimin.Globals;
import com.dlten.kaimin.frmWndMgr;
import com.dlten.kaimin.kaimin;
import com.dlten.lib.CBaseView;
import com.dlten.lib.STD;
import com.dlten.lib.file.CResFile;
import com.dlten.lib.frmWork.CAnimation;
import com.dlten.lib.frmWork.CButton;
import com.dlten.lib.frmWork.CWnd;
import com.dlten.lib.graphics.CDCView;
import com.dlten.lib.graphics.CImgObj;


public class WndSound extends WndTimer {

	private int m_nStep;
	private	long	m_timeProc;

	private static long OPEN_FRAME_COUNT 	= 20;
	private static long CLOSE_FRAME_COUNT 	= 20;
	private static int	SOUND_KIND_COUNT = 12;

	private CImgObj m_imgBg   = new CImgObj();
	private CImgObj m_imgMenuBg   = new CImgObj();
	private CImgObj m_imgTitleBg   = new CImgObj();
	private CImgObj m_imgMenuNor   = new CImgObj();
	private CImgObj m_imgPauseNor   = new CImgObj();
	private CImgObj m_imgBtnMenuNor   = new CImgObj();
	private CImgObj m_imgBtnMenuFoc   = new CImgObj();
	private CImgObj m_imgBtnPauseNor   = new CImgObj();
	private CImgObj m_imgBtnPauseFoc   = new CImgObj();
	private CImgObj m_imgTitle1			= new CImgObj();
	private CImgObj m_imgTitle2 		= new CImgObj();
	private CImgObj m_imgSoundBtnNor[] = new CImgObj[SOUND_KIND_COUNT];
	private CImgObj m_imgSoundBtnFoc[] = new CImgObj[SOUND_KIND_COUNT];

	private CButton	m_btnMenu  = null;
	private CButton	m_btnPause  = null;
	private CButton m_btnSoundKind[] = new CButton[SOUND_KIND_COUNT];
	
	private	long m_timePauseStart = 0;
	private	boolean m_bPauseFinished = false;
	
	private int m_screenMode = 0;//0 -> sound select mode, 1 -> sound playing mode
	private float m_fSoundKindButtonStartPos = 0.0f;
	
	private boolean m_bToggle = false;
	private boolean m_bMenu = false;

    public static final int
    	CMD_PAUSE_ASYNC		= 0,
		CMD_MENU_ASYNC      = 1,
		CMD_SELECT_CLOSE	= 2,
    	CMD_SOUND_KIND_START = 3;
    
    //kjh start
	private static final int	BTN_FOCUS_PAUSE				=	100;
	private static final int	BTN_FOCUS_MENU					=	105;
	
	public int					m_nCurFoucus	=	-1;
	
	public void initFocusBtns(){
		
		if( m_btnMenu != null )
			m_btnMenu.setNormal();
		
		if ( m_btnPause != null )
			m_btnPause.setNormal();
			
	}
	
	public void updateFocusBtns( int nFocusBtn ){
		
		if( !kaimin.m_bSBTV )
			return;
		
//		if( m_nCurFoucus == nFocusBtn )
//			return;
		try {
			
			initFocusBtns();
			
			switch ( nFocusBtn ) {
				case BTN_FOCUS_MENU:
					if( m_btnMenu != null )
						m_btnMenu.setFocus();
	//				m_Btns.setFocusState( true );
					break;
				case BTN_FOCUS_PAUSE:
					if( m_btnPause != null )
						m_btnPause.setFocus();
					break;
			default:
				break;
			}	
		} catch (Exception e) {
		}
		
		m_nCurFoucus	=	nFocusBtn;
		
	}
	//kjh end
	
	public void OnLoadResource() {
		createImages();
		super.OnLoadResource();
	}
	public void OnInitWindow() {
		Globals.m_bBGMDisable = true;
		Globals.m_bSEDisable = false;
		Globals.m_bSoundTheatre = true;
		
		m_nStep = 0;
		m_timeProc = STD.GetTickCount();
	}
	
	public void OnShowWindow() {
	}

	private void createImages() {
		
		//kjh start
//		m_imgBg.load("COMN/COMN_background.png");
		if( kaimin.m_bSBTV ){
			m_imgBg.load("COMN/COMN_background_sbtv_landscape.png" );
		}
		else
			m_imgBg.load("COMN/COMN_background.png");
		//kjh end
		
//		m_imgMenuBg.load("COMN/COMN_menu_back.png");
//		m_imgMenuNor.load("COMN/COMN_btn_menu_1.png");
		m_imgMenuBg.load("COMN/COMN_menu_back.png", kaimin.m_bSBTV );
		m_imgTitleBg.load("COMN/COMN_menu_back.png", kaimin.m_bSBTV );
		m_imgMenuNor.load("COMN/COMN_btn_menu_1.png", kaimin.m_bSBTV );
		m_imgPauseNor.load("H1/H1_btn_stop_1.png", kaimin.m_bSBTV );
		
		m_imgBtnMenuNor.load("COMN/COMN_btn_menu_1.png", kaimin.m_bSBTV );
		m_imgBtnPauseNor.load("H1/H1_btn_stop_1.png", kaimin.m_bSBTV );
		m_imgBtnPauseFoc.load("H1/H1_btn_stop_1.png", kaimin.m_bSBTV );
		m_imgBtnPauseNor.setVisible(false);
		m_imgBtnPauseFoc.setVisible(false);
		
		if( kaimin.m_bSBTV ){
			m_imgBtnMenuFoc.load("COMN/COMN_btn_menu_2_sbtv.png", kaimin.m_bSBTV );
		}else{
			m_imgBtnMenuFoc.load("COMN/COMN_btn_menu_2.png", kaimin.m_bSBTV );
		}
		
		m_imgTitle1.load("H1/H1_lbl_select.png", kaimin.m_bSBTV );
		
		for (int i = 0; i < SOUND_KIND_COUNT; i++) {
			m_imgSoundBtnNor[i] = new CImgObj();
			m_imgSoundBtnFoc[i] = new CImgObj();
			switch(i) {
			case 0://森�
				m_imgSoundBtnNor[i].load("H1/H1_btn_Forest_1.png", kaimin.m_bSBTV );
				m_imgSoundBtnFoc[i].load("H1/H1_btn_Forest_2.png", kaimin.m_bSBTV );
				break;
			case 1://虫の音
				m_imgSoundBtnNor[i].load("H1/H1_btn_Mushi_1.png", kaimin.m_bSBTV );
				m_imgSoundBtnFoc[i].load("H1/H1_btn_Mushi_2.png", kaimin.m_bSBTV );
				break;
			case 2://夕暮れ�E小�
				m_imgTitle2.load("H1/H1_lbl_Dusk.png", kaimin.m_bSBTV );
				m_imgSoundBtnNor[i].load("H1/H1_btn_Dusk_1.png", kaimin.m_bSBTV );
				m_imgSoundBtnFoc[i].load("H1/H1_btn_Dusk_2.png", kaimin.m_bSBTV );
				break;
			case 3://カエル
				m_imgTitle2.load("H1/H1_lbl_Frog.png", kaimin.m_bSBTV );
				m_imgSoundBtnNor[i].load("H1/H1_btn_Frog_1.png", kaimin.m_bSBTV );
				m_imgSoundBtnFoc[i].load("H1/H1_btn_Frog_2.png", kaimin.m_bSBTV );
				break;
			case 4://雨
				m_imgTitle2.load("H1/H1_lbl_Rain.png", kaimin.m_bSBTV );
				m_imgSoundBtnNor[i].load("H1/H1_btn_Rain_1.png", kaimin.m_bSBTV );
				m_imgSoundBtnFoc[i].load("H1/H1_btn_Rain_2.png", kaimin.m_bSBTV );
				break;
			case 5://荒れる水面
				m_imgTitle2.load("H1/H1_lbl_Water.png", kaimin.m_bSBTV );
				m_imgSoundBtnNor[i].load("H1/H1_btn_Water_1.png", kaimin.m_bSBTV );
				m_imgSoundBtnFoc[i].load("H1/H1_btn_Water_2.png", kaimin.m_bSBTV );
				break;
			case 6://波
				m_imgTitle2.load("H1/H1_lbl_Wave.png", kaimin.m_bSBTV );
				m_imgSoundBtnNor[i].load("H1/H1_btn_Wave_1.png", kaimin.m_bSBTV );
				m_imgSoundBtnFoc[i].load("H1/H1_btn_Wave_2.png", kaimin.m_bSBTV );
				break;
			case 7://地鳴�
				m_imgTitle2.load("H1/H1_lbl_Jinari.png", kaimin.m_bSBTV );
				m_imgSoundBtnNor[i].load("H1/H1_btn_Jinari_1.png", kaimin.m_bSBTV );
				m_imgSoundBtnFoc[i].load("H1/H1_btn_Jinari_2.png", kaimin.m_bSBTV );
				break;
			case 8://メトロノ�Eム
				m_imgTitle2.load("H1/H1_lbl_Metronome.png", kaimin.m_bSBTV );
				m_imgSoundBtnNor[i].load("H1/H1_btn_Metronome_1.png", kaimin.m_bSBTV );
				m_imgSoundBtnFoc[i].load("H1/H1_btn_Metronome_2.png", kaimin.m_bSBTV );
				break;
			case 9://BGM�E�タイプA
				m_imgSoundBtnNor[i].load("H1/H1_btn_BGMa_1.png", kaimin.m_bSBTV );
				m_imgSoundBtnFoc[i].load("H1/H1_btn_BGMa_2.png", kaimin.m_bSBTV );
				break;
			case 10://BGM�E�タイプB
				m_imgSoundBtnNor[i].load("H1/H1_btn_BGMb_1.png", kaimin.m_bSBTV );
				m_imgSoundBtnFoc[i].load("H1/H1_btn_BGMb_2.png", kaimin.m_bSBTV );
				break;
			case 11://BGM�E�タイプC
				m_imgSoundBtnNor[i].load("H1/H1_btn_BGMc_1.png", kaimin.m_bSBTV );
				m_imgSoundBtnFoc[i].load("H1/H1_btn_BGMc_2.png", kaimin.m_bSBTV );
				break;
			}
		}
		
		m_imgBg.moveTo(0, 0);
		m_imgMenuBg.moveTo(0, 899);
		m_imgTitleBg.moveTo(0, 0);
		m_imgMenuNor.moveTo(433, 901.5f);
		m_imgPauseNor.moveTo(80, 450.0f);
		m_imgTitle1.moveTo(95, 15);
		m_imgTitle1.setVisible(false);
		m_imgTitle2.setVisible(false);

		for (int i = 0; i < SOUND_KIND_COUNT; i++) {
			m_imgSoundBtnNor[i].moveTo(80.0f, 80+SOUND_BUTTON_HEIGHT*i);
			m_imgSoundBtnFoc[i].moveTo(80.0f, 80+SOUND_BUTTON_HEIGHT*i);
		}
		
		if( kaimin.m_bSBTV ){
			
//			m_imgBg.setSBTVScale( true );
			m_imgMenuBg.setSBTVScale( true );
			m_imgTitleBg.setSBTVScale( true );
			m_imgMenuNor.setSBTVScale( true );
			m_imgPauseNor.setSBTVScale( true );
			
			m_imgBtnMenuNor.setSBTVScale( true );
			m_imgBtnMenuFoc.setSBTVScale( true );
			
			m_imgBtnPauseNor.setSBTVScale( true );
			m_imgBtnPauseFoc.setSBTVScale( true );
			
			m_imgTitle1.setSBTVScale( true );
		
			for (int i = 0; i < SOUND_KIND_COUNT; i++) {
				m_imgSoundBtnNor[i].setSBTVScale( true );
				m_imgSoundBtnFoc[i].setSBTVScale( true );
			}
		}
		
	}

	private void loadSoundImagePlay(int soundID) {
		switch(soundID) {
		case 0://森�
			m_imgTitle2.load("H1/H1_lbl_Forest.png", kaimin.m_bSBTV );
//			soundID = R.raw.sound_forest;
			break;
		case 1://虫の音
			m_imgTitle2.load("H1/H1_lbl_Mushi.png", kaimin.m_bSBTV );
//			soundID = R.raw.sound_mushi;
			break;
		case 2://夕暮れ�E小�
			m_imgTitle2.load("H1/H1_lbl_Dusk.png", kaimin.m_bSBTV );
//			soundID = R.raw.sound_dusk;
			break;
		case 3://カエル
			m_imgTitle2.load("H1/H1_lbl_Frog.png", kaimin.m_bSBTV );
//			soundID = R.raw.sound_frog;
			break;
		case 4://雨
			m_imgTitle2.load("H1/H1_lbl_Rain.png", kaimin.m_bSBTV );
//			soundID = R.raw.sound_rain;
			break;
		case 5://荒れる水面
			m_imgTitle2.load("H1/H1_lbl_Water.png", kaimin.m_bSBTV );
//			soundID = R.raw.sound_water;
			break;
		case 6://波
			m_imgTitle2.load("H1/H1_lbl_Wave.png", kaimin.m_bSBTV );
//			soundID = R.raw.sound_wave;
			break;
		case 7://地鳴�
			m_imgTitle2.load("H1/H1_lbl_Jinari.png", kaimin.m_bSBTV );
//			soundID = R.raw.sound_jinari;
			break;
		case 8://メトロノ�Eム
			m_imgTitle2.load("H1/H1_lbl_Metronome.png", kaimin.m_bSBTV );
//			soundID = R.raw.sound_metronome;
			break;
		case 9:
			m_imgTitle2.load("H1/H1_lbl_BGMa.png", kaimin.m_bSBTV );
			break;
		case 10:
			m_imgTitle2.load("H1/H1_lbl_BGMb.png", kaimin.m_bSBTV );
			break;
		case 11:
			m_imgTitle2.load("H1/H1_lbl_BGMc.png", kaimin.m_bSBTV );
			break;
		default:
			m_imgTitle2.load("H1/H1_lbl_Metronome.png", kaimin.m_bSBTV );
//			soundID = R.raw.sound_metronome;
			break;
		}
		m_imgTitle2.moveTo(95, 15);
		if (kaimin.m_bSBTV)
			m_imgTitle2.setSBTVScale( true );
		
		// SKY:121120:start
		if (Globals.m_nTextFileID <= 8)
//			Globals.playBGM(Globals.m_nTextFileID+3); //sorry by Kwang
			Globals.playMyBGM(Globals.m_nTextFileID);
		else
			Globals.playBGM(Globals.m_nTextFileID-9); //sorry by Kwang
		// SKY:end
			
	}
	
	public void createButtons() {
		CButton	btn = null;

		btn = createButton(
				m_imgBtnMenuNor,
				m_imgBtnMenuFoc,
				null);
		btn.setPoint(433, 901.5f);
		btn.setCommand( CMD_MENU_ASYNC );
		btn.setAsyncFlag(true);
		m_btnMenu = btn;

		btn = createButton(
				m_imgBtnPauseNor,
				m_imgBtnPauseFoc,
				null);
		btn.setPoint(80.0f, 450.0f);
		btn.setCommand( CMD_PAUSE_ASYNC );
		btn.setAsyncFlag(true);
		btn.setVisible(false);
		m_btnPause = btn;
		
		setMode(0);
	}
	
	public void OnPaint() {
		// drawing dimmension is just Globals.RES_WIDTH * Globals.RES_HEIGHT
		m_imgBg.draw();
		
		if (m_screenMode == 0) {
			for (int i = 0; i < SOUND_KIND_COUNT; i++) {
				float x = 80.0f;
				float y = SOUND_KIND_BUTTON_START_Y+m_fSoundKindButtonStartPos+i*SOUND_BUTTON_HEIGHT;
				if (i != m_selectedSoundKind)
					m_imgSoundBtnNor[i].draw(x, y);
				else
					m_imgSoundBtnFoc[i].draw(x, y);
			}
		}
		
		m_imgMenuBg.draw();
		m_imgTitleBg.draw();

		if (m_btnMenu != null)
			m_btnMenu.Draw();
		
		if (m_btnPause != null && m_screenMode != 0)
			m_btnPause.Draw();
		
		if(m_nStep != 1) {
			m_imgMenuNor.draw();
			if (m_btnPause != null && m_screenMode != 0)
				m_imgPauseNor.draw();
		}
		
		m_imgTitle2.draw();
		m_imgTitle1.draw();
		
		int nAlpha = GetStepAlpha();
		setViewAlpha(nAlpha);
		
		super.OnPaint();
	}
	
    public void DrawProcess() {
        OnPaint();
//        DrawWindowName();
//
//        int i;
//        CAnimation animObj;
//        for (i = 0; i < m_Anims.size(); i++) {
//            animObj = (CAnimation) m_Anims.elementAt(i);
//            if (animObj.IsDrawBylib())
//                animObj.Draw();
//            animObj.UpdateFrame();
//        }
//
//        CButton btn;
//        for (i = 0; i < m_Btns.size(); i++) {
//        	btn = (CButton) m_Btns.elementAt(i);
//           	btn.Draw();
//        }
//        
//        if (GetModalessWnd() != null) {
//            GetModalessWnd().DrawProcess();
//        }

    }
    
	public void OnKeyDown( int keycode ) {
		switch (keycode) {
		case KEY_MENU:		OnMenu();						break;
		case KEY_BACK:		OnExit();						break;
		
		case KEY_DPAD_CENTER:
			onDPADCenter();
			break;
		case KEY_DPAD_UP:
			onUpKey();
			break;
		case KEY_DPAD_LEFT:
			onLeftKey();
			break;
		case KEY_DPAD_RIGHT:
			onRightKey();
			break;
		
		default:			super.OnKeyDown(keycode);		break;
		}
	}
	
	//kjh start
	
	public void onDPADCenter(){
		
		if( m_nCurFoucus == BTN_FOCUS_MENU )
			OnOption();
		
	}
	
	public void onLeftKey(){
	}
	
	public void onRightKey(){
	}
	
	public void onDownKey(){
		
	}
	
	public void onUpKey(){
		
	}
	//kjh end
	public void OnCommand(int nCmd) {
		if(m_nStep != 1)
			return;
    	switch (nCmd) {
    	case CMD_PAUSE_ASYNC:	OnPause(); break;
    	case CMD_MENU_ASYNC:	OnOption();	break;
    	case CMD_SELECT_CLOSE:	Close();	break;
    	}
    }
	
	public void OnExit() {
		Close();
	}
	
	public void OnPause() {
		// SKY:121120:start
		Globals.stopBGM();
		Globals.stopMyBGM();
		// SKY:end
		setMode(0);
	}

	public void MessageBoxClosed(int dlgid) {
		switch(dlgid) {
		case 2:
			if(Globals.m_bShowYesNo) {
		        getView().getActivity().showAlertDialog( 3 );	//kjh
			}
			else {
				m_bMenu = false;
				resume();
			}
			if (Globals.m_bClickClose) { // if user clicks close button, ...
				OnClickMenuClose();
			}
			break;
		case 3:
			if(Globals.m_bSelYes) {
				PostMessage(WM_COMMAND, CMD_SELECT_CLOSE, 0);
			}
			else {
				m_bMenu = false;
				resume();
			}
			break;
		}
	}

	public void OnOption() {
		if (m_bMenu)
			return;
		m_bMenu = true;
		updateFocusBtns( BTN_FOCUS_MENU );				//kjh
		pause();
        getView().getActivity().showAlertDialog( 2 );	//kjh

	}
	
	private void Close() {
		// SKY:121120:start
		Globals.stopBGM();
		Globals.stopMyBGM();
		// SKY:end
		
		//RemoveAllButtons();

		m_nStep = 2;
		m_timeProc = STD.GetTickCount();
	}

	public void OnMenu() {
	}

	private int GetStepAlpha() {
		if (m_timeProc == 0)
			return 255;

		long curTime = STD.GetTickCount();
		int	nAlpha = 255;
		long timeElapse = curTime - m_timeProc;

		if(m_nStep == 0) {
			if(timeElapse >= OPEN_FRAME_COUNT * Globals.MS_PER_FRAME) {
				m_nStep ++;
				createButtons();
				m_timeProc = curTime;
				timeElapse = 0;
			}
			else {
				float	fAlpha = 255.0f;

				fAlpha *= (float)timeElapse;
				fAlpha /= (float)(OPEN_FRAME_COUNT * Globals.MS_PER_FRAME);
				nAlpha = (int)fAlpha;
			}
		}
		if(m_nStep == 2) {
			if(timeElapse >= CLOSE_FRAME_COUNT * Globals.MS_PER_FRAME) {
				nAlpha = 0;
				DestroyWindow( frmWndMgr.WND_TITLE );
			}
			else {
				float	fAlpha = 255.0f;

				fAlpha *= (float)timeElapse;
				fAlpha /= (float)(CLOSE_FRAME_COUNT * Globals.MS_PER_FRAME);
				nAlpha = (int)(255.0 - fAlpha);
			}
		}

		return nAlpha;
	}

	private void pause() {
		m_timePauseStart = STD.GetTickCount();
		m_bPauseFinished = false;
		
		// SKY:121128:start
		if ( Globals.m_bHomekeyPressed )
		{
			Globals.pauseMyBGM();
			Globals.pauseBGM(); //by LYM 2013/01/04
//			Globals.m_bHomekeyPressed = false;
		}
		// SKY:end
	}

	private void resume() {
		m_bPauseFinished = true;
		
		if ( Globals.m_bHomekeyPressed )
		{
			Globals.resumeMyBGM();// SKY:121128
			Globals.resumeBGM(); //by LYM 2013/01/04
			Globals.m_bHomekeyPressed = false;
		}
	}

	public void OnSuspend() {
		pause();
	}

	public void OnResume() {
		resume();
	}
	
	private void setMode(int nMode) {
		m_screenMode = nMode;
		if (nMode == 0) {
			m_imgTitle1.setVisible(true);
			m_imgTitle2.setVisible(false);
			m_btnPause.setVisible(false);
			
			m_imgBtnPauseNor.setVisible(false);
			m_imgBtnPauseFoc.setVisible(false);
			
			Globals.stopBGM();
			Globals.stopMyBGM();			// SKY:121128
		}
		else {
			m_imgTitle1.setVisible(false);
			m_imgTitle2.setVisible(true);
			m_btnPause.setVisible(true);
			
			m_imgBtnPauseNor.setVisible(true);
			m_imgBtnPauseFoc.setVisible(true);

			loadSoundImagePlay(Globals.m_nTextFileID);
		}
		
		m_bToggle = false;
	}
	
	private boolean m_bTouched = false;
	private int m_nPrevTouchEventPosY;
	private int m_nScrollPtByTouchMove = 0;
	private long m_touchStartTick = 0;
	private int m_touchStartKind = -1;
	private int m_selectedSoundKind = -1;
	private int m_touchStartY = -1;
	
	public void OnTouchDown(int x, int y) {
		if (m_screenMode != 0 || m_bToggle)
			return;
		
		if (m_selectedSoundKind >= 0)
			return;
		
		m_bTouched = true;
		m_nPrevTouchEventPosY = y;
		m_touchStartTick = STD.GetTickCount();
		m_touchStartKind = getSoundKindIndex(x,y);
		m_touchStartY = y;
	}

	public boolean OnTouchUp(int x, int y) {
		if (m_screenMode != 0 || m_bToggle)
			return false;
		
		if (m_selectedSoundKind >= 0)
			return false;
		
		OnTouchMove(x, y);
		m_bTouched = false;
		if (STD.GetTickCount()-m_touchStartTick < 300 && m_touchStartY-y<20) { //200ms
			if (m_touchStartKind >= 0 && m_touchStartKind == getSoundKindIndex(x,y)) {
				Globals.m_nTextFileID = m_touchStartKind;
				m_selectedSoundKind = m_touchStartKind;
				SetTimer(ID_TIMER_0, 300);
				m_bToggle = true;
			}
		}
		
		m_touchStartKind = -1;
		return false;
	}
	
	public void OnTouchMove(int x, int y) {
		if (m_screenMode != 0 || m_bToggle)
			return;
		
		if (m_selectedSoundKind >= 0)
			return;
		
		m_nScrollPtByTouchMove += (y - m_nPrevTouchEventPosY);
		m_fSoundKindButtonStartPos += (y - m_nPrevTouchEventPosY);
		m_nPrevTouchEventPosY = y;
		
		adjustScrollPos();
	}
	
	private final static int SOUND_BUTTON_HEIGHT = 85;
	private final static int SOUND_KIND_BUTTON_START_Y = 62+10;
	private final static int SOUND_KIND_BUTTON_END_Y = 960-62-62-10;
	
	public void adjustScrollPos() {
		if (m_fSoundKindButtonStartPos > 0.0f)
			m_fSoundKindButtonStartPos = 0.0f;
		if (m_fSoundKindButtonStartPos+SOUND_KIND_COUNT*SOUND_BUTTON_HEIGHT<SOUND_KIND_BUTTON_END_Y)
			m_fSoundKindButtonStartPos = SOUND_KIND_BUTTON_END_Y-SOUND_KIND_COUNT*SOUND_BUTTON_HEIGHT;
	}
	
	public int getSoundKindIndex(int x, int y) {
		if (x < 80 || x > 80+478)
			return -1;
		
		int index = (int)((y - m_fSoundKindButtonStartPos-SOUND_KIND_BUTTON_START_Y) / SOUND_BUTTON_HEIGHT);
		if (index >= SOUND_KIND_COUNT)
			return -1;
		
		int index1 = (int)((y - m_fSoundKindButtonStartPos-SOUND_KIND_BUTTON_START_Y - 70) / SOUND_BUTTON_HEIGHT);
		if (index1 > 0 && index == index1)
			return -1;
		
		return index;
	}
	
	public void OnTimer(int nTimerID) {
		if (nTimerID == ID_TIMER_0) {
			if (m_selectedSoundKind >= 0) {
				m_selectedSoundKind = -1;
			}
			else {
				KillTimer(ID_TIMER_0);
				setMode(1);
			}
		}
		super.OnTimer(nTimerID);
	}
}
