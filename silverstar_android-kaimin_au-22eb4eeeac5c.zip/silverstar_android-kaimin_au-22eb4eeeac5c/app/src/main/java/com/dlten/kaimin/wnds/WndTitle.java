package com.dlten.kaimin.wnds;

import com.dlten.lib.STD;
import com.dlten.lib.frmWork.CButton;
import com.dlten.lib.frmWork.CWnd;
import com.dlten.lib.graphics.CImgObj;
import com.dlten.kaimin.Globals;
import com.dlten.kaimin.frmWndMgr;
import com.dlten.kaimin.kaimin;

public class WndTitle extends CWnd {

	private int 	nCountList;
	private static final int		nStep = 1; //if nStep is 1, an app contains air_bubble. if nstep is 2, an app contains air_bubble and sheep_box.
	private int 	m_nStep;
	private	long	m_timeProc;
	private int 	m_nReturnCode;

	private static long OPEN_FRAME_COUNT = 20;
	private static long CLOSE_FRAME_COUNT = 20;

	private static int SHEET1_FRAME_COUNT = 200;
//	private static int SHEET1_FRAME_START = 20;
	private static int[] SHEET1_START_FRAME = new int[] {0, 20, 40};
	private static int[] SHEET1_HIDE_FRAME = new int[] {80, 100, 120};
	private static int[] SHEET1_END_FRAME = new int[] {100, 120, 140};
	private static float[] SHEET1_START_X = new float[] {336.596f, 339.5f, 339.5f}; // {22.096f, 25, 25};
	private static float[] SHEET1_START_Y = new float[] {386.678f, 383.774f, 383.774f}; // {86.822f, 89.726f, 89.726f};
	private static float[] SHEET1_END_X = new float[] {393.596f, 396.5f, 396.5f}; // {79.096f, 82, 82};
	private static float[] SHEET1_END_Y = new float[] {350.404f, 347.5f, 347.5f}; // {123.096f, 126, 126};

	private CImgObj m_imgBg   = new CImgObj();
	private CImgObj m_imgVer   = new CImgObj();
	private CImgObj m_imgSheet   = new CImgObj();
	private CImgObj m_imgSheet1   = new CImgObj();
	private CImgObj[] m_imgComment ;
	private CImgObj	m_imgChangeUpNor = new CImgObj();
	private CImgObj	m_imgChangeUpFoc = new CImgObj();
	private CImgObj	m_imgChangeDownNor  = new CImgObj();
	private CImgObj	m_imgChangeDownFoc  = new CImgObj();
	private CImgObj[]	m_imgModeNor;
	private CImgObj[]	m_imgModeFoc;
	private CImgObj m_imgHelp   = new CImgObj();
//	private CImgObj m_imgPrivacy   = new CImgObj();

	private CButton	m_btnChangeUp 		= null;
	private CButton	m_btnChangeDown  	= null;
	private CButton	m_btnMode     		= null;
	private CButton	m_btnHelp  			= null;
//	private CButton	m_btnPrivacy		= null;
	
	public static final int
		MODE_TEXT = 0,
		MODE_PI = 1,
		MODE_CAR = 2,
		MODE_SHEET = 3,
		MODE_BLOCK = 4,
		MODE_LAW = 5,
		MODE_SOUND = 6, // SKY:120615
		MODE_RPG = 7, // LYM:130620
		MODE_AIR_BUBBLE = 8,
		MODE_SHEEP_BOX = 9;


	public static int MODE_MAX = MODE_RPG;//by Kwang 20121126
	private static int m_nMode = MODE_TEXT;
	
    public static final int
		CMD_CHANGE_UP = 0,
		CMD_CHANGE_DOWN  = 1,
		CMD_SELECT_ASYNC = 2,
    	CMD_SELECT_CLOSE = 3,
    	CMD_HELP = 4;
//    	CMD_PRIVACY = 5;		
    
    //kjh start
	private static final int	BTN_FOCUS_SCROLL_DOWN			=	100;
	private static final int	BTN_FOCUS_SCROLL_UP				=	101;
	private static final int	BTN_FOCUS_GOTOGAME				=	102;
	private static final int	BTN_FOCUS_HELP					=	103;
//	private static final int	BTN_FOCUS_PRIVACY				=	104;
	
	public int					m_nCurFoucus	=	-1;
	
	public void initFocusBtns(){
		
			if( m_btnChangeDown != null )
				m_btnChangeDown.setNormal();
			if( m_btnChangeUp != null )
				m_btnChangeUp.setNormal();
			if( m_btnMode != null )
				m_btnMode.setNormal();
			if( m_btnHelp != null )
				m_btnHelp.setNormal();
//			if( m_btnPrivacy != null )
//				m_btnPrivacy.setNormal();
			
	}
	
	public void updateFocusBtns( int nFocusBtn ){
		
		if( !kaimin.m_bSBTV )
			return;
		
//		if( m_nCurFoucus == nFocusBtn )
//			return;
		try {
			
			initFocusBtns();
			
			switch ( nFocusBtn ) {
				case BTN_FOCUS_SCROLL_UP:
					if( m_btnChangeUp != null )
						m_btnChangeUp.setFocus();
	//				m_Btns.setFocusState( true );
					break;
				case BTN_FOCUS_SCROLL_DOWN:
	//				m_btnOption.setFocusState( true );
					if( m_btnChangeDown != null )
						m_btnChangeDown.setFocus();
					break;
				case BTN_FOCUS_GOTOGAME:
	//				m_btnAbout.setFocusState( true );
					if( m_btnMode != null )
						m_btnMode.setFocus();
					break;
				case BTN_FOCUS_HELP:
					if( m_btnHelp != null )
						m_btnHelp.setFocus();
					break;
//				case BTN_FOCUS_PRIVACY:
//					if( m_btnPrivacy != null )
//						m_btnPrivacy.setFocus();
//					break;
			default:
				break;
			}	
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		m_nCurFoucus	=	nFocusBtn;
		
	}
	//kjh end
	
	
	public void OnLoadResource() {
		//setString("Title Wnd");

		Globals.m_bBGMDisable = true;
		Globals.m_bSEDisable = true;

		Globals.playBGM(2);

		nCountList = 8;

		if (nStep == 1)
		{
			nCountList = 9;
			MODE_MAX = MODE_AIR_BUBBLE;
		}
		else if (nStep == 2)
		{
			nCountList = 10;
			MODE_MAX = MODE_SHEEP_BOX;
		}
		m_imgComment   = new CImgObj[nCountList];
		m_imgModeNor     = new CImgObj[nCountList];
		m_imgModeFoc     = new CImgObj[nCountList];

		createImages();

		m_nStep = 0;
		m_timeProc = STD.GetTickCount();
		
		if (kaimin.m_bSBTV)//by Kwang 20121126
			MODE_MAX = MODE_LAW;
	}
	public void OnInitWindow() {
	}
	public void OnShowWindow() {	
		if (Globals.m_bFirst) {
			Globals.m_bFirst = false;
			Globals.SaveSetting();
			
//			getView().getActivity().showAlertDialog( 6 ); //push notification confirm dialog
		}
	}
	
	private void createImages() {
		
//		boolean		bRealSize = !kaimin.m_bSBTV;			//kjh
		
		if( kaimin.m_bSBTV ){
			m_imgBg.load("A1/A1_background_sbtv.png");	
		}else{
			m_imgBg.load("A1/A1_background.png");
		}
		
		//kjh start
		m_imgVer.load("A1/A1_ver.png");
		m_imgSheet.load("A1/A1_sheep_1.png");
		m_imgSheet1.load("A1/A1_sheep_2.png");

		
//		m_imgComment[0] = new CImgObj("A1/A1_comment_B1.png");
//		m_imgComment[1] = new CImgObj("A1/A1_comment_C1.png");
//		m_imgComment[2] = new CImgObj("A1/A1_comment_D1.png");
//		m_imgComment[3] = new CImgObj("A1/A1_comment_E1.png");
//		m_imgComment[4] = new CImgObj("A1/A1_comment_F1.png");
//		m_imgComment[5] = new CImgObj("A1/A1_comment_G1.png"); // SKY:120615
		
//		m_imgComment[0] = new CImgObj("A1/A1_comment_B1.png", kaimin.m_bSBTV );
//		m_imgComment[1] = new CImgObj("A1/A1_comment_C1.png", kaimin.m_bSBTV );
//		m_imgComment[2] = new CImgObj("A1/A1_comment_D1.png", kaimin.m_bSBTV );
//		m_imgComment[3] = new CImgObj("A1/A1_comment_E1.png", kaimin.m_bSBTV );
//		m_imgComment[4] = new CImgObj("A1/A1_comment_F1.png", kaimin.m_bSBTV );
//		m_imgComment[5] = new CImgObj("A1/A1_comment_G1.png", kaimin.m_bSBTV );

		m_imgComment[0] = new CImgObj("A1/A1_comment_B1.png", kaimin.m_bSBTV );
		m_imgComment[1] = new CImgObj("A1/A1_comment_C1.png", kaimin.m_bSBTV );
		m_imgComment[2] = new CImgObj("A1/A1_comment_D1.png", kaimin.m_bSBTV );
		
		//kjh start
//		m_imgComment[3] = new CImgObj("A1/A1_comment_E1.png", kaimin.m_bSBTV );
		if( kaimin.m_bSBTV )
			m_imgComment[3] = new CImgObj("A1/A1_comment_E1_sbtv.png", kaimin.m_bSBTV );
		else
			m_imgComment[3] = new CImgObj("A1/A1_comment_E1.png", kaimin.m_bSBTV );
		//kjh end
		
		m_imgComment[4] = new CImgObj("A1/A1_comment_F1.png", kaimin.m_bSBTV );
		m_imgComment[5] = new CImgObj("A1/A1_comment_G1.png", kaimin.m_bSBTV );
		m_imgComment[6] = new CImgObj("A1/A1_comment_H1.png", kaimin.m_bSBTV );
		m_imgComment[7] = new CImgObj("A1/A1_comment_I1.png", kaimin.m_bSBTV );
		if (nCountList == 9)
		{
			m_imgComment[8] = new CImgObj("G1/air_bubble_explain.png", kaimin.m_bSBTV );
		}
		if (nCountList == 10)
		{
			m_imgComment[8] = new CImgObj("G1/air_bubble_explain.png", kaimin.m_bSBTV );
			m_imgComment[9] = new CImgObj("G1/sheep_box_explain.png", kaimin.m_bSBTV );
		}

		
		m_imgHelp.load("A1/aplibtn.png", kaimin.m_bSBTV );
//		m_imgPrivacy.load("A1/privacy.png", kaimin.m_bSBTV );
		m_imgChangeUpNor.load("A1/A1_btn_change_up_1.png", kaimin.m_bSBTV );
		m_imgChangeDownNor.load("A1/A1_btn_change_down_1.png", kaimin.m_bSBTV );
		
		if( kaimin.m_bSBTV ){
			
			m_imgModeNor[0] = new CImgObj("A1/A1_btn_mode_B1_1.png", kaimin.m_bSBTV );
			m_imgModeNor[1] = new CImgObj("A1/A1_btn_mode_C1_1.png", kaimin.m_bSBTV );
			m_imgModeNor[2] = new CImgObj("A1/A1_btn_mode_D1_1.png", kaimin.m_bSBTV );
			m_imgModeNor[3] = new CImgObj("A1/A1_btn_mode_E1_1.png", kaimin.m_bSBTV );		
			m_imgModeNor[4] = new CImgObj("A1/A1_btn_mode_F1_1.png", kaimin.m_bSBTV );
			m_imgModeNor[5] = new CImgObj("A1/A1_btn_mode_G1_1.png", kaimin.m_bSBTV ); // SKY:120615
			m_imgModeNor[6] = new CImgObj("A1/A1_btn_mode_H1_1.png", kaimin.m_bSBTV ); // Kwang
			m_imgModeNor[7] = new CImgObj("A1/A1_btn_mode_I1_1.png", kaimin.m_bSBTV ); // Lym
			if (nCountList == 9)
			{
				m_imgModeNor[8] = new CImgObj("G1/air_bubble_start_btn_normal.png", kaimin.m_bSBTV );
			}
			if (nCountList == 10)
			{
				m_imgModeNor[8] = new CImgObj("G1/air_bubble_start_btn_normal.png", kaimin.m_bSBTV );
				m_imgModeNor[9] = new CImgObj("G1/sheep_box_btn_normal.png", kaimin.m_bSBTV );
			}

			m_imgChangeUpFoc.load("A1/A1_btn_change_up_2_sbtv.png", kaimin.m_bSBTV );
			m_imgChangeDownFoc.load("A1/A1_btn_change_down_2_sbtv.png", kaimin.m_bSBTV );
			m_imgModeFoc[0] = new CImgObj("A1/A1_btn_mode_B1_2_sbtv.png", kaimin.m_bSBTV );
			m_imgModeFoc[1] = new CImgObj("A1/A1_btn_mode_C1_2_sbtv.png", kaimin.m_bSBTV );
			m_imgModeFoc[2] = new CImgObj("A1/A1_btn_mode_D1_2_sbtv.png", kaimin.m_bSBTV );
			m_imgModeFoc[3] = new CImgObj("A1/A1_btn_mode_E1_2_sbtv.png", kaimin.m_bSBTV );
			m_imgModeFoc[4] = new CImgObj("A1/A1_btn_mode_F1_2_sbtv.png", kaimin.m_bSBTV );
			m_imgModeFoc[5] = new CImgObj("A1/A1_btn_mode_G1_2_sbtv.png", kaimin.m_bSBTV ); // SKY:120615
			m_imgModeFoc[6] = new CImgObj("A1/A1_btn_mode_H1_2_sbtv.png", kaimin.m_bSBTV ); // Kwang
			m_imgModeFoc[7] = new CImgObj("A1/A1_btn_mode_I1_2_sbtv.png", kaimin.m_bSBTV ); // Lym
			if (nCountList == 9)
			{
				m_imgModeFoc[8] = new CImgObj("G1/air_bubble_start_btn_press.png", kaimin.m_bSBTV );
			}
			if (nCountList == 10)
			{
				m_imgModeFoc[8] = new CImgObj("G1/air_bubble_start_btn_press.png", kaimin.m_bSBTV );
				m_imgModeFoc[9] = new CImgObj("G1/sheep_box_btn_press.png", kaimin.m_bSBTV );
			}
			
		}else{

			m_imgModeNor[0] = new CImgObj("A1/A1_btn_mode_B1_1.png");
			m_imgModeNor[1] = new CImgObj("A1/A1_btn_mode_C1_1.png");
			m_imgModeNor[2] = new CImgObj("A1/A1_btn_mode_D1_1.png");
			m_imgModeNor[3] = new CImgObj("A1/A1_btn_mode_E1_1.png");		
			m_imgModeNor[4] = new CImgObj("A1/A1_btn_mode_F1_1.png");
			m_imgModeNor[5] = new CImgObj("A1/A1_btn_mode_G1_1.png"); // SKY:120615
			m_imgModeNor[6] = new CImgObj("A1/A1_btn_mode_H1_1.png"); //Kwang
			m_imgModeNor[7] = new CImgObj("A1/A1_btn_mode_I1_1.png"); //Lym
			if (nCountList == 9)
			{
				m_imgModeNor[8] = new CImgObj("G1/air_bubble_start_btn_normal.png");
			}
			if (nCountList == 10)
			{
				m_imgModeNor[8] = new CImgObj("G1/air_bubble_start_btn_normal.png");
				m_imgModeNor[9] = new CImgObj("G1/sheep_box_btn_normal.png");
			}

			m_imgChangeUpFoc.load("A1/A1_btn_change_up_2.png");
			m_imgChangeDownFoc.load("A1/A1_btn_change_down_2.png");
			m_imgModeFoc[0] = new CImgObj("A1/A1_btn_mode_B1_2.png");
			m_imgModeFoc[1] = new CImgObj("A1/A1_btn_mode_C1_2.png");
			m_imgModeFoc[2] = new CImgObj("A1/A1_btn_mode_D1_2.png");
			m_imgModeFoc[3] = new CImgObj("A1/A1_btn_mode_E1_2.png");
			m_imgModeFoc[4] = new CImgObj("A1/A1_btn_mode_F1_2.png");
			m_imgModeFoc[5] = new CImgObj("A1/A1_btn_mode_G1_2.png"); // SKY:120615
			m_imgModeFoc[6] = new CImgObj("A1/A1_btn_mode_H1_2.png"); // Kwang
			m_imgModeFoc[7] = new CImgObj("A1/A1_btn_mode_I1_2.png"); // Lym
			if (nCountList == 9)
			{
				m_imgModeFoc[8] = new CImgObj("G1/air_bubble_start_btn_press.png");
			}
			if (nCountList == 10)
			{
				m_imgModeFoc[8] = new CImgObj("G1/air_bubble_start_btn_press.png");
				m_imgModeFoc[9] = new CImgObj("G1/sheep_box_btn_press.png");
			}
		}
		
		if( kaimin.m_bSBTV ){
			m_imgVer.setSBTVScale( true );
			m_imgSheet.setSBTVScale( true );
			m_imgSheet1.setSBTVScale( true );
			m_imgComment[ 0 ].setSBTVScale( true );
			m_imgComment[ 1 ].setSBTVScale( true );
			m_imgComment[ 2 ].setSBTVScale( true );
			m_imgComment[ 3 ].setSBTVScale( true );
			m_imgComment[ 4 ].setSBTVScale( true );
			m_imgComment[ 5 ].setSBTVScale( true );
			m_imgComment[ 6 ].setSBTVScale( true );
			m_imgComment[ 7 ].setSBTVScale( true );
			if (nCountList == 9)
			{
				m_imgComment[ 8 ].setSBTVScale( true );
			}
			if (nCountList == 10)
			{
				m_imgComment[ 8 ].setSBTVScale( true );
				m_imgComment[ 9 ].setSBTVScale( true );
			}
			
			m_imgChangeUpNor.setSBTVScale( true );
			m_imgChangeUpFoc.setSBTVScale( true );
			m_imgChangeDownNor.setSBTVScale( true );
			m_imgChangeDownFoc.setSBTVScale( true );

			m_imgModeNor[0].setSBTVScale( true );
			m_imgModeFoc[0].setSBTVScale( true );

			m_imgModeNor[1].setSBTVScale( true );
			m_imgModeFoc[1].setSBTVScale( true );

			m_imgModeNor[2].setSBTVScale( true );
			m_imgModeFoc[2].setSBTVScale( true );

			m_imgModeNor[3].setSBTVScale( true );
			m_imgModeFoc[3].setSBTVScale( true );

			m_imgModeNor[4].setSBTVScale( true );
			m_imgModeFoc[4].setSBTVScale( true );

			m_imgModeNor[5].setSBTVScale( true );
			m_imgModeFoc[5].setSBTVScale( true );

			m_imgModeNor[6].setSBTVScale( true );
			m_imgModeFoc[6].setSBTVScale( true );
			
			m_imgModeNor[7].setSBTVScale( true );
			m_imgModeFoc[7].setSBTVScale( true );
			if (nCountList == 9)
			{
				m_imgModeNor[8].setSBTVScale( true );
				m_imgModeFoc[8].setSBTVScale( true );
			}
			if (nCountList == 10)
			{
				m_imgModeNor[8].setSBTVScale( true );
				m_imgModeFoc[8].setSBTVScale( true );
				m_imgModeNor[9].setSBTVScale( true );
				m_imgModeFoc[9].setSBTVScale( true );
			}
		}
		
		int nOffsetX	=	0;
		if( kaimin.m_bSBTV )
			nOffsetX	=	28;
		
		m_imgBg.moveTo(0, 0);
		m_imgVer.moveTo(513 + nOffsetX, 343);
		m_imgSheet.moveTo(275 + nOffsetX, 377);
		m_imgComment[0].moveTo(61 + nOffsetX, m_selectButttonY);
		m_imgComment[1].moveTo(61 + nOffsetX, m_selectButttonY);
		m_imgComment[2].moveTo(61 + nOffsetX, m_selectButttonY);
		m_imgComment[3].moveTo(61 + nOffsetX, m_selectButttonY);
		m_imgComment[4].moveTo(61 + nOffsetX, m_selectButttonY);
		m_imgComment[5].moveTo(61 + nOffsetX, m_selectButttonY);
		m_imgComment[6].moveTo(61 + nOffsetX, m_selectButttonY);
		m_imgComment[7].moveTo(61 + nOffsetX, m_selectButttonY);
		if (nCountList == 9)
		{
			m_imgComment[8].moveTo(61 + nOffsetX, m_selectButttonY);
		}
		if (nCountList == 10)
		{
			m_imgComment[8].moveTo(61 + nOffsetX, m_selectButttonY);
			m_imgComment[9].moveTo(61 + nOffsetX, m_selectButttonY);
		}

		m_imgChangeUpNor.moveTo(282-10 + nOffsetX, m_upButtonY);
		m_imgChangeDownNor.moveTo(282-10 + nOffsetX, m_downButtonY);

	}
	
	int m_upButtonY = 482-( ( kaimin.m_bSBTV ) ? 0 : 15 );
	int m_downButtonY = 662;
	int m_selectButttonY = 752;
	
	public void createButtons() {
		
		int nOffsetX	=	0;
		if( kaimin.m_bSBTV )
			nOffsetX	=	28;
		
		CButton	btn = null;

		btn = createButton(
				m_imgChangeUpNor,
				m_imgChangeUpFoc,
				null);
		btn.setPoint(282-10 + nOffsetX, m_upButtonY);
		btn.setCommand( CMD_CHANGE_UP );
		m_btnChangeUp = btn;

		btn = createButton(
				m_imgChangeDownNor,
				m_imgChangeDownFoc,
				null);
		btn.setPoint(282-10 + nOffsetX, m_downButtonY);
		btn.setCommand( CMD_CHANGE_DOWN );
		m_btnChangeDown = btn;

		btn = createButton(
				m_imgModeNor[0],
				m_imgModeFoc[0],
				null);
		btn.setPoint(81 + nOffsetX, 566);
		btn.setCommand( CMD_SELECT_ASYNC );
		btn.setAsyncFlag(true);
		m_btnMode = btn;
		
		btn = createButton(
				m_imgHelp,
				m_imgHelp,
				null);
		btn.setPoint(536 + nOffsetX, 5);
		btn.setCommand( CMD_HELP );
		m_btnHelp = btn;
		
//		btn = createButton(
//				m_imgPrivacy,
//				m_imgPrivacy,
//				null);
//		btn.setPoint(384 + nOffsetX, 5);
//		btn.setCommand( CMD_PRIVACY );
//		m_btnPrivacy = btn;
		
		//kjh start
		updateFocusBtns( BTN_FOCUS_SCROLL_UP );
		//kjh end
		
	}
	
	private void SetMode(int nMode) {
		m_nMode = nMode;

		m_btnMode.setImage_Normal(m_imgModeNor[m_nMode]);
		m_btnMode.setImage_Focus(m_imgModeFoc[m_nMode]);
	}

	public void OnPaint() {
		// drawing dimmension is just Globals.RES_WIDTH * Globals.RES_HEIGHT
		drawBackGround();
		drawSheet();

		int nAlpha = GetStepAlpha();
		setViewAlpha(nAlpha);
	}
	
	public void OnKeyDown( int keycode ) {
		
		switch (keycode) {
		case KEY_MENU:		OnMenu();						break;
		case KEY_BACK:		OnExit();						break;
		
		//kjh start
		case KEY_DPAD_CENTER:
			onDPADCenter();
			break;
			
		case KEY_DPAD_DOWN:
			onDownKey();
			break;
			
		case KEY_DPAD_UP:
			onUpKey();
			break;
			
		case KEY_DPAD_LEFT:
		case KEY_DPAD_RIGHT:
			onLeftRightKey();
			break;
			
		default:			super.OnKeyDown(keycode);		break;
		
		}
	}

	public void onDPADCenter(){
		
		updateFocusBtns( BTN_FOCUS_GOTOGAME );
		OnSelect();
		
	}
	
	public void onLeftRightKey(){
		updateFocusBtns( BTN_FOCUS_HELP );
		OnHelp();
	}
	
	public void onDownKey(){
		
		updateFocusBtns( BTN_FOCUS_SCROLL_DOWN );
		OnChangeDown();
		
	}
	
	public void onUpKey(){
		updateFocusBtns( BTN_FOCUS_SCROLL_UP );
		OnChangeUp();
	}
	
	
	public void OnCommand(int nCmd) {
		if(m_nStep != 1)
			return;
    	switch (nCmd) {
    	case CMD_CHANGE_UP:			OnChangeUp();	break;
    	case CMD_CHANGE_DOWN:		OnChangeDown();	break;
    	case CMD_SELECT_ASYNC:		OnSelect();		break;
    	case CMD_SELECT_CLOSE:		Close();		break;
    	case CMD_HELP:				OnHelp();		break;
//    	case CMD_PRIVACY:			OnPrivacy();	break;
    	}
    }
	
	public void OnExit() {
		m_nReturnCode = frmWndMgr.WND_DESTROYAPP;
		Close();
	}

	private void Close() {
		m_nStep = 2;
		m_timeProc = STD.GetTickCount();

		RemoveAllButtons();
	}

	private void CloseReq(int nReturnCode) {
		m_nReturnCode = nReturnCode;
		PostMessage(WM_COMMAND, CMD_SELECT_CLOSE, 0);
	}

	public void OnMenu() {
	}

	public void OnChangeUp() {
		updateFocusBtns( BTN_FOCUS_SCROLL_UP );						//kjh
		if( kaimin.m_bSBTV )
			SetMode((m_nMode > 0) ? (m_nMode - 1) : /*MODE_BLOCK*/MODE_MAX);//SKY:120615 //by Kwang 20121126
		else
			SetMode((m_nMode > 0) ? (m_nMode - 1) : /*MODE_BLOCK*/MODE_MAX);//SKY:120615
	}

	public void OnChangeDown() {
		updateFocusBtns( BTN_FOCUS_SCROLL_DOWN );					//kjh
		if( kaimin.m_bSBTV )
			SetMode((m_nMode < /*MODE_BLOCK*/MODE_MAX) ? (m_nMode + 1) : MODE_TEXT); // SKY:120615 //by Kwang 20121126
		else
			SetMode( ( m_nMode < /*MODE_BLOCK*/MODE_MAX) ? (m_nMode + 1) : MODE_TEXT); // SKY:120615
	}
	
	public void OnHelp() {
		getView().getActivity().showAlertDialog( 7 );	//kjh
	}
	
//	public void OnPrivacy() {
//		getView().getActivity().showPrivacy();
//	}

	public void MessageBoxClosed(int dlgid) {
		if(Globals.m_nTextFileID >= 0) {
			// SKY:120615:start
			if (dlgid == 1) 
				CloseReq(frmWndMgr.WND_READ);
			else if (dlgid == 100)
				CloseReq(frmWndMgr.WND_LAW);
			else if (dlgid == 101)
				CloseReq(frmWndMgr.WND_SOUND);
			// SKY:end
		}
	}

	public void OnSelect() {
		
		updateFocusBtns( BTN_FOCUS_GOTOGAME );			//kjh

		switch(m_nMode) {
		case MODE_TEXT:
//	        getView().getActivity().showDialog(1);			//kjh
			getView().getActivity().showAlertDialog( 1 );	//kjh
			break;
		case MODE_PI:
			CloseReq(frmWndMgr.WND_PI);
			break;
		case MODE_CAR:
			CloseReq(frmWndMgr.WND_CAR);
			break;
		case MODE_SHEET:
			CloseReq(frmWndMgr.WND_SHEET);
			break;
		case MODE_BLOCK:
			CloseReq(frmWndMgr.WND_BLOCK);
			break;
		case MODE_LAW:
//	        getView().getActivity().showDialog(100);// SKY:120615
	        getView().getActivity().showAlertDialog( 100 );	//kjh
			break;
		case MODE_SOUND:
//	        getView().getActivity().showDialog(100);// SKY:120615
//	        getView().getActivity().showAlertDialog( 101 );	//kjh
			CloseReq(frmWndMgr.WND_SOUND);
			break;
		case MODE_RPG:
			CloseReq(frmWndMgr.WND_RPG);
			break;
			case MODE_AIR_BUBBLE:
				CloseReq(frmWndMgr.WND_AIR_BUBBLE);
				break;
			case MODE_SHEEP_BOX:
				CloseReq(frmWndMgr.WND_SHEEP_BOX);
				break;
		}
	}

	private int GetStepAlpha() {
		if (m_timeProc == 0)
			return 255;

		int	nAlpha = 255;
		long timeElapse = STD.GetTickCount() - m_timeProc;

		if(m_nStep == 0) {
			if(timeElapse >= OPEN_FRAME_COUNT * Globals.MS_PER_FRAME) {
				m_nStep ++;
				createButtons();
				SetMode(m_nMode);
				m_timeProc = STD.GetTickCount();
				timeElapse = 0;
			}
			else {
				float	fAlpha = 255.0f;

				fAlpha *= (float)timeElapse;
				fAlpha /= (float)(OPEN_FRAME_COUNT * Globals.MS_PER_FRAME);
				nAlpha = (int)fAlpha;
			}
		}
		if(m_nStep == 2) {
			if(timeElapse >= CLOSE_FRAME_COUNT * Globals.MS_PER_FRAME) {
				nAlpha = 0;
				Globals.stopBGM();
				DestroyWindow( m_nReturnCode );
			}
			else {
				float	fAlpha = 255.0f;

				fAlpha *= (float)timeElapse;
				fAlpha /= (float)(CLOSE_FRAME_COUNT * Globals.MS_PER_FRAME);
				nAlpha = (int)(255.0 - fAlpha);
			}
		}

		return nAlpha;
	}

	private void drawBackGround() {
		if(m_nStep == 1) {
			m_imgBg.draw();
			m_imgVer.draw();

			m_imgComment[m_nMode].draw();
			
		}
		else {
			m_imgBg.draw();
			m_imgVer.draw();
			m_imgSheet.draw();
			
			//kjh start
			if( kaimin.m_bSBTV ){
				if( MODE_SHEET != m_nMode )
					m_imgComment[m_nMode].draw();
			}else
				m_imgComment[m_nMode].draw();
			
			//kjh end
			m_imgChangeUpNor.draw();
			m_imgChangeDownNor.draw();
			
			//kjh start
			int nOffsetX	=	0;
			if( kaimin.m_bSBTV )
				nOffsetX	=	28;
			m_imgModeNor[m_nMode].draw(81 + nOffsetX, 566);
			//kjh end
		}
	}
	
	private void drawSheet() {
		if(m_nStep != 1)
			return;

		long dtime = STD.GetTickCount() - m_timeProc;

		float frameno = (float)dtime / Globals.MS_PER_FRAME;
		int loopcount = (int)(frameno / SHEET1_FRAME_COUNT);
		frameno -= (loopcount * SHEET1_FRAME_COUNT);
		
		for(int i = 0; i < 3; i ++) {
			if((frameno < SHEET1_START_FRAME[i]) || (frameno > SHEET1_END_FRAME[i]))
				continue;
			
			int nAlpha = 255;
			if(frameno > SHEET1_HIDE_FRAME[i]) {
				float fAlpha = (frameno - SHEET1_HIDE_FRAME[i]) / (SHEET1_END_FRAME[i] - SHEET1_HIDE_FRAME[i]);
				nAlpha = (int)(255 * (1 - fAlpha)); 
			}

			float a = (frameno - SHEET1_START_FRAME[i]) / (SHEET1_END_FRAME[i] - SHEET1_START_FRAME[i]);
			float x = SHEET1_START_X[i] * (1 - a) +  SHEET1_END_X[i] * a;
			float y = SHEET1_START_Y[i] * (1 - a) +  SHEET1_END_Y[i] * a;

			m_imgSheet1.setAlpha(nAlpha);
			
			//kjh start
			int nOffsetX	=	0;
			if( kaimin.m_bSBTV )
				nOffsetX	=	28;
			m_imgSheet1.draw(x + nOffsetX, y);
			//kjh end
			
		}

		m_imgSheet.draw();
	}

	public void OnSuspend() {
		Globals.pauseBGM();
	}

	public void OnResume() {
		Globals.resumeBGM();
	}
}
