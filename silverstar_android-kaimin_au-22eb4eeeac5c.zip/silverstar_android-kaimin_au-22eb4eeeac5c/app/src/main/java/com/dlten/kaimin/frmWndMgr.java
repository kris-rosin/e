package com.dlten.kaimin;

import com.dlten.kaimin.wnds.*;
import com.dlten.kaimin_auOM.R;
import com.dlten.lib.STD;
import com.dlten.lib.file.CConFile;
import com.dlten.lib.frmWork.CWnd;
import com.dlten.lib.frmWork.CWndMgr;
import com.dlten.lib.graphics.CImage;

public class frmWndMgr extends CWndMgr {
	
	private kaimin m_activity;
	private frmView m_view;

    public frmWndMgr( kaimin activity, frmView dc ) {
    	super(dc);
    	
    	m_activity = activity;
    	m_view = dc;
    }
    
    protected void Initialize() {
    	super.Initialize();
    	
    	STD.initRand();
    	CConFile.Initialize(m_activity);
    	CImage.Initialize(m_view);
    	Globals.createGlobalValues( m_activity );
    }
    protected void Finalize() {
    	super.Finalize();
    	Globals.deleteGlobalValues();
    	m_activity.finish();
    }
	@Override
	protected void runProc() {
        int nState = WND_LOGO;
		// int nState = WND_TEST1;

        while (nState > 0) {
            nState = NewWindow(nState);
        }
	}

	@Override
	protected CWnd createWindow(int nWndID, int nParam) {
        CWnd ret = null;
        Globals.m_bSoundTheatre = false;
        Globals.SetTimerType(7);//90分00秒!!!
        Globals.SetMSpeedType(1);//ふつう!!!
        
        switch( nWndID ) {
        
        case WND_LOGO:				ret = new WndLogo(m_activity);			break; // SKY:120322
        case WND_TITLE:				ret = new WndTitle();			break;
        case WND_READ:				ret = new WndRead(false);		break; // SKY:120615
        case WND_PI:				ret = new WndPI();				break;
        case WND_CAR:				ret = new WndDrive();			break;
        case WND_SHEET:				ret = new WndSheet();			break;
        case WND_BLOCK:				ret = new WndBlock();			break;
        case WND_LAW:				ret = new WndRead(true);		break; // SKY:120615
        case WND_SOUND:				ret = new WndSound();			break; //by Kwang 20121015
        case WND_RPG:				ret = new WndRPG();				break; //by Lym 20130620
			case WND_AIR_BUBBLE:	ret = new WndAirB();			break;
			case WND_SHEEP_BOX:     ret = new WndSheepBox();				break;
        }
        return ret;
	}


    public static final int
	    WND_DESTROYAPP	= 0,

	    WND_LOGO		= 3,
	    WND_TITLE		= 4,
	    WND_READ		= 5,
	    WND_PI			= 6,
	    WND_CAR			= 7,
	    WND_SHEET		= 8,
	    WND_BLOCK		= 9,
    	WND_LAW			= 10, // SKY:120615
    	WND_SOUND		= 11, //by kwang
    	WND_RPG			= 12, //by Lym
		WND_AIR_BUBBLE  = 13,
		WND_SHEEP_BOX   = 14;

}
