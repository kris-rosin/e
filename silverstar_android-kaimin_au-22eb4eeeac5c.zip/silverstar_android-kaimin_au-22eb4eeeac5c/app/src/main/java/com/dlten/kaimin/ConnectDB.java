package com.dlten.kaimin;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ConnectDB extends SQLiteOpenHelper{
	
	private static final int DATABASE_VERSION = 3;
    
	public static final String DATABASE_NAME = "Anti-err.db";
    
    private static final String [] TABLES = {"MyTable", 
    										 "item", 
    										 "spec", 
    										 "custom", 
    										 "assets", 
    										 "ledger",
    										 "budget"};
	
    private static final String TABLE_CREATE_ENVIR = "create table MyTable ( id int  NOT NULL, Num int NOT NULL );";
    private static final String TABLE_CREATE_ITEM = "create table item (itemID int   NOT NULL  ,  itemName varchar (10)   NULL ,  itemtype int   NULL );";
    private static final String TABLE_CREATE_SPEC = "create table spec (specID int   NOT NULL  ,  specName varchar (10)   NULL ,  itemID int   NULL );";
    private static final String TABLE_CREATE_CUSTOM = "create table custom (customID int   NOT NULL ,  customName varchar (10)   NOT NULL   );";
    private static final String TABLE_CREATE_ASSETS = "create table assets ( assetsID int   NOT NULL ,  assetsName varchar (10)   NULL  );";
    private static final String TABLE_CREATE_LEDGER = "create table ledger ( ledgerID int   NOT NULL ,  ioDate varchar (10)   NOT NULL ,  itemID int   NOT NULL ,  specID int   NOT NULL ,  amount double (10, 1)   NOT NULL ,  assetsID int   NOT NULL , note varchar(10),  transType int   NOT NULL  );";
    private static final String TABLE_CREATE_BUDGET = "create table budget ( itemID int   NOT NULL ,  budgetDate varchar (10)   NOT NULL ,  amount double   NOT NULL    );";
    
    private static ConnectDB _instance;
    
	private ConnectDB(Context context) {
		
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}
	
	public void onCreate(SQLiteDatabase db) {
	//	initDB(db);
	}

	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}
	
	public void onOpen(SQLiteDatabase db) {}
	
	
	public SQLiteDatabase getWritableDB() {
		
		return getWritableDatabase();
	}
	
	
	public SQLiteDatabase getReadableDB() {
		
		return getReadableDatabase();
	}
	
	public static ConnectDB getInstance(Context context) {
		if (_instance == null) {
			_instance = new ConnectDB(context);
		}
		return _instance;
	}
	
	public void initDB(SQLiteDatabase db) {
			
		db.execSQL(TABLE_CREATE_ENVIR);				
		db.execSQL(TABLE_CREATE_ITEM);
		db.execSQL(TABLE_CREATE_SPEC);
		db.execSQL(TABLE_CREATE_CUSTOM );
		db.execSQL(TABLE_CREATE_ASSETS);
		db.execSQL(TABLE_CREATE_LEDGER); 
		db.execSQL(TABLE_CREATE_BUDGET );
		db.execSQL("insert into MyTable values ('1', '0')");
	
		db.execSQL("insert into item values ('1', 'ë°›ì�€ë�ˆ', '4')");
		db.execSQL("insert into item values ('2', 'ì¤€ë�ˆ', '3')");
		db.execSQL("insert into item values ('5', 'ì •ê¸°ìˆ˜ìž…', '2')");
		db.execSQL("insert into item values ('6', 'ê¸°íƒ€ìˆ˜ìž…', '2')");
		db.execSQL("insert into item values ('7', 'ì‹�ë£Œí’ˆ', '1')");
		db.execSQL("insert into item values ('8', 'ì�˜ë³µë¥˜', '1')");
		db.execSQL("insert into item values ('9', 'ì‚¬ìš©ë£Œ', '1')");
		db.execSQL("insert into item values ('10', 'ê°€êµ¬, ìƒ�í™œìš©í’ˆ', '1')");
		db.execSQL("insert into item values ('11', 'ì§‘ê´€ê³„', '1')");
		db.execSQL("insert into item values ('12', 'ì�˜ë£Œ, ìœ„ìƒ�', '1')");
		db.execSQL("insert into item values ('13', 'êµ�í†µ, í†µì‹ ', '1')");
		db.execSQL("insert into item values ('14', 'êµ�ìœ¡', '1')");
		db.execSQL("insert into item values ('15', 'ë¬¸í™”ì˜¤ë�½', '1')");
		db.execSQL("insert into item values ('16', 'ë³´í—˜', '1')");
		db.execSQL("insert into item values ('17', 'ê¸°íƒ€ì§€ì¶œ', '1')");

		db.execSQL("insert into spec values ('1', 'ê¸°íƒ€', '7')");
		db.execSQL("insert into spec values ('2', 'ìŒ€', '7')");
		db.execSQL("insert into spec values ('3', 'ìœ¡ë¥˜, ì•Œë¥˜', '7')");
		db.execSQL("insert into spec values ('4', 'ìˆ˜ì‚°ë¬¼ë¥˜', '7')");
		db.execSQL("insert into spec values ('5', 'ë‚¨ìƒˆ, ê³¼ì�¼', '7')");
		db.execSQL("insert into spec values ('6', 'ì¡°ë¯¸ë£Œ', '7')");
		db.execSQL("insert into spec values ('7', 'ì�Œë£Œ', '7')");
		db.execSQL("insert into spec values ('8', 'ê¸°íƒ€', '8')");
		db.execSQL("insert into spec values ('9', 'ì™¸ì¶œì˜·', '8')");
		db.execSQL("insert into spec values ('10', 'ì‹ ë°œ', '8')");
		db.execSQL("insert into spec values ('11', 'ì‹¤ë‚´ì˜·', '8')");
		db.execSQL("insert into spec values ('12', 'ê°€ë°©', '8')");
		db.execSQL("insert into spec values ('13', 'ê¸°íƒ€', '9')");
		db.execSQL("insert into spec values ('14', 'ì „ê¸°', '9')");
		db.execSQL("insert into spec values ('15', 'ì—°ë£Œ', '9')");
		db.execSQL("insert into spec values ('16', 'ìˆ˜ë�„', '9')");
		db.execSQL("insert into spec values ('17', 'ì‚´ë¦¼ì§‘', '9')");
		db.execSQL("insert into spec values ('18', 'ê¸°íƒ€', '10')");
		db.execSQL("insert into spec values ('19', 'ê°€êµ¬', '10')");
		db.execSQL("insert into spec values ('20', 'ìž¡í™”', '10')");
		db.execSQL("insert into spec values ('21', 'ì‹�ê¸°ë¥˜', '10')");
		db.execSQL("insert into spec values ('22', 'ê°€ì •ìš©í’ˆ', '10')");
		db.execSQL("insert into spec values ('23', 'ê¸°íƒ€', '11')");
		db.execSQL("insert into spec values ('24', 'ì§‘ìˆ˜ë¦¬', '11')");
		db.execSQL("insert into spec values ('25', 'ê¸°íƒ€', '12')");
		db.execSQL("insert into spec values ('26', 'ì�˜ì•½í’ˆ', '12')");
		db.execSQL("insert into spec values ('27', 'ìœ„ìƒ�ì†Œëª¨í’ˆ', '12')");
		db.execSQL("insert into spec values ('28', 'í™”ìž¥í’ˆ', '12')");
		db.execSQL("insert into spec values ('29', 'ê¸°íƒ€', '13')");
		db.execSQL("insert into spec values ('30', 'ìœ ì„ ì „í™”ë£Œê¸ˆ', '13')");
		db.execSQL("insert into spec values ('31', 'ì�´ë�™ì „í™”ë£Œê¸ˆ', '13')");
		db.execSQL("insert into spec values ('32', 'êµ�í†µë£Œê¸ˆ', '13')");
		db.execSQL("insert into spec values ('33', 'ê¸°íƒ€', '14')");
		db.execSQL("insert into spec values ('34', 'ê¸°íƒ€', '15')");
		db.execSQL("insert into spec values ('35', 'ì˜¤ë�½ì‹œì„¤ë¦¬ìš©', '15')");
		db.execSQL("insert into spec values ('36', 'ì‹ ë¬¸ëŒ€', '15')");
		db.execSQL("insert into spec values ('37', 'DVD/CD', '15')");
		db.execSQL("insert into spec values ('38', 'ê¸°íƒ€', '5')");
		db.execSQL("insert into spec values ('39', 'ì •ì•¡ìƒ�í™œë¹„', '5')");
		db.execSQL("insert into spec values ('40', 'ìƒ�ê¸ˆ', '5')");
		db.execSQL("insert into spec values ('41', 'ê¸°íƒ€', '6')");
		db.execSQL("insert into spec values ('42', 'ìž¡ìˆ˜ìž…', '6')");
		db.execSQL("insert into spec values ('43', 'ê¸°íƒ€', '16')");
		db.execSQL("insert into spec values ('44', 'ì‚¬íšŒë³´í—˜', '16')");
		db.execSQL("insert into spec values ('45', 'ìƒ�ëª…ë³´í—˜', '16')");
		db.execSQL("insert into spec values ('46', 'ê¸°íƒ€', '17')");
		db.execSQL("insert into spec values ('47', 'ìž”ê³ ì •ë¦¬', '17')");

		db.execSQL("insert into assets values ('1', 'í˜„ê¸ˆ')");
		db.execSQL("insert into assets values ('2', 'ì¹´ë“œ')");
	
	}
	
	
}

