
package com.dlten.lib.frmWork;

public interface CTimerListner {
    public void TimerProc( CWnd pWnd, int nTimerID );
}
