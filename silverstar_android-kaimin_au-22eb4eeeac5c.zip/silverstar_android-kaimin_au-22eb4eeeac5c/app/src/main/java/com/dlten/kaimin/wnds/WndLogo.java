package com.dlten.kaimin.wnds;

import com.dlten.lib.STD;
import com.dlten.lib.frmWork.CWnd;
import com.dlten.lib.graphics.CImgObj;
import com.dlten.kaimin.Globals;
import com.dlten.kaimin.frmWndMgr;
import com.dlten.kaimin.kaimin;


public class WndLogo extends CWnd {
	
	private CImgObj m_imgBack = new CImgObj();
	
	private int m_nStep;
	private	long	m_timeProc;

	private static long OPEN_FRAME_COUNT 	= 20;
	private static long WINDOW_WAIT_MS 		= 2000;
	private static long CLOSE_FRAME_COUNT 	= 20;
    
	// SKY:120322:start
	private kaimin	m_activity;
    public WndLogo( kaimin activity ) {
    	super();
    	
    	m_activity = activity;
    	
//		// SKY:120322:start
//		m_activity.processCertificate();
//		while ( ! m_activity.m_bCertiEnd ) {
//			STD.logout("waiting");
//		};
//		// SKY:end
    }
    // SKY:end

    public void OnLoadResource() {
		//setString("logo Wnd");
		
    	//kjh start
    	if( kaimin.m_bSBTV )
    		m_imgBack.load("A0/A0_ssjlogo_sbtv.png");
    	else
    		m_imgBack.load("A0/A0_ssjlogo.png");
    	//kjh end
    	
		m_timeProc = STD.GetTickCount();
		m_nStep = 0;
	}
	public void OnInitWindow() {
		Globals.m_bBGMDisable = false;
		Globals.m_bSEDisable = false;
	}
	public void OnShowWindow() {
	}
	public void OnDestroy() {
		super.OnDestroy();
	}
	
	public void OnPaint() {
		// drawing dimmension is just Globals.RES_WIDTH * Globals.RES_HEIGHT
		drawBackGround();

		int nAlpha = GetStepAlpha();
		setViewAlpha(nAlpha);
	}
	
	public void OnKeyDown( int keycode ) {
		switch (keycode) {
		case KEY_MENU:		OnMenu();						break;
		case KEY_BACK:		OnExit();						break;
		default:			super.OnKeyDown(keycode);		break;
		}
	}

	public void OnExit() {
		// TODO : back button proc
		DestroyWindow( frmWndMgr.WND_DESTROYAPP );
	}

	public void OnMenu() {
		// TODO : menu button proc
	}
	
	public void OnTouchDown(int x, int y) {
		if(m_nStep < 2) {
			m_nStep = 2;
			m_timeProc = STD.GetTickCount();
		}
	}

	private int GetStepAlpha() {
		if (m_timeProc == 0)
			return 255;
		
		int	nAlpha = 255;
		long timeElapse = STD.GetTickCount() - m_timeProc;

		if(m_nStep == 0) {
			if(timeElapse >= OPEN_FRAME_COUNT * Globals.MS_PER_FRAME) {
				m_nStep ++;
				m_timeProc = STD.GetTickCount();
				timeElapse = 0;
			}
			else {
				float	fAlpha = 255.0f;

				fAlpha *= (float)timeElapse;
				fAlpha /= (float)(OPEN_FRAME_COUNT * Globals.MS_PER_FRAME);
				nAlpha = (int)fAlpha;
			}
		}
		if(m_nStep == 1) {
			if(timeElapse >= WINDOW_WAIT_MS) {
				m_nStep ++;
				m_timeProc = STD.GetTickCount();
				timeElapse = 0;
			}
		}
		if(m_nStep == 2) {
			if(timeElapse >= CLOSE_FRAME_COUNT * Globals.MS_PER_FRAME) {
				nAlpha = 0;
				
				if (m_activity.m_bCertSuccess) // SKY:120322
					DestroyWindow( frmWndMgr.WND_TITLE );
//					
//				else // SKY:120322
//				{
//					m_nStep = 0;
//				}
				
//				// SKY:120322:start
//				if ( m_activity.m_bCertiEnd && !m_activity.m_bCertSuccess )
//				{
//					m_activity.killProcess();
//				}
//				// SKY:end
			}
			else {
				float	fAlpha = 255.0f;

				fAlpha *= (float)timeElapse;
				fAlpha /= (float)(CLOSE_FRAME_COUNT * Globals.MS_PER_FRAME);
				nAlpha = (int)(255.0 - fAlpha);
			}
		}

		return nAlpha;
		
	}

	private void drawBackGround() {
		m_imgBack.draw();
	}
	
}
