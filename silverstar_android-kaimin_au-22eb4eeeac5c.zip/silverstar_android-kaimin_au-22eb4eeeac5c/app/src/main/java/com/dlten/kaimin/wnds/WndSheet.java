package com.dlten.kaimin.wnds;

import android.os.Handler;
import android.os.Message;

import com.dlten.kaimin.Globals;
import com.dlten.kaimin.frmWndMgr;
import com.dlten.kaimin.kaimin;
import com.dlten.lib.STD;
import com.dlten.lib.frmWork.CButton;
import com.dlten.lib.frmWork.CWnd;
import com.dlten.lib.graphics.CDCView;
import com.dlten.lib.graphics.CImgObj;

public class WndSheet extends WndTimer {

	private int m_nStep;
	private	long	m_timeProc;
	private	long m_timePauseStart = 0;
	private	boolean m_bPauseFinished = false;

	private static long OPEN_FRAME_COUNT = 20;
	private static long CLOSE_FRAME_COUNT = 20;

	private CImgObj m_imgBg   		= new CImgObj();
	private CImgObj m_imgMoon   	= new CImgObj();
	private CImgObj m_imgBar   		= new CImgObj();
	private CImgObj m_imgMenuBg   	= new CImgObj();
	private CImgObj m_imgScoreBg   	= new CImgObj();
	private CImgObj[] m_imgScoreNum   = new CImgObj[10];

	private CImgObj m_imgMenuNor   	= new CImgObj();
	private CImgObj m_imgMenuFoc   	= new CImgObj();

	private CImgObj[] m_imgSheet   	= new CImgObj[2];
	private CImgObj m_imgSheetCall  = new CImgObj();

	private CButton	m_btnMenu  		= null;
	
	private int m_nScoreOK = 0;
	private int m_nScoreFail = 0;

	private long m_timeProcCall = 0;
	private boolean m_bHit = false;
	private boolean m_bSheetExist = false;

    public static final int
		CMD_MENU_ASYNC      = 0,
		CMD_SELECT_CLOSE	= 1;
    
	public void OnLoadResource() {
		//setString("Sheet Wnd");

		Globals.playBGM(Globals.m_nBGMType_WndSheet);
		
		createImages();

		super.OnLoadResource();
	}
	public void OnInitWindow() {
		m_nStep = 0;
		m_timeProc = STD.GetTickCount();

		Globals.m_bBGMDisable = false;
		Globals.m_bSEDisable = false;
	}
	public void OnShowWindow() {
	}

	private void createImages() {
		//kjh start
		if( kaimin.m_bSBTV ){
			m_imgBg.load( "E1/E1_background_sbtv.png" );
		}
		else{
			if (CDCView.m_fScale <= 1) {
				m_imgBg.load("E1/E1_background.png", true);
				m_imgBg.moveTo(320 * (1 - 1 / CDCView.m_fScale), 300 * (1 - 1 / CDCView.m_fScale));
			}
			else
				m_imgBg.load("E1/E1_background.png");	
		}
		//kjh end
		
		m_imgMoon.load("E1/E1_moon.png", kaimin.m_bSBTV );
		m_imgBar.load("E1/E1_bar.png", kaimin.m_bSBTV );
		m_imgMenuBg.load("COMN/COMN_menu_back.png", kaimin.m_bSBTV );
		m_imgScoreBg.load("E1/E1_info.png", kaimin.m_bSBTV );

		m_imgMenuNor.load("COMN/COMN_btn_menu_1.png", kaimin.m_bSBTV );
		if( kaimin.m_bSBTV ){
			m_imgMenuFoc.load("COMN/COMN_btn_menu_2_sbtv.png", kaimin.m_bSBTV );
		}else{
			m_imgMenuFoc.load("COMN/COMN_btn_menu_2.png");
		}
		

		for(int i = 0; i < 10; i ++) {
			m_imgScoreNum[i] = new CImgObj("COMN/COMN_num_" + i + ".png", kaimin.m_bSBTV );
		}

		m_imgSheet[0] = new CImgObj("E1/E1_sheep_1.png", kaimin.m_bSBTV );
		m_imgSheet[1] = new CImgObj("E1/E1_sheep_2.png", kaimin.m_bSBTV );
		m_imgSheetCall.load("E1/E1_call.png", kaimin.m_bSBTV );

		if( kaimin.m_bSBTV ){

			m_imgMoon.setSBTVScale( true );
			m_imgBar.setSBTVScale( true );
			m_imgMenuBg.setSBTVScale( true );
			m_imgScoreBg.setSBTVScale( true );

			m_imgMenuNor.setSBTVScale( true );
			m_imgMenuFoc.setSBTVScale( true );

			for(int i = 0; i < 10; i ++) {
				m_imgScoreNum[i].setSBTVScale( true );
			}

			m_imgSheet[0].setSBTVScale( true );
			m_imgSheet[1].setSBTVScale( true );
			m_imgSheetCall.setSBTVScale( true );
		}
		
		m_imgMoon.moveTo(550, 42);
		m_imgBar.moveTo(251, 533);
		m_imgMenuBg.moveTo(0, 899);
		m_imgScoreBg.moveTo(10, 906);
		m_imgMenuNor.moveTo(433, 901.5f);
	}
	
	public void createButtons() {
		CButton	btn = null;

		btn = createButton(
				m_imgMenuNor,
				m_imgMenuFoc,
				null);
		btn.setPoint(433, 901.5f);
		btn.setAsyncFlag(true);
		btn.setCommand( CMD_MENU_ASYNC );
		m_btnMenu = btn;
		
		//kjh start
		if( kaimin.m_bSBTV ){
			if( m_btnMenu != null )
				m_btnMenu.setFocus();	
		}
		//kjh end
		
		
	}
	
	public void OnPaint() {
		// drawing dimmension is just Globals.RES_WIDTH * Globals.RES_HEIGHT
		drawBackGround();

		int nAlpha = GetStepAlpha();
		setViewAlpha(nAlpha);
		
		super.OnPaint();
	}
	
    public void OnKeyDown( int keycode ) {
		
		switch (keycode) {
		case KEY_MENU:		OnMenu();						break;
		case KEY_BACK:		OnExit();						break;
		
		//kjh start
		//kjh start
		case KEY_DPAD_CENTER:
			onDPADCenter();
			return;
			
		case KEY_DPAD_DOWN:
		case KEY_DPAD_UP:
		case KEY_DPAD_LEFT:
		case KEY_DPAD_RIGHT:
			OnTouchDown( 0, 0 );
			return;
		//kjh end
		
		default:			super.OnKeyDown(keycode);		break;
		}
	}
	
	
	//kjh start
	
	public void onDPADCenter(){
		OnOption();
	}
	
	public void onDownKey(){
		
	}
	
	public void onUpKey(){
		
	}
	
	public void onLeftKey(){
		
	}
	
	public void onRightKey(){
		
	}
	//kjh end
	
	public void OnCommand(int nCmd) {
		if(m_nStep != 1)
			return;
    	switch (nCmd) {
    	case CMD_MENU_ASYNC:	OnOption();	break;
    	case CMD_SELECT_CLOSE:	Close();	break;
    	}
    }

	public void MessageBoxClosed(int dlgid) {
		switch(dlgid) {
		case 2:
			if(Globals.m_bShowYesNo) {
//		        getView().getActivity().showDialog(3);		//kjh
		        getView().getActivity().showAlertDialog( 3 );	//kjh
		        
			}
			else {
				resume();
			}
			Globals.m_nBGMType_WndSheet = Globals.GetBGMType();
			
			if (Globals.m_bClickClose) { // if user clicks close button, ...
				OnClickMenuClose();
			}
			break;
		case 3:
			if(Globals.m_bSelYes) {
				PostMessage(WM_COMMAND, CMD_SELECT_CLOSE, 0);
			}
			else {
				resume();
			}
			break;
		}
	}

	public void OnOption() {
		
		pause();
		Globals.SetBGMType(Globals.m_nBGMType_WndSheet);

//        getView().getActivity().showDialog(2);
        getView().getActivity().showAlertDialog( 2 );	//kjh

        
	}
	
	public void OnExit() {
		Close();
	}
	
	private void Close() {
		RemoveAllButtons();
		
		m_nStep = 2;
		m_timeProc = STD.GetTickCount();
	}

	public void OnMenu() {
	}

	private int GetStepAlpha() {
		if (m_timeProc == 0)
			return 255;

		int	nAlpha = 255;
		long timeElapse = STD.GetTickCount() - m_timeProc;

		if(m_nStep == 0) {
			if(timeElapse >= OPEN_FRAME_COUNT * Globals.MS_PER_FRAME) {
				m_nStep ++;
				createButtons();
				m_timeProc = STD.GetTickCount();
				timeElapse = 0;
			}
			else {
				float	fAlpha = 255.0f;

				fAlpha *= (float)timeElapse;
				fAlpha /= (float)(OPEN_FRAME_COUNT * Globals.MS_PER_FRAME);
				nAlpha = (int)fAlpha;
			}
		}
		if(m_nStep == 2) {
			if(timeElapse >= CLOSE_FRAME_COUNT * Globals.MS_PER_FRAME) {
				Globals.stopBGM();

				nAlpha = 0;
				DestroyWindow( frmWndMgr.WND_TITLE );
			}
			else {
				float	fAlpha = 255.0f;

				fAlpha *= (float)timeElapse;
				fAlpha /= (float)(CLOSE_FRAME_COUNT * Globals.MS_PER_FRAME);
				nAlpha = (int)(255.0 - fAlpha);
			}
		}

		return nAlpha;
	}

	private void drawBackGround() {
		m_imgBg.draw();
		m_imgMoon.draw();
		m_imgBar.draw();
		m_imgMenuBg.draw();
		m_imgScoreBg.draw();
		drawScore();
		
		if(m_nStep != 1) {
			m_imgMenuNor.draw();
		}
		else {
			//kjh start
			if( kaimin.m_bSBTV )
				drawSheetSBTV();
			else
				drawSheet();
			//kjh end
		}
	}
	
	private void drawScore1(int nScore, float x) {
		int nOOO = 100000;
		for(int i = 0; i < 6; i ++) {
			int nOne = nScore / nOOO;
			nScore -= nOne * nOOO;
			nOOO /= 10;

			m_imgScoreNum[nOne].draw(x + 19 * i, 919.5f);
		}
	}

	private void drawScore() {
		drawScore1(m_nScoreOK, 75.5f);
		drawScore1(m_nScoreFail, 299.5f);
	}
	
//	int nStartIndex	=	400;
//	int nEndIndex	=	1000;
	
	int nStartIndex	=	50;
	int nEndIndex	=	1350;
	
	//kjh start
	private void drawSheetSBTV(){
		long curTime;
		curTime = STD.GetTickCount();

		if(m_timePauseStart != 0) {
			if(m_bPauseFinished) {
				m_timeProc += (curTime - m_timePauseStart);
				if(m_timeProcCall > 0)
					m_timeProcCall += (curTime - m_timePauseStart);
				m_timePauseStart = 0;
			}
			else
				curTime = m_timePauseStart;
		}

		long timeElapse = curTime - m_timeProc;
		float fFrame = (float)timeElapse / Globals.MS_PER_FRAME;
		
		float fSheetX = 0, fSheetY = 0;
		int nSheet = 0;
		
		if(fFrame >= nStartIndex) {
			if(fFrame > nEndIndex) {
				if(!m_bHit) {
					if(m_nScoreFail < 999999)
						m_nScoreFail ++; 
				}
				m_bHit = false;
				m_bSheetExist = false;
				m_timeProc = curTime;
				m_timeProcCall = 0;
			}
			else {
				m_bSheetExist = true;
				
				nSheet = (((int)fFrame - nStartIndex) / 10) & 1;
				float a = (fFrame - nStartIndex) / 600;
				fSheetX = -81.5f * (1 - a) + 642.5f * a;
				fSheetY = 561.5f;
				fSheetX	-=	420;
				if(fFrame > 630 && fFrame < 780) {
					a = (705 - fFrame) / 75;
					a = a * a * 104;
					fSheetY -= (104 - a);
					nSheet = 1;
				}
			}
		}
		
		if(m_timeProcCall > 0) {
			timeElapse = curTime - m_timeProcCall;
			fFrame = (float)timeElapse / Globals.MS_PER_FRAME;
			if(fFrame > 100) {
				m_timeProcCall = 0;
			}
			else {
				float a = fFrame / 100;
				float fSheetCallX = fSheetX + 39.5f - 36.5f + a * 64.726f;
				float fSheetCallY = fSheetY + 30.5f - 15.5f - 9 - a * 64.726f;
				m_imgSheetCall.draw(fSheetCallX, fSheetCallY);
			}
		}
		if(m_bSheetExist) {
			if( kaimin.m_bSBTV )
				m_imgSheet[nSheet].draw(fSheetX, fSheetY);
		}
		
	}
	//kjh end
	
	private void drawSheet() {
		long curTime;
		curTime = STD.GetTickCount();

		if(m_timePauseStart != 0) {
			if(m_bPauseFinished) {
				m_timeProc += (curTime - m_timePauseStart);
				if(m_timeProcCall > 0)
					m_timeProcCall += (curTime - m_timePauseStart);
				m_timePauseStart = 0;
			}
			else
				curTime = m_timePauseStart;
		}

		long timeElapse = curTime - m_timeProc;
		float fFrame = (float)timeElapse / Globals.MS_PER_FRAME;
		
		float fSheetX = 0, fSheetY = 0;
		int nSheet = 0;
		
		if(fFrame >= 400) {
			if(fFrame > 1000) {
				if(!m_bHit) {
					if(m_nScoreFail < 999999)
						m_nScoreFail ++;
				}
				m_bHit = false;
				m_bSheetExist = false;
				m_timeProc = curTime;
				m_timeProcCall = 0;
			}
			else {
				m_bSheetExist = true;
				
				nSheet = (((int)fFrame - 400) / 10) & 1;
				float a = (fFrame - 400) / 600;
				fSheetX = -81.5f * (1 - a) + 642.5f * a;
				fSheetY = 561.5f;
				if(fFrame > 630 && fFrame < 780) {
					a = (705 - fFrame) / 75;
					a = a * a * 104;
					fSheetY -= (104 - a);
					nSheet = 1;
				}
			}
		}
		
		if(m_timeProcCall > 0) {
			timeElapse = curTime - m_timeProcCall;
			fFrame = (float)timeElapse / Globals.MS_PER_FRAME;
			if(fFrame > 100) {
				m_timeProcCall = 0;
			}
			else {
				float a = fFrame / 100;
				float fSheetCallX = fSheetX + 39.5f - 36.5f + a * 64.726f;
				float fSheetCallY = fSheetY + 30.5f - 15.5f - 9 - a * 64.726f;
				m_imgSheetCall.draw(fSheetCallX, fSheetCallY);
			}
		}
		if(m_bSheetExist) {
			m_imgSheet[nSheet].draw(fSheetX, fSheetY);
		}
	}
	
	public void OnTouchDown(int x, int y) {
		if(m_bSheetExist && !m_bHit) {
			m_bHit = true;

			Globals.playSE(10);

			if(m_nScoreOK < 999999)
				m_nScoreOK ++;

			m_timeProcCall = STD.GetTickCount();
		}
	}

	private void pause() {
		m_timePauseStart = STD.GetTickCount();
		m_bPauseFinished = false;
	}

	private void resume() {
		m_bPauseFinished = true;
	}

	public void OnSuspend() {
		if(Globals.m_nBGMType_WndSheet < Globals.m_nBGMIDs.length) {
			Globals.pauseBGM();
		}
		pause();
	}

	public void OnResume() {
		if(Globals.m_nBGMType_WndSheet < Globals.m_nBGMIDs.length) {
			Globals.resumeBGM();
		}
		resume();
	}
}
