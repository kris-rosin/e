package com.dlten.kaimin.wnds;

import android.app.SearchManager.OnDismissListener;
import android.util.Log;
import android.view.KeyEvent;

import com.dlten.lib.STD;
import com.dlten.lib.frmWork.CButton;
import com.dlten.lib.frmWork.CWnd;
import com.dlten.lib.graphics.CImgObj;
import com.dlten.kaimin.Globals;
import com.dlten.kaimin.frmWndMgr;
import com.dlten.kaimin.kaimin;

public class WndTimer extends CWnd {

	private CImgObj m_imgTimerMark   = new CImgObj();
	private CImgObj m_imgTimerNotify   = new CImgObj();
	
	public void OnLoadResource() {
		m_imgTimerMark.load("TM/COMN_timer.png", kaimin.m_bSBTV );
		m_imgTimerNotify.load("TM/TM_end.png", kaimin.m_bSBTV );
		if( kaimin.m_bSBTV ){
			m_imgTimerMark.setSBTVScale( true );
			m_imgTimerNotify.setSBTVScale( true );
		}
		m_imgTimerMark.move(640-30, 6);
		m_imgTimerNotify.move(0, 0);
		
		Globals.SetScreenOffType(0);
	}
	public void OnInitWindow() {
		super.OnInitWindow();
	}
	public void OnShowWindow() {
		super.OnShowWindow();
	}
	public void OnPaint() {
		super.OnPaint();
	}
	public void OnKeyDown( int keycode ) {
		super.OnKeyDown(keycode);
	}
	public void OnCommand(int nCmd) {
		super.OnCommand(nCmd);
    }
	public void OnClickMenuClose() {
		if (Globals.GetTimerType() > 0) { //timer : off
			if (Globals.m_nTimerTick <= 0)
				Globals.m_nTimerTick = 1;
			getView().getActivity().setSuicideAlarm(Globals.m_nTimerTick);
		}
		else {
			OnClickExit();
		}
		Globals.SetScreenOffType(Globals.GetScreenOffType());
	}
	public void OnClickExit() {
		Globals.m_nTimerTick = -1;
		getView().getActivity().cancelAlarm();
		Globals.SetTimerType(0);
	}
	
	public void OnDestroy() {
		Globals.SetScreenOffType(0);
		getView().getActivity().cancelAlarm();
		super.OnDestroy();
	}

    public void onLastDraw() {
		if (Globals.GetTimerType() != 0) {
			int nTick;
			if (Globals.suicideStartTick > 0) {
				nTick = Globals.m_nTimerTick - 
				(int)((System.currentTimeMillis() - Globals.suicideStartTick + 999) / 1000);
			}
			else {
				nTick = Globals.m_nTimerTick;
			}
			if (nTick < 20) //20s
				m_imgTimerNotify.draw();
			m_imgTimerMark.draw();
		}
    }
}
