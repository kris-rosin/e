package com.dlten.lib.frmWork;

import java.util.Vector;

import com.dlten.lib.CBaseView;
import com.dlten.lib.graphics.CImage;
import com.dlten.lib.graphics.CImgObj;
import com.dlten.lib.graphics.CPoint;

public abstract class CEventWnd {

    private static CBaseView m_baseView = null;

    protected Vector<CAnimation> m_Anims;
    protected Vector<CButton> m_Btns;
    protected CEventWnd m_pParent;
    protected CEventWnd m_pActiveWnd;
    protected CEventWnd m_pModalessWnd;
    protected CEventWnd m_pForegroundWnd;

    private boolean m_bEnable;
    private boolean m_bDestroyed = false;

    public CEventWnd() {
        m_Anims = new Vector<CAnimation>(10, 5);
        m_Btns = new Vector<CButton>(10, 5);

        m_bEnable = true;

        m_pParent = null;
        m_pActiveWnd = null;
        m_pModalessWnd = null;
        m_pForegroundWnd = null;

        m_baseView.clearMsgQueue();
    }

    // abstract functions
    public abstract void DrawProcess();
    public abstract void DrawPrevProc();
    public void onDrawText() {};

    // Framework Callback Functions
    public void OnLoadResource() {}
    public void OnInitWindow() {}
    public void OnShowWindow() {}
    public void OnDestroy() {
    	m_bDestroyed = true;
    	
    	RemoveAllButtons();
    	deleteTexture();
    }
    
    public final int RunProc() {
        return m_baseView.RunProc(this);
    }
    
    public void OnSuspend() {}
    public void OnResume() {}

    public void onMultiTouchDown(int wParam1, int lParam1, int wParam2, int lParam2) {
    	if(m_bDestroyed)
    		return;
    	
    	OnMultiTouchDown(wParam1, lParam1, wParam2, lParam2);
    }
    public void onTouchDown(int wParam, int lParam) {
    	if(m_bDestroyed)
    		return;
    	
    	if((GetActiveWnd() != null) && (GetActiveWnd() != this)) {
    		GetActiveWnd().onTouchDown(wParam, lParam);
    	}
    	else {
    		if (setFocusButton(wParam, lParam) == false)
    			OnTouchDown(wParam, lParam);
    	}
    }
    public boolean onTouchUp(int wParam, int lParam) {
    	if(m_bDestroyed)
    		return false;
    	
    	if((GetActiveWnd() != null) && (GetActiveWnd() != this)) {
    		return GetActiveWnd().onTouchUp(wParam, lParam);
    	}
    	else {
    		if (clickFocusButton(wParam, lParam) == false)
    			return OnTouchUp(wParam, lParam);
    		else
    			return false;
    	}
    }
    public void onTouchMove(int wParam, int lParam) {
    	if(m_bDestroyed)
    		return;
    	
    	if((GetActiveWnd() != null) && (GetActiveWnd() != this)) {
    		GetActiveWnd().onTouchMove(wParam, lParam);
    	}
    	else {
    		if (changeFocusButton(wParam, lParam) == false)
    			OnTouchMove(wParam, lParam);
    	}
    }
    public void onFling(float velocityX, float velocityY) {
    	if((GetActiveWnd() != null) && (GetActiveWnd() != this)) {
    		GetActiveWnd().onFling(velocityX, velocityY);
    	}
    	else {
    		OnFling(velocityX, velocityY);
    	}
    }

    public int WindowProc(int message, int wParam, int lParam) {
        switch (message) {
        case WM_PAINT:
            UpdateWindow();
            break;
        case WM_COMMAND:
            OnCommand(wParam);
            break;
        case WM_KEY_DOWN:
            OnKeyDown(wParam);
            break;
        case WM_KEY_UP:
            OnKeyUp(wParam);
            break;
        case WM_KEY_PRESS:
            OnKeyPress(wParam);
            break;
        case WM_QUIT:
            break;
        case WM_ANIM_EVENT:
            OnAnimEvent((short) wParam);
            break;
        default:
            break;
        }
        return 0;
    }

    private CButton	m_btnFocus = null;
    private CButton	findFocusButton(int x, int y) {
        CPoint	pt = new CPoint(x, y);
        CButton	btnFocus = null;
        CButton btn;
        for (int i = 0; i < m_Btns.size(); i++) {
        	btn = (CButton) m_Btns.elementAt(i);
        	
           	if (btn.getVisible() == true &&
           		btn.isInside(pt) == true)
           	{
           		btnFocus = btn; 
           	}
        }
    	return btnFocus;
    }
    private boolean setFocusButton(int x, int y) {
        CButton	btnFocus = findFocusButton(x, y);
        
        // if there is no any focus button.
        if (btnFocus == null) {
        	if (m_btnFocus != null) {
        		m_btnFocus = null;
        		m_btnFocus.setNormal();
        	}
        	return false;
        }
        
        // if there is already a focus button.
        if (btnFocus != m_btnFocus) {
        	if (m_btnFocus != null) {
        		m_btnFocus = null;
        		m_btnFocus.setNormal();
        	}
        }
        
    	btnFocus.setFocus();
    	m_btnFocus = btnFocus;
    	return true;
    }
    
    private boolean changeFocusButton(int x, int y) {
    	if (m_btnFocus == null)
    		return false;

    	// return setFocusButton(x, y);
    	CPoint	pt = new CPoint(x, y);
        if (m_btnFocus.isInside(pt) == true) {
        	m_btnFocus.setFocus();
        } else {
       		m_btnFocus.setNormal();
        }
    	return true;
    }
    
    private boolean clickFocusButton(int x, int y) {
    	if (m_btnFocus == null)
    		return false;

    	CButton	btnFocus = m_btnFocus;
        m_btnFocus = null;
        
        btnFocus.setNormal();
    	CPoint	pt = new CPoint(x, y);
        if (btnFocus.isInside(pt) == true) {
        	if(btnFocus.getAsyncFlag())
            	OnCommand(btnFocus.getCommand());
        	else
        		PostMessage(WM_COMMAND, btnFocus.getCommand(), 0);
        }
    	return true;
    }
    
    // UI callback functions.
    public void OnKeyDown(int keycode) {}
    public void OnKeyUp(int keycode) {}
    public void OnKeyPress(int keycode) {}
    public void OnMultiTouchDown(int nTouchX1, int nTouchY1, int nTouchX2, int nTouchY2) {}
    public void OnTouchDown(int nTouchX, int nTouchY) {}
    public boolean OnTouchUp(int nTouchX, int nTouchY) { return false; }
    public void OnTouchMove(int nTouchX, int nTouchY) {}
    public void OnFling(float velocityX, float velocityY) {}
    public void OnCommand(int nCmd) {}
    public void OnAnimEvent(int nAnimID) {}
    public int OnNetEvent(int nEvtType, int nParam, Object objData) { return 0; }

    // for framework call
    public static void setView(CBaseView dc) {
    	m_baseView = dc;
    }
    public static CBaseView getView() {
        return m_baseView;
    }

    public boolean AddAnimation(CAnimation pAnimObj) {
        if (m_Anims.indexOf(pAnimObj) != -1) { // exist this object
            return false;
        }
        m_Anims.addElement(pAnimObj);
        return true;
    }
    public void RemoveAnimation(CAnimation pAnimObj) {
        m_Anims.removeElement(pAnimObj);
    }

/*    public CButton createButton(String norName, String focName, String disName) {
		CButton	btn = new CButton();
		btn.create(this, norName, focName, disName);
		
		return btn;
    }*/
    public CButton createButton(CImgObj nor, CImgObj foc, CImgObj dis) {
		CButton	btn = new CButton();
		btn.create(this, new CPoint(0, 0), nor, foc, dis, null);
		
		return btn;
    }
/*    public CButton createButton(String norName, String focName, String disName, String chkName) {
		CButton	btn = new CButton();
		btn.create(this, norName, focName, disName, chkName);
		
		return btn;
    }*/
    public boolean AddButton(CButton pBtnObj) {
        if (m_Btns.indexOf(pBtnObj) != -1) { // exist this object
            return false;
        }
        m_Btns.addElement(pBtnObj);
        return true;
    }
    public void RemoveButton(CButton pBtnObj) {
        m_Btns.removeElement(pBtnObj);
    }
    public void RemoveAllButtons() {
        CButton btn;
        while (m_Btns.size() > 0) {
        	btn = (CButton) m_Btns.elementAt(0);
        	btn.destroy();
        }
        
        ClearMessageQueue();
    }
    public void ClearMessageQueue() {
    	m_baseView.clearMsgQueue();
    }
    
    public boolean EnableWindow(boolean bEnable) {
        boolean bTemp = m_bEnable;
        m_bEnable = bEnable;
        return bTemp;
    }
    public boolean IsEnable() {
        return m_bEnable;
    };
    public void NotifyToParentEndRun() {
        if (m_pParent != null) {
            m_pParent.InitKeyState();
        }
    }
    private void InitKeyState() {
        int[] messages = new int[] {WM_KEY_DOWN, WM_KEY_UP};
        m_baseView.DeleteMsgs(messages);
    }

    // window state relations
    public void SetParent(CEventWnd pParent) {
        m_pParent = pParent;
    }
    public CEventWnd SetActiveWnd(CEventWnd pActive) {
        CEventWnd pOldActiveWnd = m_pActiveWnd;
        m_pActiveWnd = pActive;
        return pOldActiveWnd;
    }
    public CEventWnd SetModalessWnd(CEventWnd pModaless) {
        CEventWnd pOldModalessWnd = m_pModalessWnd;
        m_pModalessWnd = pModaless;
        return pOldModalessWnd;
    }
    public CEventWnd SetForegroundWnd(CEventWnd pForegroundWnd) {
        CEventWnd pRet = m_pForegroundWnd;
        m_pForegroundWnd = pForegroundWnd;
        return pRet;
    }


    /////////////////////////////////////////////////////////////////////////
    // functionalities
    /////////////////////////////////////////////////////////////////////////
    // window state relations.
    public void DestroyWindow(int nCode) {
        PostMessage(WM_QUIT, nCode);
    }
    public CEventWnd GetParent() {
        return m_pParent;
    }
    public CEventWnd GetActiveWnd() {
        return m_pActiveWnd;
    }
    public CEventWnd GetForegroundWnd() {
        return m_pForegroundWnd;
    }
    public CEventWnd GetModalessWnd() {
        return m_pModalessWnd;
    }
    
    public void onLastDraw() {
    	
    }

    // message relations
    public boolean SendMessage(int message, int wParam, int lParam) {
        WindowProc(message, wParam, lParam);
        return true;
    }
    public boolean PostMessage(int message) {
        return PostMessage(message, 0);
    }
    public boolean PostMessage(int message, int wParam) {
        return PostMessage(message, wParam, 0);
    }
    public boolean PostMessage(int message, int wParam, int lParam) {
        if (!IsEnable() && message == WM_TIMER)
            return false;
        m_baseView.PostMessage(message, wParam, lParam);
        return true;
    }

    // Update
    public void UpdateWindow() {
    	m_baseView.update(this);
    }
    public void Invalidate() {
        PostMessage(WM_PAINT);
    }
    
    // for Debug
    protected String m_strName = null;
    
    public void setString(String strName) {
//    	if (!m_strName)
//    		m_strName = new String();
    	m_strName =  strName;
    }
    
    public void drawStr(int x, int y, int color, int drawType, String str) {
		CBaseView view = getView();
//===NO		view.setColor(color);
		view.drawString(str, x, y, drawType);
	}
    
    public void drawStr(int x, int y, String str) {
    	drawStr(x, y, 0xFFFFFF, ANCHOR_CENTER | ANCHOR_TOP, str);
	}
    
    public static final int
    WM_PAINT = 2,
    WM_COMMAND = 3,
    WM_TIMER = 4,
    WM_SUSPEND = 5,
    WM_RESUME = 6,
    //WM_TOUCH_DOWN = 8,
    //WM_TOUCH_UP = 9,
    //WM_TOUCH_MOVE = 10,
    WM_KEY_DOWN = 12,
    WM_KEY_UP = 13,
    WM_KEY_PRESS = 14,
    WM_QUIT = 15,
    WM_ANIM_EVENT = 16,
    WM_NET = 17,
    WM_APP_EXIT = 18,
    WM_RESIZE = 19,
    //kjh start
   
    WM_GENERIC_MOVE	=	22;
    //kjh end

    public static final int WM_USER = 0x400;

    public static final int NET_EVT_CONNECTED = 0;
    public static final int NET_EVT_CLOSED = 1;
    public static final int NET_EVT_RECVDATA = 2;

    public static int RES_WIDTH = CBaseView.RES_WIDTH;
    public static int RES_HEIGHT = CBaseView.RES_HEIGHT;
    public static void prepareDC() {
        RES_WIDTH = CBaseView.RES_WIDTH;
        RES_HEIGHT = CBaseView.RES_HEIGHT;
    }

    public static final int ANCHOR_TOP = CImage.ANCHOR_TOP;
    public static final int ANCHOR_MIDDLE = CImage.ANCHOR_MIDDLE;
    public static final int ANCHOR_BOTTOM = CImage.ANCHOR_BOTTOM;
    public static final int ANCHOR_V_FILTER = CImage.ANCHOR_V_FILTER;
    public static final int ANCHOR_LEFT = CImage.ANCHOR_LEFT;
    public static final int ANCHOR_CENTER = CImage.ANCHOR_CENTER;
    public static final int ANCHOR_RIGHT = CImage.ANCHOR_RIGHT;
    public static final int ANCHOR_H_FILTER = CImage.ANCHOR_H_FILTER;

    public static final int
            KEY_NONE = 0,
    KEY_0 = 1 << 0,
    KEY_1 = 1 << 1,
    KEY_2 = 1 << 2,
    KEY_3 = 1 << 3,
    KEY_4 = 1 << 4,
    KEY_5 = 1 << 5,
    KEY_6 = 1 << 6,
    KEY_7 = 1 << 7,
    KEY_8 = 1 << 8,
    KEY_9 = 1 << 9,
    KEY_MENU = 1 << 10,
    KEY_HOME = 1 << 11,
    KEY_BACK = 1 << 12,
    KEY_DIAL = 1 << 13,
    KEY_UP = 1 << 14,
    KEY_DOWN = 1 << 15,
    KEY_LEFT = 1 << 16,
    KEY_RIGHT = 1 << 17,
    KEY_SELECT = 1 << 18,
    //kjh start
    KEY_DPAD_LEFT	=	1 << 19,
    KEY_DPAD_RIGHT	=	1 << 20,
    KEY_DPAD_UP		=	1 << 21,
    KEY_DPAD_DOWN	=	1 << 22,
    KEY_DPAD_CENTER	=	1 << 23,
    KEY_DPAD_SPACE	=	1 << 24;
    //kjh end
    
//////////////////////////////////////////////////////////////////////////////////
    public void onLoadResource2() {};

    private boolean m_bTextureLoaded = false;
    
    public boolean isTextureLoaded() {
    	return m_bTextureLoaded;
    }

    public void initializeTexture(int nTextureCount) {
    	m_baseView.initializeTexture(nTextureCount);
    }

    public int createTexture(int nTextureIndex, int width, int height) {
    	return m_baseView.createTexture(nTextureIndex, width, height);
    }
    
    public void finalizeTexture() {
    	m_baseView.finalizeTexture();
    	m_bTextureLoaded = true;
    }

    public void deleteTexture() {
    	m_baseView.deleteTexture();
    }
    
    public void setViewAlpha(int nAlpha) {
    	m_baseView.setAlpha(nAlpha / 255.0f);
    }
}
